package com.mangmi.controllerbridge;

import java.util.Objects;

/**
 * A transport-neutral snapshot of the physical handheld controller.
 *
 * <p>Stick axes use the signed range -127..127 and triggers use 0..255. Keeping the
 * snapshot immutable makes it safe to hand between the UI and transport threads.</p>
 */
public final class ControllerState {
    public static final int UNKNOWN_BATTERY = -1;
    public static final int NO_TOUCH_ID = -1;
    public static final int BUTTON_A = 1;
    public static final int BUTTON_B = 1 << 1;
    public static final int BUTTON_X = 1 << 2;
    public static final int BUTTON_Y = 1 << 3;
    public static final int BUTTON_LB = 1 << 4;
    public static final int BUTTON_RB = 1 << 5;
    public static final int BUTTON_BACK = 1 << 6;
    public static final int BUTTON_START = 1 << 7;
    public static final int BUTTON_GUIDE = 1 << 8;
    public static final int BUTTON_LS = 1 << 9;
    public static final int BUTTON_RS = 1 << 10;
    public static final int BUTTON_DPAD_UP = 1 << 11;
    public static final int BUTTON_DPAD_DOWN = 1 << 12;
    public static final int BUTTON_DPAD_LEFT = 1 << 13;
    public static final int BUTTON_DPAD_RIGHT = 1 << 14;

    public static final ControllerState NEUTRAL =
            new ControllerState(0, 0, 0, 0, 0, 0, 0);

    public final int leftX;
    public final int leftY;
    public final int rightX;
    public final int rightY;
    public final int leftTrigger;
    public final int rightTrigger;
    public final int buttons;
    public final int batteryPercent;
    public final boolean charging;
    public final boolean touch1Active;
    public final int touch1Id;
    public final int touch1X;
    public final int touch1Y;
    public final boolean touch2Active;
    public final int touch2Id;
    public final int touch2X;
    public final int touch2Y;
    public final boolean touchClick;

    public ControllerState(
            int leftX,
            int leftY,
            int rightX,
            int rightY,
            int leftTrigger,
            int rightTrigger,
            int buttons) {
        this(
                leftX,
                leftY,
                rightX,
                rightY,
                leftTrigger,
                rightTrigger,
                buttons,
                UNKNOWN_BATTERY,
                false,
                false,
                NO_TOUCH_ID,
                0,
                0,
                false,
                NO_TOUCH_ID,
                0,
                0,
                false);
    }

    public ControllerState(
            int leftX,
            int leftY,
            int rightX,
            int rightY,
            int leftTrigger,
            int rightTrigger,
            int buttons,
            int batteryPercent,
            boolean charging,
            boolean touch1Active,
            int touch1Id,
            int touch1X,
            int touch1Y,
            boolean touch2Active,
            int touch2Id,
            int touch2X,
            int touch2Y,
            boolean touchClick) {
        this.leftX = clamp(leftX, -127, 127);
        this.leftY = clamp(leftY, -127, 127);
        this.rightX = clamp(rightX, -127, 127);
        this.rightY = clamp(rightY, -127, 127);
        this.leftTrigger = clamp(leftTrigger, 0, 255);
        this.rightTrigger = clamp(rightTrigger, 0, 255);
        this.buttons = buttons & 0xFFFF;
        this.batteryPercent =
                batteryPercent < 0 ? UNKNOWN_BATTERY : clamp(batteryPercent, 0, 100);
        this.charging = charging;
        this.touch1Active = touch1Active;
        this.touch1Id = clampTouchId(touch1Id);
        this.touch1X = clamp(touch1X, 0, 1919);
        this.touch1Y = clamp(touch1Y, 0, 942);
        this.touch2Active = touch2Active;
        this.touch2Id = clampTouchId(touch2Id);
        this.touch2X = clamp(touch2X, 0, 1919);
        this.touch2Y = clamp(touch2Y, 0, 942);
        this.touchClick = touchClick;
    }

    public ControllerState withButton(int mask, boolean pressed) {
        int nextButtons = pressed ? buttons | mask : buttons & ~mask;
        return new ControllerState(
                leftX,
                leftY,
                rightX,
                rightY,
                leftTrigger,
                rightTrigger,
                nextButtons,
                batteryPercent,
                charging,
                touch1Active,
                touch1Id,
                touch1X,
                touch1Y,
                touch2Active,
                touch2Id,
                touch2X,
                touch2Y,
                touchClick);
    }

    public ControllerState withBattery(int percent, boolean isCharging) {
        return new ControllerState(
                leftX,
                leftY,
                rightX,
                rightY,
                leftTrigger,
                rightTrigger,
                buttons,
                percent,
                isCharging,
                touch1Active,
                touch1Id,
                touch1X,
                touch1Y,
                touch2Active,
                touch2Id,
                touch2X,
                touch2Y,
                touchClick);
    }

    public ControllerState withTouches(
            boolean firstActive,
            int firstId,
            int firstX,
            int firstY,
            boolean secondActive,
            int secondId,
            int secondX,
            int secondY) {
        return withTouches(
                firstActive,
                firstId,
                firstX,
                firstY,
                secondActive,
                secondId,
                secondX,
                secondY,
                false);
    }

    public ControllerState withTouches(
            boolean firstActive,
            int firstId,
            int firstX,
            int firstY,
            boolean secondActive,
            int secondId,
            int secondX,
            int secondY,
            boolean clickActive) {
        return new ControllerState(
                leftX,
                leftY,
                rightX,
                rightY,
                leftTrigger,
                rightTrigger,
                buttons,
                batteryPercent,
                charging,
                firstActive,
                firstId,
                firstX,
                firstY,
                secondActive,
                secondId,
                secondX,
                secondY,
                clickActive);
    }

    public ControllerState withTouches(TouchpadState touchpad) {
        TouchpadState safe = touchpad == null ? TouchpadState.NONE : touchpad;
        return withTouches(
                safe.touch1Active,
                safe.touch1Id,
                safe.touch1X,
                safe.touch1Y,
                safe.touch2Active,
                safe.touch2Id,
                safe.touch2X,
                safe.touch2Y,
                safe.clickActive);
    }

    public boolean hasButton(int mask) {
        return (buttons & mask) != 0;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ControllerState)) {
            return false;
        }
        ControllerState state = (ControllerState) other;
        return leftX == state.leftX
                && leftY == state.leftY
                && rightX == state.rightX
                && rightY == state.rightY
                && leftTrigger == state.leftTrigger
                && rightTrigger == state.rightTrigger
                && buttons == state.buttons
                && batteryPercent == state.batteryPercent
                && charging == state.charging
                && touch1Active == state.touch1Active
                && touch1Id == state.touch1Id
                && touch1X == state.touch1X
                && touch1Y == state.touch1Y
                && touch2Active == state.touch2Active
                && touch2Id == state.touch2Id
                && touch2X == state.touch2X
                && touch2Y == state.touch2Y
                && touchClick == state.touchClick;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                leftX,
                leftY,
                rightX,
                rightY,
                leftTrigger,
                rightTrigger,
                buttons,
                batteryPercent,
                charging,
                touch1Active,
                touch1Id,
                touch1X,
                touch1Y,
                touch2Active,
                touch2Id,
                touch2X,
                touch2Y,
                touchClick);
    }

    private static int clampTouchId(int value) {
        return value < 0 ? NO_TOUCH_ID : Math.min(127, value);
    }
}
