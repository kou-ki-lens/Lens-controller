package com.mangmi.controllerbridge;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import android.view.KeyEvent;

import java.util.Map;

import org.junit.Test;

public class ButtonMappingTest {
    @Test
    public void standardMappingContainsAirXFaceAndTriggerButtons() {
        Map<Integer, Integer> mapping = ButtonMapping.standard();

        assertEquals(
                ButtonMapping.ACTION_A,
                (int) mapping.get(KeyEvent.KEYCODE_BUTTON_A));
        assertEquals(
                ButtonMapping.ACTION_LT,
                (int) mapping.get(KeyEvent.KEYCODE_BUTTON_L2));
        assertEquals(
                ButtonMapping.ACTION_START,
                (int) mapping.get(KeyEvent.KEYCODE_BUTTON_SELECT));
    }

    @Test
    public void rebindingRemovesPreviousKeyForActionAndStealsNewKey() {
        Map<Integer, Integer> mapping = ButtonMapping.standard();

        ButtonMapping.bind(mapping, KeyEvent.KEYCODE_BUTTON_Y, ButtonMapping.ACTION_A);

        assertFalse(
                ButtonMapping.keysForAction(mapping, ButtonMapping.ACTION_A)
                        .contains(KeyEvent.KEYCODE_BUTTON_A));
        assertEquals(
                ButtonMapping.ACTION_A,
                (int) mapping.get(KeyEvent.KEYCODE_BUTTON_Y));
    }

    @Test
    public void logicalButtonBitsMatchControllerStateMasks() {
        assertEquals(
                ControllerState.BUTTON_DPAD_RIGHT,
                ButtonMapping.buttonBit(ButtonMapping.ACTION_DPAD_RIGHT));
        assertEquals(0, ButtonMapping.buttonBit(ButtonMapping.ACTION_LT));
    }

    @Test
    public void presetLayoutNamesAreIndependentPerOutputProfile() {
        assertEquals(
                AppPreferences.XBOX_PRESET_LAYOUT,
                AppPreferences.presetLayoutName(OutputProfile.XBOX));
        assertEquals(
                AppPreferences.DS4_PRESET_LAYOUT,
                AppPreferences.presetLayoutName(OutputProfile.DUALSHOCK_4));
    }
}
