# The application uses only platform APIs and does not require custom rules.
