package com.mangmi.controllerbridge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public final class NavigationCursorView extends View {
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint crossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF horizontal = new RectF();
    private final RectF vertical = new RectF();
    private boolean emphasized;

    public NavigationCursorView(Context context) {
        super(context);
        setClickable(false);
        setFocusable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        shadowPaint.setColor(Color.argb(58, 255, 255, 255));
        crossPaint.setColor(Color.rgb(8, 9, 12));
        outlinePaint.setStyle(Paint.Style.STROKE);
        outlinePaint.setStrokeWidth(dp(1.5f));
        outlinePaint.setColor(Color.argb(220, 255, 255, 255));
    }

    public void setEmphasized(boolean value) {
        if (emphasized == value) {
            return;
        }
        emphasized = value;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float arm = dp(emphasized ? 27 : 16);
        float thickness = dp(emphasized ? 13 : 8);
        float radius = thickness / 2f;

        if (emphasized) {
            canvas.drawCircle(cx, cy, dp(39), shadowPaint);
            outlinePaint.setStrokeWidth(dp(2f));
        } else {
            outlinePaint.setStrokeWidth(dp(1.2f));
        }

        horizontal.set(cx - arm, cy - thickness / 2f, cx + arm, cy + thickness / 2f);
        vertical.set(cx - thickness / 2f, cy - arm, cx + thickness / 2f, cy + arm);
        canvas.drawRoundRect(horizontal, radius, radius, outlinePaint);
        canvas.drawRoundRect(vertical, radius, radius, outlinePaint);
        canvas.drawRoundRect(horizontal, radius, radius, crossPaint);
        canvas.drawRoundRect(vertical, radius, radius, crossPaint);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
