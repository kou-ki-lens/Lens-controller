package com.mangmi.controllerbridge;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Process;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public final class UsbTcpTransport implements Transport {
    private static final int DISCOVERY_PORT = 47653;
    private static final int DATA_PORT = 47654;
    private static final String DISCOVER_REQUEST = "MANGMI_BRIDGE_DISCOVER_V1";
    private static final String DISCOVER_RESPONSE_PREFIX = "MANGMI_BRIDGE_SERVER_V1 ";

    private final Context context;
    private final AppPreferences preferences;
    private OutputProfile profile = OutputProfile.XBOX;
    private Callback callback;
    private Thread worker;
    private volatile boolean stopped;
    private volatile Socket socket;
    private OutputStream output;
    private RumbleListener rumbleListener;

    public UsbTcpTransport(Context context) {
        this.context = context;
        preferences = new AppPreferences(context);
    }

    @Override
    public void start(OutputProfile outputProfile, Callback transportCallback) {
        profile = outputProfile;
        callback = transportCallback;
        stopped = false;
        worker =
                new Thread(
                        () -> {
                            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                            connectLoop();
                        },
                        "Mangmi-USB-Bridge");
        worker.start();
    }

    private void connectLoop() {
        while (!stopped) {
            DatagramSocket discovery = null;
            try {
                Socket nextSocket = tryConnectLoopback();
                if (nextSocket == null) {
                    reportConnectionHint();
                    discovery = new DatagramSocket();
                    discovery.setBroadcast(true);
                    discovery.setSoTimeout(450);
                    InetSocketAddress server = discover(discovery);
                    if (server == null) {
                        continue;
                    }
                    report("发现电脑，正在建立 USB 通道…", false);
                    nextSocket = new Socket();
                    nextSocket.setTcpNoDelay(true);
                    nextSocket.setKeepAlive(true);
                    nextSocket.connect(server, 3000);
                }

                socket = nextSocket;
                output = nextSocket.getOutputStream();
                synchronized (this) {
                    output.write(
                            ProtocolCodec.encodeHandshake(
                                    preferences.getControllerName()));
                    output.flush();
                }
                report("USB 有线连接就绪", true);
                readFeedback(nextSocket);
            } catch (IOException | RuntimeException exception) {
                if (!stopped) {
                    report("等待电脑端：请开启 USB 网络共享并运行 PC 配套程序", false);
                    pause(1200L);
                }
            } finally {
                output = null;
                closeSocket();
                if (discovery != null) {
                    discovery.close();
                }
            }
        }
    }

    private void readFeedback(Socket activeSocket) throws IOException {
        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                activeSocket.getInputStream(),
                                StandardCharsets.US_ASCII));
        String line;
        while (!stopped && (line = reader.readLine()) != null) {
            parseRumbleLine(line);
        }
    }

    private void parseRumbleLine(String line) {
        String[] parts = line.trim().split("\\s+");
        if (parts.length != 3 || !"LENSRUMBLE".equals(parts[0]) || rumbleListener == null) {
            return;
        }
        try {
            rumbleListener.onRumble(
                    Math.max(0, Math.min(255, Integer.parseInt(parts[1]))),
                    Math.max(0, Math.min(255, Integer.parseInt(parts[2]))));
        } catch (NumberFormatException ignored) {
            // Ignore a malformed feedback line without closing the input channel.
        }
    }

    private Socket tryConnectLoopback() {
        try {
            Socket localSocket = new Socket();
            localSocket.setTcpNoDelay(true);
            localSocket.setKeepAlive(true);
            localSocket.connect(
                    new InetSocketAddress(InetAddress.getLoopbackAddress(), DATA_PORT),
                    700);
            return localSocket;
        } catch (IOException ignored) {
            return null;
        }
    }

    private InetSocketAddress discover(DatagramSocket discovery) throws IOException {
        byte[] payload = DISCOVER_REQUEST.getBytes(StandardCharsets.US_ASCII);
        for (InetAddress address : discoveryAddresses()) {
            try {
                discovery.send(
                        new DatagramPacket(payload, payload.length, address, DISCOVERY_PORT));
            } catch (IOException ignored) {
                // Try the remaining interfaces.
            }
        }

        byte[] responseBuffer = new byte[128];
        long deadline = System.nanoTime() + 2_000_000_000L;
        while (!stopped && System.nanoTime() < deadline) {
            try {
                DatagramPacket response =
                        new DatagramPacket(responseBuffer, responseBuffer.length);
                discovery.receive(response);
                String message =
                        new String(
                                        response.getData(),
                                        response.getOffset(),
                                        response.getLength(),
                                        StandardCharsets.US_ASCII)
                                .trim();
                if (!message.startsWith(DISCOVER_RESPONSE_PREFIX)) {
                    continue;
                }
                int port = DATA_PORT;
                try {
                    port =
                            Integer.parseInt(
                                    message.substring(DISCOVER_RESPONSE_PREFIX.length()).trim());
                } catch (NumberFormatException ignored) {
                    // The default port is used for older companions.
                }
                return new InetSocketAddress(response.getAddress(), port);
            } catch (SocketTimeoutException ignored) {
                // Keep receiving until the discovery deadline.
            }
        }
        return null;
    }

    private List<InetAddress> discoveryAddresses() {
        List<InetAddress> addresses = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces != null) {
                for (NetworkInterface networkInterface : Collections.list(interfaces)) {
                    if (!networkInterface.isUp() || networkInterface.isLoopback()) {
                        continue;
                    }
                    for (InterfaceAddress interfaceAddress :
                            networkInterface.getInterfaceAddresses()) {
                        InetAddress broadcast = interfaceAddress.getBroadcast();
                        if (broadcast instanceof Inet4Address) {
                            addresses.add(broadcast);
                        }
                    }
                }
            }
            InetAddress globalBroadcast = InetAddress.getByName("255.255.255.255");
            if (!addresses.contains(globalBroadcast)) {
                addresses.add(globalBroadcast);
            }
        } catch (IOException ignored) {
            try {
                addresses.add(InetAddress.getByName("255.255.255.255"));
            } catch (IOException ignoredAgain) {
                // An empty list will retry after the transport loop backs off.
            }
        }
        return addresses;
    }

    private void reportConnectionHint() {
        ConnectivityManager manager =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) {
            report("正在搜索电脑：ADB 隧道或 USB 网络共享…", false);
            return;
        }
        Network active = manager.getActiveNetwork();
        NetworkCapabilities capabilities =
                active == null ? null : manager.getNetworkCapabilities(active);
        boolean usbLike =
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                        && capabilities != null
                        && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_USB)
                        && capabilities.hasCapability(
                                NetworkCapabilities.NET_CAPABILITY_INTERNET);
        if (usbLike) {
            report("正在通过 USB 搜索电脑…", false);
        } else {
            report("正在搜索电脑：ADB 隧道或 USB 网络共享…", false);
        }
    }

    @Override
    public void send(ControllerState state, int sequence) {
        Socket activeSocket = socket;
        OutputStream activeOutput = output;
        if (activeSocket == null
                || activeOutput == null
                || activeSocket.isClosed()
                || !activeSocket.isConnected()) {
            return;
        }
        try {
            synchronized (this) {
                activeOutput.write(
                        ProtocolCodec.encode(state, profile, sequence, true));
            }
        } catch (IOException exception) {
            closeSocket();
            throw new IllegalStateException("USB 连接中断", exception);
        }
    }

    @Override
    public void stop() {
        stopped = true;
        closeSocket();
        if (worker != null) {
            worker.interrupt();
            worker = null;
        }
    }

    @Override
    public void setRumbleListener(RumbleListener listener) {
        rumbleListener = listener;
    }

    private void closeSocket() {
        Socket activeSocket = socket;
        socket = null;
        output = null;
        if (activeSocket != null) {
            try {
                activeSocket.close();
            } catch (IOException ignored) {
                // Already closed.
            }
        }
    }

    private void report(String message, boolean connected) {
        if (callback != null && !stopped) {
            callback.onTransportStatus(message, connected);
        }
    }

    private static void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
    }
}
