"use strict";

const {
  discoverBluetoothDevices,
  findAndroidDevices,
} = require("../bluetooth-discovery");

console.log(JSON.stringify(discoverBluetoothDevices(), null, 2));
console.log("Candidates", findAndroidDevices({ includeUnknown: true }));
