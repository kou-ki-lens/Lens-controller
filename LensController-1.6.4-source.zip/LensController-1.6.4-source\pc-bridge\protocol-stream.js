"use strict";

const { PACKET_SIZE } = require("./protocol");

const DEFAULT_CONTROLLER_NAME = "Lens controller";

function createProtocolState() {
  return {
    pending: Buffer.alloc(0),
    handshakeComplete: false,
    packetCount: 0,
  };
}

function parseHandshakeName(line) {
  const match = /^LENS1\s+([A-Za-z0-9+/=]+)$/.exec(line);
  if (!match) {
    return DEFAULT_CONTROLLER_NAME;
  }
  try {
    return (
      Buffer.from(match[1], "base64").toString("utf8").trim() ||
      DEFAULT_CONTROLLER_NAME
    );
  } catch {
    return DEFAULT_CONTROLLER_NAME;
  }
}

function consumeProtocolData(state, chunk, options = {}) {
  const {
    source = "",
    onPacket = () => {},
    onControllerName = () => {},
    log = () => {},
  } = options;

  state.pending = Buffer.concat([state.pending, Buffer.from(chunk)]);
  if (!state.handshakeComplete) {
    if (
      state.pending.length >= 4 &&
      state.pending.subarray(0, 4).equals(Buffer.from("MGB1"))
    ) {
      state.handshakeComplete = true;
    } else if (state.pending.subarray(0, 5).equals(Buffer.from("LENS1"))) {
      const newline = state.pending.indexOf(0x0a);
      if (newline < 0) {
        if (state.pending.length > 4096) {
          throw new Error("手柄名称消息过长");
        }
        return;
      }
      const line = state.pending.subarray(0, newline).toString("ascii").trim();
      const controllerName = parseHandshakeName(line);
      state.pending = state.pending.subarray(newline + 1);
      state.handshakeComplete = true;
      onControllerName(controllerName);
      log(`收到${source}连接，手柄名称：${controllerName}`);
    } else if (state.pending.length >= 5) {
      throw new Error("无法识别输入协议");
    }
  }

  while (state.pending.length >= PACKET_SIZE) {
    const frame = state.pending.subarray(0, PACKET_SIZE);
    state.pending = state.pending.subarray(PACKET_SIZE);
    state.packetCount += 1;
    onPacket(frame, state.packetCount);
  }
}

module.exports = {
  consumeProtocolData,
  createProtocolState,
  parseHandshakeName,
};
