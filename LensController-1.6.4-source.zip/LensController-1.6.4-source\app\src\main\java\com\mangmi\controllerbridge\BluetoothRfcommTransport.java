package com.mangmi.controllerbridge;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;

/**
 * Classic Bluetooth transport used by the PC companion.
 *
 * <p>The phone is an RFCOMM server. The PC companion connects to this service and
 * forwards reports through ViGEm, so Windows sees exactly the same virtual Xbox or
 * DualShock controller as it does in USB mode. No Android Bluetooth HID profile is
 * registered.</p>
 */
public final class BluetoothRfcommTransport implements Transport {
    public static final UUID SERVICE_UUID =
            UUID.fromString("7c6a0001-8f43-4a3f-9a72-4c656e734331");

    private final Context context;
    private final AppPreferences preferences;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean stopped;
    private BluetoothAdapter adapter;
    private BluetoothServerSocket serverSocket;
    private BluetoothSocket activeSocket;
    private OutputStream output;
    private Thread acceptThread;
    private Callback callback;
    private OutputProfile profile = OutputProfile.XBOX;
    private RumbleListener rumbleListener;

    public BluetoothRfcommTransport(Context context) {
        this.context = context;
        preferences = new AppPreferences(context);
    }

    @Override
    public void start(OutputProfile outputProfile, Callback transportCallback) {
        profile = outputProfile;
        callback = transportCallback;
        stopped = false;
        if (!hasConnectPermission()) {
            report("缺少蓝牙权限", false);
            return;
        }

        BluetoothManager manager =
                (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) {
            report("此设备没有蓝牙适配器", false);
            return;
        }
        if (!adapter.isEnabled()) {
            report("请先开启蓝牙", false);
            return;
        }

        String bluetoothName = preferences.getBluetoothName();
        boolean renamed = false;
        try {
            renamed = !bluetoothName.equals(adapter.getName()) && adapter.setName(bluetoothName);
        } catch (SecurityException exception) {
            report("蓝牙权限被拒绝", false);
            return;
        }
        if (renamed) {
            // Android applies the adapter name asynchronously. Opening the RFCOMM
            // service immediately can leave Windows' cached SDP record in a stale
            // state, so give the Bluetooth stack a moment before advertising.
            report("正在应用蓝牙连接名称…", false);
            handler.postDelayed(this::beginListening, 1_200L);
        } else {
            beginListening();
        }
    }

    private void beginListening() {
        if (stopped) {
            return;
        }
        String bluetoothName = preferences.getBluetoothName();
        try {
            serverSocket =
                    adapter.listenUsingInsecureRfcommWithServiceRecord(
                            bluetoothName + " Link", SERVICE_UUID);
        } catch (SecurityException exception) {
            report("蓝牙权限被拒绝", false);
            return;
        } catch (IOException exception) {
            report("无法启动蓝牙手柄服务：" + safeMessage(exception), false);
            return;
        }

        if (hasBondedComputer()) {
            report("蓝牙服务已就绪，正在等待已配对电脑自动连接…", false);
        } else {
            report("未找到已配对电脑，正在进入蓝牙配对模式…", false);
            enableDiscoverable();
        }

        acceptThread =
                new Thread(
                        () -> {
                            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                            acceptLoop();
                        },
                        "Lens-Bluetooth-RFCOMM");
        acceptThread.start();
    }

    private void acceptLoop() {
        while (!stopped) {
            try {
                BluetoothSocket socket = serverSocket.accept();
                if (stopped) {
                    closeSocket(socket);
                    return;
                }
                synchronized (this) {
                    activeSocket = socket;
                    output = socket.getOutputStream();
                    output.write(
                            ProtocolCodec.encodeHandshake(
                                    preferences.getControllerName()));
                    output.flush();
                }
                handler.removeCallbacksAndMessages(null);
                report("蓝牙已连接电脑" + deviceLabel(socket.getRemoteDevice()), true);
                monitorConnection(socket);
            } catch (SecurityException exception) {
                report("蓝牙连接权限已失效", false);
                return;
            } catch (IOException exception) {
                if (!stopped) {
                    report("蓝牙等待电脑重新连接…", false);
                }
            } finally {
                synchronized (this) {
                    activeSocket = null;
                    output = null;
                }
            }
        }
    }

    private void monitorConnection(BluetoothSocket socket) {
        try {
            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    socket.getInputStream(),
                                    StandardCharsets.US_ASCII));
            String line;
            while (!stopped && (line = reader.readLine()) != null) {
                parseRumbleLine(line);
            }
        } catch (IOException ignored) {
            // Falling through reports the reconnect state below.
        }
        closeSocket(socket);
        if (!stopped) {
            report("电脑已断开，等待自动重连…", false);
        }
    }

    private void parseRumbleLine(String line) {
        String[] parts = line.trim().split("\\s+");
        if (parts.length != 3 || !"LENSRUMBLE".equals(parts[0]) || rumbleListener == null) {
            return;
        }
        try {
            rumbleListener.onRumble(
                    Math.max(0, Math.min(255, Integer.parseInt(parts[1]))),
                    Math.max(0, Math.min(255, Integer.parseInt(parts[2]))));
        } catch (NumberFormatException ignored) {
            // Ignore malformed feedback and keep the RFCOMM link open.
        }
    }

    @Override
    public void send(ControllerState state, int sequence) {
        BluetoothSocket socket = activeSocket;
        OutputStream activeOutput = output;
        if (socket == null || activeOutput == null || !socket.isConnected()) {
            return;
        }
        try {
            synchronized (this) {
                activeOutput.write(
                        ProtocolCodec.encode(state, profile, sequence, true));
            }
        } catch (IOException exception) {
            closeSocket(socket);
            throw new IllegalStateException("蓝牙连接中断", exception);
        }
    }

    @Override
    public void stop() {
        stopped = true;
        handler.removeCallbacksAndMessages(null);
        BluetoothServerSocket listener = serverSocket;
        serverSocket = null;
        if (listener != null) {
            try {
                listener.close();
            } catch (IOException ignored) {
                // Already closed.
            }
        }
        BluetoothSocket socket;
        synchronized (this) {
            socket = activeSocket;
            activeSocket = null;
            output = null;
        }
        closeSocket(socket);
        if (acceptThread != null) {
            acceptThread.interrupt();
            acceptThread = null;
        }
    }

    @Override
    public void setRumbleListener(RumbleListener listener) {
        rumbleListener = listener;
    }

    private boolean hasBondedComputer() {
        if (!hasConnectPermission() || adapter == null) {
            return false;
        }
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            for (BluetoothDevice device : bonded) {
                BluetoothClass bluetoothClass = device.getBluetoothClass();
                if (bluetoothClass == null) {
                    continue;
                }
                int majorClass = bluetoothClass.getMajorDeviceClass();
                if (majorClass == BluetoothClass.Device.Major.COMPUTER) {
                    return true;
                }
                String name = safeDeviceName(device).toUpperCase();
                if (name.contains("LAPTOP")
                        || name.contains("DESKTOP")
                        || name.contains("PC-")
                        || name.contains("WINDOWS")
                        || name.contains("COMPUTER")
                        || name.contains("电脑")) {
                    return true;
                }
            }
        } catch (SecurityException ignored) {
            return false;
        }
        return false;
    }

    private void enableDiscoverable() {
        if (!hasConnectPermission()) {
            return;
        }
        try {
            Intent discoverable =
                    new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverable.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 180);
            discoverable.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(discoverable);
        } catch (SecurityException ignored) {
            report("请在系统蓝牙设置中将本机设为可被发现", false);
        } catch (RuntimeException ignored) {
            report("请在系统蓝牙设置中将本机设为可被发现", false);
        }
    }

    private boolean hasConnectPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return true;
        }
        return context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void report(String message, boolean connected) {
        if (callback != null && !stopped) {
            callback.onTransportStatus(message, connected);
        }
    }

    private static String deviceLabel(BluetoothDevice device) {
        try {
            String name = device.getName();
            return name == null || name.isBlank() ? "" : "：" + name;
        } catch (SecurityException ignored) {
            return "";
        }
    }

    private static String safeDeviceName(BluetoothDevice device) {
        try {
            String name = device.getName();
            return name == null ? "" : name;
        } catch (SecurityException ignored) {
            return "";
        }
    }

    private static void closeSocket(BluetoothSocket socket) {
        if (socket == null) {
            return;
        }
        try {
            socket.close();
        } catch (IOException ignored) {
            // Already closed.
        }
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
    }
}
