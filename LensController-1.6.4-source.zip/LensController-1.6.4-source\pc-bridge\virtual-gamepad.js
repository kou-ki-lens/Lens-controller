"use strict";

const koffi = require("koffi");
const path = require("node:path");

const VIGEM_SUCCESS = 0x20000000;
const ERROR_NAMES = new Map([
  [0xe0000001, "ViGEmBus 驱动未安装"],
  [0xe0000002, "没有空闲的虚拟手柄插槽"],
  [0xe0000003, "虚拟手柄目标无效"],
  [0xe0000004, "移除虚拟手柄失败"],
  [0xe0000005, "虚拟手柄已经连接"],
  [0xe0000006, "虚拟手柄尚未初始化"],
  [0xe0000008, "ViGEmBus 驱动版本不匹配"],
  [0xe0000009, "无权访问 ViGEmBus 驱动"],
]);

const XUSB = Object.freeze({
  DPAD_UP: 0x0001,
  DPAD_DOWN: 0x0002,
  DPAD_LEFT: 0x0004,
  DPAD_RIGHT: 0x0008,
  START: 0x0010,
  BACK: 0x0020,
  LS: 0x0040,
  RS: 0x0080,
  LB: 0x0100,
  RB: 0x0200,
  GUIDE: 0x0400,
  A: 0x1000,
  B: 0x2000,
  X: 0x4000,
  Y: 0x8000,
});

let xusbReportType;
let ds4ReportExType;
let x360NotificationType;

function getXusbReportType() {
  if (!xusbReportType) {
    xusbReportType = koffi.struct("LENS_XUSB_REPORT", {
      wButtons: "uint16",
      bLeftTrigger: "uint8",
      bRightTrigger: "uint8",
      sThumbLX: "int16",
      sThumbLY: "int16",
      sThumbRX: "int16",
      sThumbRY: "int16",
    });
  }
  return xusbReportType;
}

function getDs4ReportExType() {
  if (!ds4ReportExType) {
    const fields = koffi.pack("LENS_DS4_REPORT_FIELDS", {
      bThumbLX: "uint8",
      bThumbLY: "uint8",
      bThumbRX: "uint8",
      bThumbRY: "uint8",
      wButtons: "uint16",
      bSpecial: "uint8",
      bTriggerL: "uint8",
      bTriggerR: "uint8",
      wTimestamp: "uint16",
      bBatteryLvl: "uint8",
      wGyroX: "int16",
      wGyroY: "int16",
      wGyroZ: "int16",
      wAccelX: "int16",
      wAccelY: "int16",
      wAccelZ: "int16",
      unknown1: koffi.array("uint8", 5),
      bBatteryLvlSpecial: "uint8",
      unknown2: koffi.array("uint8", 2),
      bTouchPacketsN: "uint8",
      touch: koffi.array("uint8", 27),
      padding: koffi.array("uint8", 3),
    });
    ds4ReportExType = koffi.union("LENS_DS4_REPORT_EX", {
      Report: fields,
      ReportBuffer: koffi.array("uint8", 63),
    });
  }
  return ds4ReportExType;
}

function getX360NotificationType() {
  if (!x360NotificationType) {
    x360NotificationType = koffi.proto(
      "__stdcall",
      "LENS_X360_NOTIFICATION",
      "void",
      ["void *", "void *", "uint8", "uint8", "uint8", "void *"],
    );
  }
  return x360NotificationType;
}

class VirtualGamepad {
  constructor(profile, onVibration = () => {}, options = {}) {
    this.profile = profile;
    this.onVibration = onVibration;
    this.enableNotifications = options.enableNotifications !== false;
    this.dualShock = null;
    this.client = null;
    this.target = null;
    this.lib = null;
  }

  connect() {
    if (this.profile !== 0) {
      const { DualShockGamepad } = require("./dualshock-gamepad");
      this.dualShock = new DualShockGamepad(
        this.onVibration,
        toDs4ExtendedReport,
        { enableNotifications: this.enableNotifications },
      );
      this.dualShock.connect();
      return;
    }

    const dllPath = path.join(__dirname, "native", "ViGEmClient.dll");
    this.lib = koffi.load(dllPath);
    this.allocClient = this.lib.func("vigem_alloc", "void *", []);
    this.connectClient = this.lib.func("vigem_connect", "int", ["void *"]);
    this.disconnectClient = this.lib.func("vigem_disconnect", "void", ["void *"]);
    this.freeClient = this.lib.func("vigem_free", "void", ["void *"]);
    this.allocX360 = this.lib.func("vigem_target_x360_alloc", "void *", []);
    this.addTarget = this.lib.func("vigem_target_add", "int", ["void *", "void *"]);
    this.removeTarget = this.lib.func("vigem_target_remove", "int", ["void *", "void *"]);
    this.freeTarget = this.lib.func("vigem_target_free", "void", ["void *"]);
    this.updateX360 = this.lib.func("vigem_target_x360_update", "int", [
      "void *",
      "void *",
      getXusbReportType(),
    ]);
    this.client = this.allocClient();
    if (!this.client) {
      throw new Error("无法创建 ViGEm 客户端");
    }
    this.checkResult(this.connectClient(this.client), "连接 ViGEmBus");

    this.target = this.allocX360();
    if (!this.target) {
      throw new Error("无法创建虚拟手柄对象");
    }
    let addResult = this.addTarget(this.client, this.target);
    for (let retry = 0; (addResult >>> 0) === 0xe0000007 && retry < 5; retry += 1) {
      sleepSync(120);
      addResult = this.addTarget(this.client, this.target);
    }
    this.checkResult(addResult, "插入虚拟手柄");
    if (!this.enableNotifications) {
      this.notificationCallback = null;
    } else {
      const X360_NOTIFICATION = getX360NotificationType();
      this.registerX360Notification = this.lib.func(
        "vigem_target_x360_register_notification",
        "int",
        ["void *", "void *", "LENS_X360_NOTIFICATION *", "void *"],
      );
      this.unregisterX360Notification = this.lib.func(
        "vigem_target_x360_unregister_notification",
        "void",
        ["void *"],
      );
      this.notificationCallback = koffi.register(
        (client, target, largeMotor, smallMotor) => {
          this.onVibration(largeMotor, smallMotor);
        },
        koffi.pointer(X360_NOTIFICATION),
      );
      this.checkResult(
        this.registerX360Notification(
          this.client,
          this.target,
          this.notificationCallback,
          null,
        ),
        "注册 Xbox 震动通知",
      );
    }
  }

  update(input) {
    if (this.dualShock) {
      this.dualShock.update(input);
      return;
    }
    if (!this.target) {
      return;
    }
    this.checkResult(
      this.updateX360(this.client, this.target, toXusbReport(input)),
      "更新 Xbox 360 状态",
    );
  }

  disconnect() {
    if (this.dualShock) {
      this.dualShock.disconnect();
      this.dualShock = null;
      return;
    }
    if (this.target && this.unregisterX360Notification) {
      this.unregisterX360Notification(this.target);
    }
    if (this.notificationCallback) {
      koffi.unregister(this.notificationCallback);
      this.notificationCallback = null;
    }
    if (this.client && this.target && this.removeTarget) {
      try {
        this.removeTarget(this.client, this.target);
      } catch {
        // The driver removes orphaned targets when the process exits.
      }
    }
    if (this.target && this.freeTarget) {
      this.freeTarget(this.target);
    }
    this.target = null;
    if (this.client && this.disconnectClient) {
      this.disconnectClient(this.client);
    }
    if (this.client && this.freeClient) {
      this.freeClient(this.client);
    }
    this.client = null;
  }

  checkResult(result, operation) {
    if ((result >>> 0) === VIGEM_SUCCESS) {
      return;
    }
    const code = result >>> 0;
    const reason = ERROR_NAMES.get(code) || `错误 0x${code.toString(16)}`;
    throw new Error(`${operation}失败：${reason}`);
  }
}

function signedAxisToXusb(value) {
  const normalized = Math.max(-127, Math.min(127, value)) / 127;
  return Math.round(normalized * 32767);
}

function signedAxisToDs4(value) {
  const normalized = Math.max(-127, Math.min(127, value)) / 127;
  return Math.max(0, Math.min(255, Math.round(128 + normalized * 127)));
}

function has(input, mask) {
  return (input.buttons & mask) !== 0;
}

function toXusbReport(input) {
  let buttons = 0;
  if (has(input, 1)) buttons |= XUSB.A;
  if (has(input, 1 << 1)) buttons |= XUSB.B;
  if (has(input, 1 << 2)) buttons |= XUSB.X;
  if (has(input, 1 << 3)) buttons |= XUSB.Y;
  if (has(input, 1 << 4)) buttons |= XUSB.LB;
  if (has(input, 1 << 5)) buttons |= XUSB.RB;
  if (has(input, 1 << 6)) buttons |= XUSB.BACK;
  if (has(input, 1 << 7)) buttons |= XUSB.START;
  if (has(input, 1 << 8)) buttons |= XUSB.GUIDE;
  if (has(input, 1 << 9)) buttons |= XUSB.LS;
  if (has(input, 1 << 10)) buttons |= XUSB.RS;
  if (has(input, 1 << 11)) buttons |= XUSB.DPAD_UP;
  if (has(input, 1 << 12)) buttons |= XUSB.DPAD_DOWN;
  if (has(input, 1 << 13)) buttons |= XUSB.DPAD_LEFT;
  if (has(input, 1 << 14)) buttons |= XUSB.DPAD_RIGHT;
  return {
    wButtons: buttons,
    bLeftTrigger: input.leftTrigger,
    bRightTrigger: input.rightTrigger,
    sThumbLX: signedAxisToXusb(input.leftX),
    // Android joystick Y is positive downward; XInput considers positive Y upward.
    sThumbLY: signedAxisToXusb(-input.leftY),
    sThumbRX: signedAxisToXusb(input.rightX),
    sThumbRY: signedAxisToXusb(-input.rightY),
  };
}

function toDs4Report(input) {
  let buttons = dpadValue(input.buttons);
  if (has(input, 1)) buttons |= 1 << 5;
  if (has(input, 1 << 1)) buttons |= 1 << 6;
  if (has(input, 1 << 2)) buttons |= 1 << 4;
  if (has(input, 1 << 3)) buttons |= 1 << 7;
  if (has(input, 1 << 4)) buttons |= 1 << 8;
  if (has(input, 1 << 5)) buttons |= 1 << 9;
  if (input.leftTrigger > 0) buttons |= 1 << 10;
  if (input.rightTrigger > 0) buttons |= 1 << 11;
  if (has(input, 1 << 6)) buttons |= 1 << 12;
  if (has(input, 1 << 7)) buttons |= 1 << 13;
  if (has(input, 1 << 9)) buttons |= 1 << 14;
  if (has(input, 1 << 10)) buttons |= 1 << 15;

  let special = 0;
  if (has(input, 1 << 8)) special |= 1;
  return {
    bThumbLX: signedAxisToDs4(input.leftX),
    bThumbLY: signedAxisToDs4(input.leftY),
    bThumbRX: signedAxisToDs4(input.rightX),
    bThumbRY: signedAxisToDs4(input.rightY),
    wButtons: buttons,
    bSpecial: special,
    bTriggerL: input.leftTrigger,
    bTriggerR: input.rightTrigger,
  };
}

function toDs4ExtendedReport(input) {
  const base = toDs4Report(input);
  const hasTouch =
    (input.touch1Id ?? -1) >= 0 || (input.touch2Id ?? -1) >= 0;
  const touchClick = Boolean(input.touchClick);
  const touch = encodeTouchPoint(input, touchClick);
  return {
    Report: {
      bThumbLX: base.bThumbLX,
      bThumbLY: base.bThumbLY,
      bThumbRX: base.bThumbRX,
      bThumbRY: base.bThumbRY,
      wButtons: base.wButtons,
      bSpecial: base.bSpecial | (touchClick ? 1 << 1 : 0),
      bTriggerL: base.bTriggerL,
      bTriggerR: base.bTriggerR,
      wTimestamp: Date.now() & 0xffff,
      bBatteryLvl: encodeDs4BatteryLevel(input.batteryPercent, input.charging),
      bBatteryLvlSpecial: 0,
      bTouchPacketsN: hasTouch ? 1 : 0,
      touch: encodeTouchBytes(touch),
      padding: [0, 0, 0],
    },
  };
}

function encodeTouchBytes(touch) {
  return [
    touch.bPacketCounter,
    touch.bIsUpTrackingNum1,
    ...touch.bTouchData1,
    touch.bIsUpTrackingNum2,
    ...touch.bTouchData2,
    ...new Array(18).fill(0),
  ];
}

function encodeDs4BatteryLevel(percent, charging) {
  if (!Number.isFinite(percent) || percent < 0) {
    // A valid full value prevents Windows from raising a false 0% warning
    // before Android supplies its first battery reading.
    return 0x0a;
  }
  const capacity = Math.max(0, Math.min(10, Math.round(percent / 10)));
  const powerState = charging ? (percent >= 99 ? 2 : 1) : 0;
  return (powerState << 4) | capacity;
}

function encodeTouchPoint(input, active) {
  const firstId = Math.max(0, input.touch1Id ?? 0) & 0x7f;
  const secondId = Math.max(0, input.touch2Id ?? 0) & 0x7f;
  return {
    bPacketCounter: (input.sequence ?? 0) & 0xff,
    bIsUpTrackingNum1:
      input.touch1Active ? firstId : 0x80 | firstId,
    bTouchData1: encodeTouchCoordinates(input.touch1X ?? 0, input.touch1Y ?? 0),
    bIsUpTrackingNum2:
      input.touch2Active ? secondId : 0x80 | secondId,
    bTouchData2: encodeTouchCoordinates(input.touch2X ?? 0, input.touch2Y ?? 0),
  };
}

function encodeTouchCoordinates(x, y) {
  const clampedX = Math.max(0, Math.min(1919, x));
  const clampedY = Math.max(0, Math.min(942, y));
  return [
    clampedX & 0xff,
    ((clampedX >> 8) & 0x0f) | ((clampedY & 0x0f) << 4),
    (clampedY >> 4) & 0xff,
  ];
}

function dpadValue(buttons) {
  const up = (buttons & (1 << 11)) !== 0;
  const right = (buttons & (1 << 14)) !== 0;
  const down = (buttons & (1 << 12)) !== 0;
  const left = (buttons & (1 << 13)) !== 0;
  if (up && right) return 1;
  if (right && down) return 3;
  if (down && left) return 5;
  if (left && up) return 7;
  if (up) return 0;
  if (right) return 2;
  if (down) return 4;
  if (left) return 6;
  return 8;
}

function sleepSync(milliseconds) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, milliseconds);
}

module.exports = {
  VirtualGamepad,
  toXusbReport,
  toDs4Report,
  toDs4ExtendedReport,
  encodeTouchBytes,
  encodeDs4BatteryLevel,
  encodeTouchCoordinates,
  getDs4ReportExType,
  signedAxisToXusb,
  signedAxisToDs4,
};
