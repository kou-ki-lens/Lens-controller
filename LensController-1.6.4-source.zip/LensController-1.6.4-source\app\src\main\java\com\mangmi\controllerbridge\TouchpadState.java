package com.mangmi.controllerbridge;

public final class TouchpadState {
    public static final TouchpadState NONE =
            new TouchpadState(false, -1, 0, 0, false, -1, 0, 0, false);

    public final boolean touch1Active;
    public final int touch1Id;
    public final int touch1X;
    public final int touch1Y;
    public final boolean touch2Active;
    public final int touch2Id;
    public final int touch2X;
    public final int touch2Y;
    public final boolean clickActive;

    public TouchpadState(
            boolean touch1Active,
            int touch1Id,
            int touch1X,
            int touch1Y,
            boolean touch2Active,
            int touch2Id,
            int touch2X,
            int touch2Y) {
        this(
                touch1Active,
                touch1Id,
                touch1X,
                touch1Y,
                touch2Active,
                touch2Id,
                touch2X,
                touch2Y,
                false);
    }

    public TouchpadState(
            boolean touch1Active,
            int touch1Id,
            int touch1X,
            int touch1Y,
            boolean touch2Active,
            int touch2Id,
            int touch2X,
            int touch2Y,
            boolean clickActive) {
        this.touch1Active = touch1Active;
        this.touch1Id = clampId(touch1Id);
        this.touch1X = clamp(touch1X, 0, 1919);
        this.touch1Y = clamp(touch1Y, 0, 942);
        this.touch2Active = touch2Active;
        this.touch2Id = clampId(touch2Id);
        this.touch2X = clamp(touch2X, 0, 1919);
        this.touch2Y = clamp(touch2Y, 0, 942);
        this.clickActive = clickActive;
    }

    public boolean hasTouchReport() {
        return touch1Id >= 0 || touch2Id >= 0;
    }

    private static int clampId(int value) {
        return value < 0 ? -1 : Math.min(127, value);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
