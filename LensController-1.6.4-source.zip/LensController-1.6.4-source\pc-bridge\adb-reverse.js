"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");

const DEVICE_PORT = 47654;
const HOST_PORT = 47654;

function findAdb() {
  if (process.platform !== "win32") {
    return null;
  }
  const bundled = path.join(__dirname, "adb", "adb.exe");
  if (fs.existsSync(bundled)) {
    return bundled;
  }
  const result = spawnSync("where.exe", ["adb.exe"], {
    encoding: "utf8",
    windowsHide: true,
  });
  if (result.status !== 0) {
    return null;
  }
  return result.stdout.split(/\r?\n/).find(Boolean) || null;
}

function startAdbReverse(log) {
  if (process.platform !== "win32") {
    return () => {};
  }
  const adb = findAdb();
  if (!adb) {
    log("未找到 ADB；USB 模式将仅尝试 USB 网络共享");
    return () => {};
  }

  const runAdb = (args) =>
    spawnSync(adb, args, {
      encoding: "utf8",
      windowsHide: true,
      timeout: 5000,
    });

  runAdb(["start-server"]);
  const configured = new Set();
  let lastMissingLog = 0;

  const configure = () => {
    const result = runAdb(["devices"]);
    if (result.status !== 0) {
      return;
    }
    const serials = result.stdout
      .split(/\r?\n/)
      .map((line) => line.trim().split(/\s+/))
      .filter((parts) => parts.length >= 2 && parts[1] === "device")
      .map((parts) => parts[0]);

    if (serials.length === 0) {
      if (Date.now() - lastMissingLog > 30_000) {
        log("ADB 隧道等待掌机：请连接 USB 并允许 USB 调试");
        lastMissingLog = Date.now();
      }
      configured.clear();
      return;
    }

    for (const serial of serials) {
      const result = runAdb([
        "-s",
        serial,
        "reverse",
        `tcp:${DEVICE_PORT}`,
        `tcp:${HOST_PORT}`,
      ]);
      if (result.status === 0 && !configured.has(serial)) {
        configured.add(serial);
        log(`ADB 有线隧道已就绪：${serial}`);
      }
    }
  };

  configure();
  const timer = setInterval(configure, 3000);
  timer.unref();

  return () => {
    clearInterval(timer);
    for (const serial of configured) {
      runAdb([
        "-s",
        serial,
        "reverse",
        "--remove",
        `tcp:${DEVICE_PORT}`,
      ]);
    }
  };
}

module.exports = { startAdbReverse, findAdb };
