package com.mangmi.controllerbridge;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class AppPreferences {
    private static final String PREFS_NAME = "lens_controller";
    private static final String KEY_DEAD_ZONE = "stick_dead_zone";
    private static final String KEY_CAL_MIN = "cal_min_";
    private static final String KEY_CAL_MAX = "cal_max_";
    private static final String KEY_CAL_CENTER = "cal_center_";
    private static final String KEY_ACTIVE_LAYOUT = "active_layout";
    private static final String KEY_CUSTOM_LAYOUTS = "custom_layouts";
    private static final String KEY_PRESET_LAYOUTS = "preset_layouts";
    private static final String KEY_SCREENSAVER = "screensaver_uris";
    private static final String KEY_SCREENSAVER_INTERVAL = "screensaver_interval_seconds";
    private static final String KEY_SCREENSAVER_RANDOM = "screensaver_random";
    private static final String KEY_SCREENSAVER_EXIT_TAPS = "screensaver_exit_taps";
    private static final String KEY_SCREENSAVER_GAMEPAD_EXIT_CONFIGURED =
            "screensaver_gamepad_exit_configured";
    private static final String KEY_SCREENSAVER_GAMEPAD_EXIT_METHOD =
            "screensaver_gamepad_exit_method";
    private static final String KEY_SCREENSAVER_GAMEPAD_EXIT_KEY =
            "screensaver_gamepad_exit_key";
    private static final String KEY_SCREENSAVER_GAMEPAD_EXIT_COUNT =
            "screensaver_gamepad_exit_count";
    private static final String KEY_SCREENSAVER_GAMEPAD_EXIT_HOLD_SECONDS =
            "screensaver_gamepad_exit_hold_seconds";
    private static final String KEY_BLUETOOTH_NAME = "bluetooth_name";
    private static final String KEY_CONTROLLER_NAME = "controller_name";
    private static final String KEY_INVERT_LEFT_X = "invert_left_x";
    private static final String KEY_INVERT_LEFT_Y = "invert_left_y";
    private static final String KEY_INVERT_RIGHT_X = "invert_right_x";
    private static final String KEY_INVERT_RIGHT_Y = "invert_right_y";
    private static final String KEY_SWAP_STICKS = "swap_sticks";
    private static final String KEY_VIBRATION_ENABLED = "vibration_enabled";
    public static final String STANDARD_LAYOUT = "标准布局";
    public static final String XBOX_PRESET_LAYOUT = "Xbox 360 预设";
    public static final String DS4_PRESET_LAYOUT = "DualShock 4 预设";
    private static final String LEGACY_DUALSENSE_PRESET_LAYOUT = "DualSense 5 预设";
    public static final String GAMEPAD_EXIT_PRESS = "press";
    public static final String GAMEPAD_EXIT_HOLD = "hold";
    public static final String GAMEPAD_EXIT_START = "start";
    public static final String GAMEPAD_EXIT_HOME = "home";
    public static final String GAMEPAD_EXIT_SELECT = "select";

    private final SharedPreferences preferences;

    public AppPreferences(Context context) {
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        removeLegacyDualSensePreset();
    }

    public int getDeadZonePercent() {
        return preferences.getInt(KEY_DEAD_ZONE, 8);
    }

    public void setDeadZonePercent(int percent) {
        preferences.edit().putInt(KEY_DEAD_ZONE, Math.max(1, Math.min(30, percent))).apply();
    }

    public StickCalibration getCalibration() {
        return new StickCalibration(
                readAxis("lx"),
                readAxis("ly"),
                readAxis("rx"),
                readAxis("ry"));
    }

    public void saveCalibration(StickCalibration calibration) {
        SharedPreferences.Editor editor = preferences.edit();
        writeAxis(editor, "lx", calibration.leftX);
        writeAxis(editor, "ly", calibration.leftY);
        writeAxis(editor, "rx", calibration.rightX);
        writeAxis(editor, "ry", calibration.rightY);
        editor.apply();
    }

    public boolean isCalibrated() {
        StickCalibration calibration = getCalibration();
        return !isDefaultAxis(calibration.leftX)
                || !isDefaultAxis(calibration.leftY)
                || !isDefaultAxis(calibration.rightX)
                || !isDefaultAxis(calibration.rightY);
    }

    public String getActiveLayoutName() {
        return preferences.getString(KEY_ACTIVE_LAYOUT, STANDARD_LAYOUT);
    }

    public void setActiveLayout(String name) {
        preferences.edit().putString(KEY_ACTIVE_LAYOUT, name).apply();
    }

    public Map<Integer, Integer> getActiveMapping() {
        String active = getActiveLayoutName();
        if (STANDARD_LAYOUT.equals(active)) {
            return ButtonMapping.standard();
        }
        if (isPresetLayout(active)) {
            Map<Integer, Integer> preset = getPresetLayouts().get(active);
            return preset == null ? ButtonMapping.standard() : preset;
        }
        Map<Integer, Integer> mapping = getCustomLayouts().get(active);
        return mapping == null ? ButtonMapping.standard() : mapping;
    }

    public List<String> getLayoutNames() {
        List<String> names = new ArrayList<>();
        names.addAll(getCustomLayouts().keySet());
        return names;
    }

    public static String presetLayoutName(OutputProfile profile) {
        if (profile == OutputProfile.DUALSHOCK_4) {
            return DS4_PRESET_LAYOUT;
        }
        return XBOX_PRESET_LAYOUT;
    }

    public static boolean isPresetLayout(String name) {
        return XBOX_PRESET_LAYOUT.equals(name)
                || DS4_PRESET_LAYOUT.equals(name)
                || STANDARD_LAYOUT.equals(name);
    }

    public Map<Integer, Integer> getPresetMapping(OutputProfile profile) {
        String name = presetLayoutName(profile);
        Map<Integer, Integer> mapping = getPresetLayouts().get(name);
        return mapping == null ? ButtonMapping.standard() : mapping;
    }

    public void savePresetMapping(OutputProfile profile, Map<Integer, Integer> mapping) {
        Map<String, Map<Integer, Integer>> presets = getPresetLayouts();
        presets.put(presetLayoutName(profile), new LinkedHashMap<>(mapping));
        writeLayouts(KEY_PRESET_LAYOUTS, presets);
    }

    public Map<String, Map<Integer, Integer>> getCustomLayouts() {
        return readLayouts(KEY_CUSTOM_LAYOUTS);
    }

    public Map<String, Map<Integer, Integer>> getPresetLayouts() {
        return readLayouts(KEY_PRESET_LAYOUTS);
    }

    private Map<String, Map<Integer, Integer>> readLayouts(String preferenceKey) {
        LinkedHashMap<String, Map<Integer, Integer>> result = new LinkedHashMap<>();
        String raw = preferences.getString(preferenceKey, "{}");
        try {
            JSONObject root = new JSONObject(raw);
            Iterator<String> names = root.keys();
            while (names.hasNext()) {
                String name = names.next();
                JSONObject encoded = root.getJSONObject(name);
                LinkedHashMap<Integer, Integer> mapping = new LinkedHashMap<>();
                Iterator<String> keys = encoded.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    mapping.put(Integer.parseInt(key), encoded.getInt(key));
                }
                result.put(name, mapping);
            }
        } catch (JSONException ignored) {
            // A malformed layout is ignored and the standard mapping remains available.
        }
        return result;
    }

    public void saveCustomLayout(String name, Map<Integer, Integer> mapping) {
        Map<String, Map<Integer, Integer>> layouts = getCustomLayouts();
        layouts.put(name, new LinkedHashMap<>(mapping));
        writeLayouts(KEY_CUSTOM_LAYOUTS, layouts);
    }

    public boolean hasCustomLayout(String name) {
        return getCustomLayouts().containsKey(name);
    }

    public List<String> getScreensaverUris() {
        String raw = preferences.getString(KEY_SCREENSAVER, "[]");
        List<String> result = new ArrayList<>();
        try {
            org.json.JSONArray array = new org.json.JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                String uri = array.optString(i);
                if (!uri.isBlank()) {
                    result.add(uri);
                }
            }
        } catch (JSONException ignored) {
            return Collections.emptyList();
        }
        return result;
    }

    public void setScreensaverUris(List<String> uris) {
        org.json.JSONArray array = new org.json.JSONArray();
        for (String uri : uris) {
            if (uri != null && !uri.isBlank()) {
                array.put(uri);
            }
        }
        preferences.edit().putString(KEY_SCREENSAVER, array.toString()).apply();
    }

    public void resetScreensaver() {
        preferences.edit().remove(KEY_SCREENSAVER).apply();
    }

    public int getScreensaverIntervalSeconds() {
        return Math.max(2, Math.min(60, preferences.getInt(KEY_SCREENSAVER_INTERVAL, 8)));
    }

    public void setScreensaverIntervalSeconds(int seconds) {
        preferences.edit().putInt(KEY_SCREENSAVER_INTERVAL, Math.max(2, Math.min(60, seconds))).apply();
    }

    public boolean isScreensaverRandom() {
        return preferences.getBoolean(KEY_SCREENSAVER_RANDOM, false);
    }

    public void setScreensaverRandom(boolean random) {
        preferences.edit().putBoolean(KEY_SCREENSAVER_RANDOM, random).apply();
    }

    public int getScreensaverExitTaps() {
        return Math.max(3, Math.min(20, preferences.getInt(KEY_SCREENSAVER_EXIT_TAPS, 3)));
    }

    public void setScreensaverExitTaps(int taps) {
        preferences.edit().putInt(KEY_SCREENSAVER_EXIT_TAPS, Math.max(3, Math.min(20, taps))).apply();
    }

    public boolean isScreensaverGamepadExitConfigured() {
        return preferences.getBoolean(KEY_SCREENSAVER_GAMEPAD_EXIT_CONFIGURED, false);
    }

    public String getScreensaverGamepadExitMethod() {
        return GAMEPAD_EXIT_HOLD.equals(
                        preferences.getString(KEY_SCREENSAVER_GAMEPAD_EXIT_METHOD, GAMEPAD_EXIT_PRESS))
                ? GAMEPAD_EXIT_HOLD
                : GAMEPAD_EXIT_PRESS;
    }

    public String getScreensaverGamepadExitKey() {
        String value =
                preferences.getString(KEY_SCREENSAVER_GAMEPAD_EXIT_KEY, GAMEPAD_EXIT_START);
        if (GAMEPAD_EXIT_HOME.equals(value) || GAMEPAD_EXIT_SELECT.equals(value)) {
            return value;
        }
        return GAMEPAD_EXIT_START;
    }

    public int getScreensaverGamepadExitCount() {
        return Math.max(
                2,
                Math.min(10, preferences.getInt(KEY_SCREENSAVER_GAMEPAD_EXIT_COUNT, 3)));
    }

    public int getScreensaverGamepadExitHoldSeconds() {
        return Math.max(
                1,
                Math.min(10, preferences.getInt(KEY_SCREENSAVER_GAMEPAD_EXIT_HOLD_SECONDS, 3)));
    }

    public void configureScreensaverGamepadExit(
            String method, String key, int count, int holdSeconds) {
        preferences
                .edit()
                .putBoolean(KEY_SCREENSAVER_GAMEPAD_EXIT_CONFIGURED, true)
                .putString(
                        KEY_SCREENSAVER_GAMEPAD_EXIT_METHOD,
                        GAMEPAD_EXIT_HOLD.equals(method) ? GAMEPAD_EXIT_HOLD : GAMEPAD_EXIT_PRESS)
                .putString(
                        KEY_SCREENSAVER_GAMEPAD_EXIT_KEY,
                        GAMEPAD_EXIT_HOME.equals(key) || GAMEPAD_EXIT_SELECT.equals(key)
                                ? key
                                : GAMEPAD_EXIT_START)
                .putInt(
                        KEY_SCREENSAVER_GAMEPAD_EXIT_COUNT,
                        Math.max(2, Math.min(10, count)))
                .putInt(
                        KEY_SCREENSAVER_GAMEPAD_EXIT_HOLD_SECONDS,
                        Math.max(1, Math.min(10, holdSeconds)))
                .apply();
    }

    public String screensaverGamepadExitSummary() {
        if (!isScreensaverGamepadExitConfigured()) {
            return "未设置 · 禁止进入屏保";
        }
        String key =
                switch (getScreensaverGamepadExitKey()) {
                    case GAMEPAD_EXIT_HOME -> "Home/Mode";
                    case GAMEPAD_EXIT_SELECT -> "Select";
                    default -> "Start";
                };
        if (GAMEPAD_EXIT_HOLD.equals(getScreensaverGamepadExitMethod())) {
            return "长按 " + key + " " + getScreensaverGamepadExitHoldSeconds() + " 秒";
        }
        return "连按 " + key + " " + getScreensaverGamepadExitCount() + " 次";
    }

    public boolean isVibrationEnabled() {
        return preferences.getBoolean(KEY_VIBRATION_ENABLED, true);
    }

    public void setVibrationEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_VIBRATION_ENABLED, enabled).apply();
    }

    public String getBluetoothName() {
        String value = preferences.getString(KEY_BLUETOOTH_NAME, "Lens controller");
        return value == null || value.isBlank() ? "Lens controller" : value;
    }

    public void setBluetoothName(String name) {
        String value = name == null || name.isBlank() ? "Lens controller" : name.trim();
        preferences.edit().putString(KEY_BLUETOOTH_NAME, value).apply();
    }

    public String getControllerName() {
        String value = preferences.getString(KEY_CONTROLLER_NAME, "Lens controller");
        return value == null || value.isBlank() ? "Lens controller" : value;
    }

    public void setControllerName(String name) {
        String value = name == null || name.isBlank() ? "Lens controller" : name.trim();
        preferences.edit().putString(KEY_CONTROLLER_NAME, value).apply();
    }

    public boolean isLeftXInverted() {
        return preferences.getBoolean(KEY_INVERT_LEFT_X, false);
    }

    public boolean isLeftYInverted() {
        return preferences.getBoolean(KEY_INVERT_LEFT_Y, false);
    }

    public boolean isRightXInverted() {
        return preferences.getBoolean(KEY_INVERT_RIGHT_X, false);
    }

    public boolean isRightYInverted() {
        return preferences.getBoolean(KEY_INVERT_RIGHT_Y, false);
    }

    public boolean shouldSwapSticks() {
        return preferences.getBoolean(KEY_SWAP_STICKS, false);
    }

    public void setAxisOptions(
            boolean invertLeftX,
            boolean invertLeftY,
            boolean invertRightX,
            boolean invertRightY,
            boolean swapSticks) {
        preferences
                .edit()
                .putBoolean(KEY_INVERT_LEFT_X, invertLeftX)
                .putBoolean(KEY_INVERT_LEFT_Y, invertLeftY)
                .putBoolean(KEY_INVERT_RIGHT_X, invertRightX)
                .putBoolean(KEY_INVERT_RIGHT_Y, invertRightY)
                .putBoolean(KEY_SWAP_STICKS, swapSticks)
                .apply();
    }

    private StickCalibration.Axis readAxis(String id) {
        return new StickCalibration.Axis(
                preferences.getFloat(KEY_CAL_MIN + id, -1f),
                preferences.getFloat(KEY_CAL_MAX + id, 1f),
                preferences.getFloat(KEY_CAL_CENTER + id, 0f));
    }

    private void writeAxis(
            SharedPreferences.Editor editor, String id, StickCalibration.Axis axis) {
        editor.putFloat(KEY_CAL_MIN + id, axis.min);
        editor.putFloat(KEY_CAL_MAX + id, axis.max);
        editor.putFloat(KEY_CAL_CENTER + id, axis.center);
    }

    private void writeLayouts(
            String preferenceKey, Map<String, Map<Integer, Integer>> layouts) {
        JSONObject root = new JSONObject();
        try {
            for (Map.Entry<String, Map<Integer, Integer>> layout : layouts.entrySet()) {
                JSONObject encoded = new JSONObject();
                for (Map.Entry<Integer, Integer> binding : layout.getValue().entrySet()) {
                    encoded.put(String.valueOf(binding.getKey()), binding.getValue());
                }
                root.put(layout.getKey(), encoded);
            }
        } catch (JSONException ignored) {
            return;
        }
        preferences.edit().putString(preferenceKey, root.toString()).apply();
    }

    private static boolean isDefaultAxis(StickCalibration.Axis axis) {
        return Math.abs(axis.min + 1f) < 0.0001f
                && Math.abs(axis.max - 1f) < 0.0001f
                && Math.abs(axis.center) < 0.0001f;
    }

    private void removeLegacyDualSensePreset() {
        SharedPreferences.Editor editor = preferences.edit();
        boolean changed = false;
        if (LEGACY_DUALSENSE_PRESET_LAYOUT.equals(
                preferences.getString(KEY_ACTIVE_LAYOUT, STANDARD_LAYOUT))) {
            editor.putString(KEY_ACTIVE_LAYOUT, XBOX_PRESET_LAYOUT);
            changed = true;
        }
        String raw = preferences.getString(KEY_PRESET_LAYOUTS, "{}");
        try {
            JSONObject root = new JSONObject(raw);
            if (root.has(LEGACY_DUALSENSE_PRESET_LAYOUT)) {
                root.remove(LEGACY_DUALSENSE_PRESET_LAYOUT);
                editor.putString(KEY_PRESET_LAYOUTS, root.toString());
                changed = true;
            }
        } catch (JSONException ignored) {
            // Existing malformed presets are ignored by the normal layout loader.
        }
        if (changed) {
            editor.apply();
        }
    }
}
