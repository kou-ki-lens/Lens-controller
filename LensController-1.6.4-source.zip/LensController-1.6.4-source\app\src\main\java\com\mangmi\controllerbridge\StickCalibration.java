package com.mangmi.controllerbridge;

public final class StickCalibration {
    public static final StickCalibration DEFAULT =
            new StickCalibration(Axis.DEFAULT, Axis.DEFAULT, Axis.DEFAULT, Axis.DEFAULT);

    public final Axis leftX;
    public final Axis leftY;
    public final Axis rightX;
    public final Axis rightY;

    public StickCalibration(Axis leftX, Axis leftY, Axis rightX, Axis rightY) {
        this.leftX = leftX;
        this.leftY = leftY;
        this.rightX = rightX;
        this.rightY = rightY;
    }

    public float[] apply(float x, float y, float rx, float ry) {
        return new float[] {
            leftX.apply(x), leftY.apply(y), rightX.apply(rx), rightY.apply(ry)
        };
    }

    public static final class Axis {
        public static final Axis DEFAULT = new Axis(-1f, 1f, 0f);

        public final float min;
        public final float max;
        public final float center;

        public Axis(float min, float max, float center) {
            this.min = Math.max(-1f, Math.min(0.99f, min));
            this.max = Math.max(-0.99f, Math.min(1f, max));
            this.center = Math.max(this.min + 0.01f, Math.min(this.max - 0.01f, center));
        }

        public float apply(float raw) {
            float bounded = Math.max(-1f, Math.min(1f, raw));
            if (bounded >= center) {
                float span = Math.max(0.1f, max - center);
                return Math.max(0f, Math.min(1f, (bounded - center) / span));
            }
            float span = Math.max(0.1f, center - min);
            return Math.max(-1f, Math.min(0f, (bounded - center) / span));
        }
    }
}
