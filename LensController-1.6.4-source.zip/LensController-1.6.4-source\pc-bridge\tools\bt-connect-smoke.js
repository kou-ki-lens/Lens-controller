"use strict";

const { Worker } = require("node:worker_threads");
const path = require("node:path");

const address = process.argv[2];
if (!address) {
  throw new Error("Usage: node tools/bt-connect-smoke.js AA:BB:CC:DD:EE:FF");
}

const worker = new Worker(path.join(__dirname, "..", "bluetooth-rfcomm-worker.js"), {
  workerData: { address },
});
worker.on("message", (message) => {
  if (message.type === "data") {
    console.log("DATA", message.data.length);
  } else {
    console.log(message.type.toUpperCase(), message.message || "");
  }
});
worker.on("error", (error) => console.error(error));
setTimeout(async () => {
  await worker.terminate();
  process.exit(0);
}, 12_000);
