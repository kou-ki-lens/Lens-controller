package com.mangmi.controllerbridge;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ScreensaverView extends FrameLayout {
    public interface ExitListener {
        void onScreensaverExit();
    }

    public interface TouchpadListener {
        void onTouchpadChanged(TouchpadState state);
    }

    private static final long TAP_WINDOW_MS = 1_500L;
    private static final long DOUBLE_TAP_MS = 360L;
    private static final String[] DEFAULT_ASSETS = {
        "screensaver/default_01.jpg",
        "screensaver/default_02.jpg",
        "screensaver/default_03.jpg",
        "screensaver/default_04.jpg",
        "screensaver/default_05.jpg",
        "screensaver/default_06.jpg",
        "screensaver/default_07.jpg",
        "screensaver/default_08.jpg",
        "screensaver/default_09.jpg",
        "screensaver/default_10.jpg",
        "screensaver/default_11.jpg",
        "screensaver/default_12.jpg"
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService loader = Executors.newSingleThreadExecutor();
    private final ImageView first = imageView();
    private final ImageView second = imageView();
    private final TouchFeedbackView touchFeedback;
    private final TextView exitHint;
    private final List<ImageSource> sources = new ArrayList<>();
    private final Map<Integer, TrackedTouch> trackedTouches = new LinkedHashMap<>();
    private final Random random = new Random();
    private boolean front = true;
    private int index;
    private int generation;
    private int tapCount;
    private long firstTapAt;
    private long intervalMs = 8_000L;
    private int exitTapCount = 3;
    private int nextTouchId;
    private boolean randomOrder;
    private boolean touchClickActive;
    private ExitListener exitListener;
    private TouchpadListener touchpadListener;
    private Drawable currentDrawable;
    private Drawable previousDrawable;
    private float touchDownX;
    private float touchDownY;
    private long touchDownAt;
    private long lastTapAt;
    private float lastTapX;
    private float lastTapY;

    public ScreensaverView(Context context) {
        super(context);
        setBackgroundColor(Color.BLACK);
        addView(first, fullParams());
        addView(second, fullParams());

        touchFeedback = new TouchFeedbackView(context);
        addView(touchFeedback, fullParams());

        exitHint = new TextView(context);
        exitHint.setTextColor(Color.argb(210, 255, 255, 255));
        exitHint.setTextSize(11);
        exitHint.setGravity(Gravity.CENTER);
        exitHint.setBackgroundColor(Color.argb(105, 0, 0, 0));
        exitHint.setPadding(dp(18), dp(8), dp(18), dp(8));
        LayoutParams hintParams =
                new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        hintParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        hintParams.bottomMargin = dp(24);
        addView(exitHint, hintParams);

        getViewTreeObserver()
                .addOnGlobalLayoutListener(
                        new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
                            @Override
                            public void onGlobalLayout() {
                                if (getWidth() > 0 && getHeight() > 0) {
                                    getViewTreeObserver().removeOnGlobalLayoutListener(this);
                                    loadSlide(index, true);
                                    scheduleNext();
                                }
                            }
                        });
    }

    public void configure(
            List<String> uriStrings,
            int intervalSeconds,
            boolean useRandomOrder,
            int tapsToExit,
            boolean touchpadAvailable,
            String exitHintText,
            ExitListener listener,
            TouchpadListener touchpad) {
        exitListener = listener;
        touchpadListener = touchpad;
        intervalMs = Math.max(2, intervalSeconds) * 1_000L;
        randomOrder = useRandomOrder;
        exitTapCount = Math.max(3, Math.min(20, tapsToExit));
        exitHint.setText(
                (touchpadAvailable ? "触控板可用 · " : "")
                        + (exitHintText == null || exitHintText.isBlank()
                                ? "轻触 " + exitTapCount + " 次退出"
                                : exitHintText));
        exitHint.animate().cancel();
        exitHint.setAlpha(1f);
        exitHint.animate().alpha(0f).setStartDelay(4_500L).setDuration(800L).start();
        sources.clear();
        for (String uri : uriStrings) {
            if (uri != null && !uri.isBlank()) {
                sources.add(ImageSource.uri(Uri.parse(uri)));
            }
        }
        if (sources.isEmpty()) {
            addDefaultSources();
        }
        generation++;
        index = 0;
        loadSlide(0, true);
    }

    public void startSlideshow() {
        scheduleNext();
    }

    public void stopSlideshow() {
        generation++;
        handler.removeCallbacksAndMessages(null);
        loader.shutdownNow();
        trackedTouches.clear();
        touchClickActive = false;
        lastTapAt = 0;
        first.setImageDrawable(null);
        second.setImageDrawable(null);
        currentDrawable = null;
        previousDrawable = null;
    }

    private void addDefaultSources() {
        for (String asset : DEFAULT_ASSETS) {
            sources.add(ImageSource.asset(asset));
        }
    }

    private void scheduleNext() {
        handler.removeCallbacks(nextRunnable);
        if (sources.size() > 1) {
            handler.postDelayed(nextRunnable, intervalMs);
        }
    }

    private final Runnable nextRunnable =
            () -> {
                if (sources.isEmpty()) {
                    return;
                }
                index = randomOrder ? randomIndex() : (index + 1) % sources.size();
                loadSlide(index, false);
                scheduleNext();
            };

    private int randomIndex() {
        if (sources.size() < 2) {
            return 0;
        }
        int next = index;
        while (next == index) {
            next = random.nextInt(sources.size());
        }
        return next;
    }

    private void loadSlide(int requestedIndex, boolean immediate) {
        if (requestedIndex < 0 || requestedIndex >= sources.size()) {
            return;
        }
        int requestGeneration = generation;
        ImageSource source = sources.get(requestedIndex);
        int targetWidth = Math.max(1, getWidth());
        int targetHeight = Math.max(1, getHeight());
        loader.execute(
                () -> {
                    Bitmap bitmap = decode(source, targetWidth, targetHeight);
                    handler.post(
                            () -> {
                                if (requestGeneration != generation) {
                                    if (bitmap != null) {
                                        bitmap.recycle();
                                    }
                                    return;
                                }
                                if (bitmap == null) {
                                    if (!hasDisplayedDrawable()) {
                                        loadDefaultFallback();
                                    }
                                    return;
                                }
                                showDrawable(new BitmapDrawable(getResources(), bitmap), immediate);
                            });
                });
    }

    private void loadDefaultFallback() {
        sources.clear();
        addDefaultSources();
        index = 0;
        loadSlide(0, true);
        scheduleNext();
    }

    private boolean hasDisplayedDrawable() {
        return first.getDrawable() != null || second.getDrawable() != null;
    }

    private void showDrawable(Drawable drawable, boolean immediate) {
        ImageView incoming = front ? second : first;
        ImageView outgoing = front ? first : second;
        incoming.setImageDrawable(drawable);
        incoming.setAlpha(immediate ? 1f : 0f);
        incoming.bringToFront();
        touchFeedback.bringToFront();
        exitHint.bringToFront();

        if (immediate) {
            outgoing.setAlpha(0f);
            releaseDrawable(outgoing == first ? currentDrawable : previousDrawable);
            if (outgoing == first) {
                currentDrawable = drawable;
            } else {
                previousDrawable = drawable;
            }
        } else {
            ObjectAnimator fadeIn =
                    ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f).setDuration(650);
            fadeIn.start();
            outgoing.animate().alpha(0f).setDuration(650).start();
            Drawable old = outgoing == first ? currentDrawable : previousDrawable;
            if (outgoing == first) {
                currentDrawable = drawable;
            } else {
                previousDrawable = drawable;
            }
            handler.postDelayed(
                    () -> {
                        outgoing.setImageDrawable(null);
                        releaseDrawable(old);
                    },
                    700L);
        }
        front = !front;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchDownX = event.getX();
                touchDownY = event.getY();
                touchDownAt = event.getEventTime();
                updatePointer(event, event.getActionIndex(), true);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                updatePointer(event, event.getActionIndex(), true);
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++) {
                    updatePointer(event, i, true);
                }
                publishTouchpad();
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                updatePointer(event, event.getActionIndex(), false);
                publishTouchpad();
                scheduleReleasedTouchRemoval(event.getPointerId(event.getActionIndex()));
                return true;
            case MotionEvent.ACTION_UP: {
                int pointerIndex = event.getActionIndex();
                updatePointer(event, pointerIndex, false);
                publishTouchpad();
                scheduleReleasedTouchRemoval(event.getPointerId(pointerIndex));
                float dx = event.getX() - touchDownX;
                float dy = event.getY() - touchDownY;
                if (event.getEventTime() - touchDownAt <= 350L
                        && dx * dx + dy * dy <= dp(20) * dp(20)) {
                    registerExitTap();
                    registerTouchpadTap(event.getX(), event.getY());
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                trackedTouches.clear();
                publishTouchpad();
                return true;
            default:
                return true;
        }
        publishTouchpad();
        return true;
    }

    private void updatePointer(MotionEvent event, int pointerIndex, boolean active) {
        int pointerId = event.getPointerId(pointerIndex);
        TrackedTouch touch = trackedTouches.get(pointerId);
        if (touch == null) {
            touch = new TrackedTouch(nextTouchId++ & 0x7f);
            trackedTouches.put(pointerId, touch);
        }
        touch.active = active;
        touch.x = Math.round(event.getX(pointerIndex) / Math.max(1f, getWidth()) * 1919f);
        touch.y = Math.round(event.getY(pointerIndex) / Math.max(1f, getHeight()) * 942f);
    }

    private void scheduleReleasedTouchRemoval(int pointerId) {
        handler.postDelayed(
                () -> {
                    TrackedTouch touch = trackedTouches.get(pointerId);
                    if (touch != null && !touch.active) {
                        trackedTouches.remove(pointerId);
                        publishTouchpad();
                    }
                },
                80L);
    }

    private void publishTouchpad() {
        List<TrackedTouch> touches = new ArrayList<>(trackedTouches.values());
        TrackedTouch firstTouch = touches.size() > 0 ? touches.get(0) : null;
        TrackedTouch secondTouch = touches.size() > 1 ? touches.get(1) : null;
        TouchpadState state =
                firstTouch == null && secondTouch == null
                        ? TouchpadState.NONE
                        : new TouchpadState(
                                firstTouch != null && firstTouch.active,
                                firstTouch == null ? -1 : firstTouch.id,
                                firstTouch == null ? 0 : firstTouch.x,
                                firstTouch == null ? 0 : firstTouch.y,
                                secondTouch != null && secondTouch.active,
                                secondTouch == null ? -1 : secondTouch.id,
                                secondTouch == null ? 0 : secondTouch.x,
                                secondTouch == null ? 0 : secondTouch.y,
                                touchClickActive);
        if (touchpadListener != null) {
            touchpadListener.onTouchpadChanged(state);
        }
        List<TouchFeedbackView.Point> points = new ArrayList<>();
        for (TrackedTouch touch : touches) {
            if (touch.active) {
                points.add(
                        new TouchFeedbackView.Point(
                                touch.x / 1919f * getWidth(),
                                touch.y / 942f * getHeight()));
            }
        }
        touchFeedback.setPoints(points);
    }

    private void registerTouchpadTap(float x, float y) {
        long now = android.os.SystemClock.elapsedRealtime();
        float maxDistance = dp(32);
        float dx = x - lastTapX;
        float dy = y - lastTapY;
        if (lastTapAt > 0
                && now - lastTapAt <= DOUBLE_TAP_MS
                && dx * dx + dy * dy <= maxDistance * maxDistance) {
            lastTapAt = 0;
            touchClickActive = true;
            publishTouchpad();
            handler.postDelayed(
                    () -> {
                        touchClickActive = false;
                        publishTouchpad();
                    },
                    80L);
        } else {
            lastTapAt = now;
            lastTapX = x;
            lastTapY = y;
        }
    }

    private void registerExitTap() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (tapCount == 0 || now - firstTapAt > TAP_WINDOW_MS) {
            tapCount = 1;
            firstTapAt = now;
        } else {
            tapCount++;
        }
        if (tapCount >= exitTapCount) {
            tapCount = 0;
            performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
            if (exitListener != null) {
                exitListener.onScreensaverExit();
            }
        }
    }

    private Bitmap decode(ImageSource source, int targetWidth, int targetHeight) {
        try {
            if (source.assetName != null) {
                AssetManager assets = getContext().getAssets();
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream input = assets.open(source.assetName)) {
                    BitmapFactory.decodeStream(input, null, bounds);
                }
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize =
                        sampleSize(bounds.outWidth, bounds.outHeight, targetWidth, targetHeight);
                try (InputStream input = assets.open(source.assetName)) {
                    return BitmapFactory.decodeStream(input, null, options);
                }
            }
            ImageDecoder.Source imageSource =
                    ImageDecoder.createSource(
                            getContext().getContentResolver(), source.uri);
            return ImageDecoder.decodeBitmap(
                    imageSource,
                    (decoder, info, input) -> {
                        android.util.Size size = info.getSize();
                        float scale =
                                Math.min(
                                        1f,
                                        Math.min(
                                                (float) targetWidth / size.getWidth(),
                                                (float) targetHeight / size.getHeight()));
                        decoder.setTargetSize(
                                Math.max(1, Math.round(size.getWidth() * scale)),
                                Math.max(1, Math.round(size.getHeight() * scale)));
                        decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    });
        } catch (IOException | SecurityException ignored) {
            return null;
        }
    }

    private static int sampleSize(int width, int height, int targetWidth, int targetHeight) {
        int sample = 1;
        while (width / sample > targetWidth * 1.5f
                || height / sample > targetHeight * 1.5f) {
            sample *= 2;
        }
        return sample;
    }

    private static void releaseDrawable(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            if (bitmap != null && !bitmap.isRecycled()) {
                bitmap.recycle();
            }
        }
    }

    private ImageView imageView() {
        ImageView view = new ImageView(getContext());
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.setBackground(new ColorDrawable(Color.BLACK));
        view.setAlpha(0f);
        return view;
    }

    private LayoutParams fullParams() {
        return new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class ImageSource {
        final String assetName;
        final Uri uri;

        private ImageSource(String assetName, Uri uri) {
            this.assetName = assetName;
            this.uri = uri;
        }

        static ImageSource asset(String name) {
            return new ImageSource(name, null);
        }

        static ImageSource uri(Uri uri) {
            return new ImageSource(null, uri);
        }
    }

    private static final class TrackedTouch {
        final int id;
        boolean active;
        int x;
        int y;

        TrackedTouch(int id) {
            this.id = id;
        }
    }

    private static final class TouchFeedbackView extends View {
        static final class Point {
            final float x;
            final float y;

            Point(float x, float y) {
                this.x = x;
                this.y = y;
            }
        }

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<Point> points = new ArrayList<>();

        TouchFeedbackView(Context context) {
            super(context);
            setClickable(false);
            setFocusable(false);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(
                    2f * getResources().getDisplayMetrics().density);
            paint.setColor(Color.argb(210, 255, 255, 255));
        }

        void setPoints(List<Point> nextPoints) {
            points = nextPoints;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            for (Point point : points) {
                canvas.drawCircle(
                        point.x,
                        point.y,
                        14f * getResources().getDisplayMetrics().density,
                        paint);
                canvas.drawCircle(
                        point.x,
                        point.y,
                        4f * getResources().getDisplayMetrics().density,
                        paint);
            }
        }
    }
}
