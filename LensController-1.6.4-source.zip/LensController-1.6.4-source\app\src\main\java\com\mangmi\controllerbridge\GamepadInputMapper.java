package com.mangmi.controllerbridge;

import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.os.Handler;
import android.os.Looper;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Converts Android's many gamepad layouts into one stable state.
 *
 * <p>It supports the common Xbox mapping (X/Y, Z/Rz, Brake/Gas), the newer Android
 * trigger axes, and the DualShock mapping where Rx/Ry are the right stick.</p>
 */
public final class GamepadInputMapper {
    private static final float TRIGGER_DEAD_ZONE = 0.015f;

    private final Map<Integer, Integer> keyMapping =
            new LinkedHashMap<>(ButtonMapping.standard());
    private int leftX;
    private int leftY;
    private int rightX;
    private int rightY;
    private int leftTrigger;
    private int rightTrigger;
    private int buttons;
    private String deviceName = "等待手柄输入";
    private int deviceId = -1;
    private float stickDeadZone = 0.08f;
    private StickCalibration calibration = StickCalibration.DEFAULT;
    private CenterCapture centerCapture;
    private RangeCapture rangeCapture;
    private float lastRawLeftX;
    private float lastRawLeftY;
    private float lastRawRightX;
    private float lastRawRightY;
    private boolean invertLeftX;
    private boolean invertLeftY;
    private boolean invertRightX;
    private boolean invertRightY;
    private boolean swapSticks;
    private final Handler releaseHandler = new Handler(Looper.getMainLooper());
    private final Runnable releaseDpad =
            () -> setButton(
                    ControllerState.BUTTON_DPAD_UP
                            | ControllerState.BUTTON_DPAD_DOWN
                            | ControllerState.BUTTON_DPAD_LEFT
                            | ControllerState.BUTTON_DPAD_RIGHT,
                    false);

    public synchronized ControllerState state() {
        return new ControllerState(
                leftX, leftY, rightX, rightY, leftTrigger, rightTrigger, buttons);
    }

    public synchronized String deviceName() {
        return deviceName;
    }

    public synchronized boolean hasDevice() {
        return deviceId >= 0;
    }

    public synchronized boolean usesDevice(int id) {
        return deviceId == id;
    }

    public synchronized void setDeadZonePercent(int percent) {
        stickDeadZone = Math.max(1, Math.min(30, percent)) / 100f;
    }

    public synchronized void setKeyMapping(Map<Integer, Integer> mapping) {
        keyMapping.clear();
        keyMapping.putAll(mapping);
    }

    public synchronized void setAxisOptions(
            boolean invertLeftX,
            boolean invertLeftY,
            boolean invertRightX,
            boolean invertRightY,
            boolean swapSticks) {
        this.invertLeftX = invertLeftX;
        this.invertLeftY = invertLeftY;
        this.invertRightX = invertRightX;
        this.invertRightY = invertRightY;
        this.swapSticks = swapSticks;
    }

    public synchronized Map<Integer, Integer> getKeyMapping() {
        return new LinkedHashMap<>(keyMapping);
    }

    public synchronized void setCalibration(StickCalibration nextCalibration) {
        calibration = nextCalibration == null ? StickCalibration.DEFAULT : nextCalibration;
    }

    public synchronized void beginCenterCapture() {
        centerCapture = new CenterCapture();
        centerCapture.add(lastRawLeftX, lastRawLeftY, lastRawRightX, lastRawRightY);
        rangeCapture = null;
    }

    public synchronized void beginRangeCapture() {
        rangeCapture = new RangeCapture(centerCapture == null ? null : centerCapture.center());
        centerCapture = null;
    }

    public synchronized boolean hasRangeSamples() {
        return rangeCapture != null && rangeCapture.samples > 0;
    }

    public synchronized int calibrationSampleCount() {
        return rangeCapture == null ? 0 : rangeCapture.samples;
    }

    public synchronized StickCalibration finishCalibration() {
        RangeCapture samples = rangeCapture;
        boolean hasRangeSamples = samples != null && samples.samples > 0;
        centerCapture = null;
        rangeCapture = null;
        if (!hasRangeSamples) {
            return calibration;
        }
        calibration =
                new StickCalibration(
                        toAxis(samples.minLeftX, samples.maxLeftX, samples.centerLeftX),
                        toAxis(samples.minLeftY, samples.maxLeftY, samples.centerLeftY),
                        toAxis(samples.minRightX, samples.maxRightX, samples.centerRightX),
                        toAxis(samples.minRightY, samples.maxRightY, samples.centerRightY));
        return calibration;
    }

    public synchronized void cancelCalibration() {
        centerCapture = null;
        rangeCapture = null;
    }

    public synchronized boolean handleKeyEvent(KeyEvent event) {
        int sources =
                event.getDevice() == null
                        ? event.getSource()
                        : event.getDevice().getSources();
        if ((sources & (InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK)) == 0) {
            return false;
        }
        Integer action = keyMapping.get(event.getKeyCode());
        if (action == null) {
            return false;
        }

        rememberDevice(event.getDevice());
        boolean pressed = event.getAction() == KeyEvent.ACTION_DOWN;
        if (event.getAction() != KeyEvent.ACTION_DOWN
                && event.getAction() != KeyEvent.ACTION_UP) {
            return true;
        }
        if (action == ButtonMapping.ACTION_LT) {
            leftTrigger = pressed ? 255 : 0;
        } else if (action == ButtonMapping.ACTION_RT) {
            rightTrigger = pressed ? 255 : 0;
        } else {
            int mask = ButtonMapping.buttonBit(action);
            if (pressed && isDpadAction(action)) {
                clearOppositeDpad(action);
            }
            setButton(mask, pressed);
            if (pressed && isDpadAction(action)) {
                releaseHandler.removeCallbacks(releaseDpad);
                releaseHandler.postDelayed(releaseDpad, 220L);
            } else if (!pressed && isDpadAction(action)) {
                releaseHandler.removeCallbacks(releaseDpad);
            }
        }
        return true;
    }

    public synchronized boolean handleMotionEvent(MotionEvent event) {
        InputDevice device = event.getDevice();
        if (device == null
                || (device.getSources()
                        & (InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_GAMEPAD))
                        == 0) {
            return false;
        }

        rememberDevice(device);
        float rawLeftX = axis(event, device, MotionEvent.AXIS_X);
        float rawLeftY = axis(event, device, MotionEvent.AXIS_Y);

        boolean hasRx = hasAxis(device, MotionEvent.AXIS_RX);
        boolean hasRy = hasAxis(device, MotionEvent.AXIS_RY);
        boolean hasZ = hasAxis(device, MotionEvent.AXIS_Z);
        boolean hasRz = hasAxis(device, MotionEvent.AXIS_RZ);
        int rightAxisX = hasRx ? MotionEvent.AXIS_RX : MotionEvent.AXIS_Z;
        int rightAxisY = hasRy ? MotionEvent.AXIS_RY : MotionEvent.AXIS_RZ;
        int triggerAxisL = -1;
        int triggerAxisR = -1;

        if (hasRx && hasRy && hasZ && hasRz) {
            boolean rxIsBipolar = isBipolar(device, MotionEvent.AXIS_RX);
            boolean zIsBipolar = isBipolar(device, MotionEvent.AXIS_Z);
            if (zIsBipolar && !rxIsBipolar) {
                // Xbox layouts commonly use Z/Rz for the right stick and Rx/Ry for triggers.
                rightAxisX = MotionEvent.AXIS_Z;
                rightAxisY = MotionEvent.AXIS_RZ;
                triggerAxisL = MotionEvent.AXIS_RX;
                triggerAxisR = MotionEvent.AXIS_RY;
            } else if (rxIsBipolar && !zIsBipolar) {
                // DualShock layouts commonly use Rx/Ry for the right stick.
                rightAxisX = MotionEvent.AXIS_RX;
                rightAxisY = MotionEvent.AXIS_RY;
                triggerAxisL = MotionEvent.AXIS_Z;
                triggerAxisR = MotionEvent.AXIS_RZ;
            }
        } else if (hasRx
                && hasRy
                && !hasZ
                && !hasRz
                && !isBipolar(device, MotionEvent.AXIS_RX)
                && !isBipolar(device, MotionEvent.AXIS_RY)) {
            // A number of generic Android pads expose only two unipolar trigger axes.
            rightAxisX = MotionEvent.AXIS_Z;
            rightAxisY = MotionEvent.AXIS_RZ;
            triggerAxisL = MotionEvent.AXIS_RX;
            triggerAxisR = MotionEvent.AXIS_RY;
        }

        float rawRightX = axis(event, device, rightAxisX);
        float rawRightY = axis(event, device, rightAxisY);
        lastRawLeftX = rawLeftX;
        lastRawLeftY = rawLeftY;
        lastRawRightX = rawRightX;
        lastRawRightY = rawRightY;
        captureCalibration(rawLeftX, rawLeftY, rawRightX, rawRightY);
        float[] calibrated = calibration.apply(rawLeftX, rawLeftY, rawRightX, rawRightY);
        float calibratedLeftX = calibrated[0];
        float calibratedLeftY = calibrated[1];
        float calibratedRightX = calibrated[2];
        float calibratedRightY = calibrated[3];
        if (swapSticks) {
            float previousLeftX = calibratedLeftX;
            float previousLeftY = calibratedLeftY;
            calibratedLeftX = calibratedRightX;
            calibratedLeftY = calibratedRightY;
            calibratedRightX = previousLeftX;
            calibratedRightY = previousLeftY;
        }
        if (invertLeftX) {
            calibratedLeftX = -calibratedLeftX;
        }
        if (invertLeftY) {
            calibratedLeftY = -calibratedLeftY;
        }
        if (invertRightX) {
            calibratedRightX = -calibratedRightX;
        }
        if (invertRightY) {
            calibratedRightY = -calibratedRightY;
        }

        int[] leftStick = radialDeadZone(calibratedLeftX, calibratedLeftY);
        int[] rightStick = radialDeadZone(calibratedRightX, calibratedRightY);
        leftX = leftStick[0];
        leftY = leftStick[1];
        rightX = rightStick[0];
        rightY = rightStick[1];

        boolean hasDedicatedTriggers =
                hasAxis(device, MotionEvent.AXIS_LTRIGGER)
                        || hasAxis(device, MotionEvent.AXIS_RTRIGGER);
        if (hasDedicatedTriggers) {
            leftTrigger = trigger(event, device, MotionEvent.AXIS_LTRIGGER);
            rightTrigger = trigger(event, device, MotionEvent.AXIS_RTRIGGER);
        } else if (hasAxis(device, MotionEvent.AXIS_BRAKE)
                || hasAxis(device, MotionEvent.AXIS_GAS)) {
            leftTrigger = trigger(event, device, MotionEvent.AXIS_BRAKE);
            rightTrigger = trigger(event, device, MotionEvent.AXIS_GAS);
        } else if (triggerAxisL >= 0 && triggerAxisR >= 0) {
            leftTrigger = trigger(event, device, triggerAxisL);
            rightTrigger = trigger(event, device, triggerAxisR);
        } else if (hasAxis(device, MotionEvent.AXIS_THROTTLE)
                || hasAxis(device, MotionEvent.AXIS_RUDDER)) {
            leftTrigger = trigger(event, device, MotionEvent.AXIS_THROTTLE);
            rightTrigger = trigger(event, device, MotionEvent.AXIS_RUDDER);
        }

        float hatX = axis(event, device, MotionEvent.AXIS_HAT_X);
        float hatY = axis(event, device, MotionEvent.AXIS_HAT_Y);
        if (Math.abs(hatX) > 0.5f) {
            setButton(ControllerState.BUTTON_DPAD_LEFT, hatX < 0);
            setButton(ControllerState.BUTTON_DPAD_RIGHT, hatX > 0);
        } else {
            setButton(ControllerState.BUTTON_DPAD_LEFT, false);
            setButton(ControllerState.BUTTON_DPAD_RIGHT, false);
        }
        if (Math.abs(hatY) > 0.5f) {
            setButton(ControllerState.BUTTON_DPAD_UP, hatY < 0);
            setButton(ControllerState.BUTTON_DPAD_DOWN, hatY > 0);
        } else {
            setButton(ControllerState.BUTTON_DPAD_UP, false);
            setButton(ControllerState.BUTTON_DPAD_DOWN, false);
        }

        leftX = outputAxis(leftStick[0]);
        leftY = outputAxis(leftStick[1]);
        rightX = outputAxis(rightStick[0]);
        rightY = outputAxis(rightStick[1]);
        return true;
    }

    public synchronized void reset() {
        releaseHandler.removeCallbacks(releaseDpad);
        leftX = 0;
        leftY = 0;
        rightX = 0;
        rightY = 0;
        leftTrigger = 0;
        rightTrigger = 0;
        buttons = 0;
    }

    private void rememberDevice(InputDevice device) {
        if (device == null) {
            return;
        }
        int sources = device.getSources();
        if ((sources & (InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_GAMEPAD)) == 0) {
            return;
        }
        deviceId = device.getId();
        String name = device.getName();
        deviceName = name == null || name.isBlank() ? "Android 手柄" : name;
    }

    private synchronized void setButton(int mask, boolean pressed) {
        buttons = pressed ? buttons | mask : buttons & ~mask;
    }

    private void clearOppositeDpad(int action) {
        if (action == ButtonMapping.ACTION_DPAD_UP) {
            setButton(ControllerState.BUTTON_DPAD_DOWN, false);
        } else if (action == ButtonMapping.ACTION_DPAD_DOWN) {
            setButton(ControllerState.BUTTON_DPAD_UP, false);
        } else if (action == ButtonMapping.ACTION_DPAD_LEFT) {
            setButton(ControllerState.BUTTON_DPAD_RIGHT, false);
        } else if (action == ButtonMapping.ACTION_DPAD_RIGHT) {
            setButton(ControllerState.BUTTON_DPAD_LEFT, false);
        }
    }

    private static boolean isDpadAction(int action) {
        return action >= ButtonMapping.ACTION_DPAD_UP
                && action <= ButtonMapping.ACTION_DPAD_RIGHT;
    }

    private static boolean hasAxis(InputDevice device, int axis) {
        return device.getMotionRange(axis, 0) != null
                || device.getMotionRange(axis, InputDevice.SOURCE_JOYSTICK) != null;
    }

    private static boolean isBipolar(InputDevice device, int axis) {
        InputDevice.MotionRange range =
                device.getMotionRange(axis, InputDevice.SOURCE_JOYSTICK);
        if (range == null) {
            range = device.getMotionRange(axis, 0);
        }
        return range != null && range.getMin() < -0.01f;
    }

    private static float axis(MotionEvent event, InputDevice device, int axis) {
        if (!hasAxis(device, axis)) {
            return 0f;
        }
        try {
            return event.getAxisValue(axis);
        } catch (IllegalArgumentException ignored) {
            return 0f;
        }
    }

    private static int trigger(MotionEvent event, InputDevice device, int axis) {
        InputDevice.MotionRange range =
                device.getMotionRange(axis, InputDevice.SOURCE_JOYSTICK);
        if (range == null) {
            range = device.getMotionRange(axis, 0);
        }
        if (range == null) {
            return 0;
        }
        float value;
        try {
            value = event.getAxisValue(axis);
        } catch (IllegalArgumentException ignored) {
            return 0;
        }
        float span = range.getMax() - range.getMin();
        float normalized = span <= 0f ? 0f : (value - range.getMin()) / span;
        normalized = Math.max(0f, Math.min(1f, normalized));
        if (normalized < TRIGGER_DEAD_ZONE) {
            normalized = 0f;
        }
        return Math.round(normalized * 255f);
    }

    private int[] radialDeadZone(float x, float y) {
        x = Math.max(-1f, Math.min(1f, x));
        y = Math.max(-1f, Math.min(1f, y));
        float magnitude = (float) Math.sqrt(x * x + y * y);
        if (magnitude < stickDeadZone) {
            return new int[] {0, 0};
        }
        float scaledMagnitude =
                Math.min(1f, (magnitude - stickDeadZone) / (1f - stickDeadZone));
        float scale = scaledMagnitude / magnitude;
        return new int[] {
            Math.round(x * scale * 127f), Math.round(y * scale * 127f)
        };
    }

    private static int outputAxis(int value) {
        return Math.max(-127, Math.min(127, value));
    }

    private void captureCalibration(
            float rawLeftX, float rawLeftY, float rawRightX, float rawRightY) {
        if (centerCapture != null) {
            centerCapture.add(rawLeftX, rawLeftY, rawRightX, rawRightY);
        } else if (rangeCapture != null) {
            rangeCapture.add(rawLeftX, rawLeftY, rawRightX, rawRightY);
        }
    }

    private static StickCalibration.Axis toAxis(float min, float max, float center) {
        float usableMin = center - min >= 0.25f ? min : Math.max(-1f, center - 1f);
        float usableMax = max - center >= 0.25f ? max : Math.min(1f, center + 1f);
        return new StickCalibration.Axis(usableMin, usableMax, center);
    }

    private static final class CenterCapture {
        private int samples;
        private double leftX;
        private double leftY;
        private double rightX;
        private double rightY;

        void add(float x, float y, float rx, float ry) {
            leftX += x;
            leftY += y;
            rightX += rx;
            rightY += ry;
            samples++;
        }

        float[] center() {
            int divisor = Math.max(1, samples);
            return new float[] {
                (float) (leftX / divisor),
                (float) (leftY / divisor),
                (float) (rightX / divisor),
                (float) (rightY / divisor)
            };
        }
    }

    private static final class RangeCapture {
        private final float centerLeftX;
        private final float centerLeftY;
        private final float centerRightX;
        private final float centerRightY;
        private float minLeftX;
        private float maxLeftX;
        private float minLeftY;
        private float maxLeftY;
        private float minRightX;
        private float maxRightX;
        private float minRightY;
        private float maxRightY;
        private int samples;

        RangeCapture(float[] centers) {
            float[] safe =
                    centers == null ? new float[] {0f, 0f, 0f, 0f} : centers;
            centerLeftX = safe[0];
            centerLeftY = safe[1];
            centerRightX = safe[2];
            centerRightY = safe[3];
            minLeftX = maxLeftX = centerLeftX;
            minLeftY = maxLeftY = centerLeftY;
            minRightX = maxRightX = centerRightX;
            minRightY = maxRightY = centerRightY;
        }

        void add(float x, float y, float rx, float ry) {
            minLeftX = Math.min(minLeftX, x);
            maxLeftX = Math.max(maxLeftX, x);
            minLeftY = Math.min(minLeftY, y);
            maxLeftY = Math.max(maxLeftY, y);
            minRightX = Math.min(minRightX, rx);
            maxRightX = Math.max(maxRightX, rx);
            minRightY = Math.min(minRightY, ry);
            maxRightY = Math.max(maxRightY, ry);
            samples++;
        }
    }
}
