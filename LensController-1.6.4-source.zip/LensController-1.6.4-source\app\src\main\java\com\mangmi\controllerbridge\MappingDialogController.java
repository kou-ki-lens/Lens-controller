package com.mangmi.controllerbridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class MappingDialogController {
    public interface Listener {
        void onMappingChanged(String name, Map<Integer, Integer> mapping);
    }

    private final Activity activity;
    private final AppPreferences preferences;
    private final GamepadInputMapper inputMapper;
    private final Listener listener;
    private int captureAction = ButtonMapping.ACTION_NONE;
    private Map<Integer, Integer> editingMapping;
    private Map<Integer, TextView> mappingLabels;
    private TextView captureHint;
    private AlertDialog editorDialog;

    public MappingDialogController(
            Activity activity,
            AppPreferences preferences,
            GamepadInputMapper inputMapper,
            Listener listener) {
        this.activity = activity;
        this.preferences = preferences;
        this.inputMapper = inputMapper;
        this.listener = listener;
    }

    public void showLayoutPicker() {
        List<String> names = preferences.getLayoutNames();
        String[] items = names.toArray(new String[0]);
        int activeIndex = Math.max(0, names.indexOf(preferences.getActiveLayoutName()));
        AlertDialog.Builder builder =
                new AlertDialog.Builder(activity)
                        .setTitle("按键映射布局")
                        .setSingleChoiceItems(
                                items,
                                activeIndex,
                                (dialog, which) -> {
                                    String name = items[which];
                                    activate(name);
                                    dialog.dismiss();
                                })
                        .setPositiveButton(
                                "编辑当前",
                                (dialog, which) -> {
                                    String active = preferences.getActiveLayoutName();
                                    if (preferences.hasCustomLayout(active)) {
                                        activity.getWindow()
                                                .getDecorView()
                                                .postDelayed(() -> showCustomEditor(active), 150L);
                                    } else {
                                        Toast.makeText(
                                                        activity,
                                                        "请先选择或新建一个自定义布局",
                                                        Toast.LENGTH_SHORT)
                                                .show();
                                    }
                                })
                        .setNeutralButton("新建", (dialog, which) -> showCreateDialog())
                        .setNegativeButton("关闭", null);
        builder.show();
    }

    public void showPresetEditor(OutputProfile profile) {
        String name = AppPreferences.presetLayoutName(profile);
        showEditor(
                name,
                preferences.getPresetMapping(profile),
                mapping -> preferences.savePresetMapping(profile, mapping));
    }

    private void showCreateDialog() {
        EditText nameInput = new EditText(activity);
        nameInput.setHint("例如：格斗布局、赛车布局");
        nameInput.setSingleLine(true);
        nameInput.setInputType(InputType.TYPE_CLASS_TEXT);
        int padding = dp(20);
        nameInput.setPadding(padding, padding / 2, padding, padding / 2);

        AlertDialog dialog =
                new AlertDialog.Builder(activity)
                        .setTitle("新建自定义布局")
                        .setView(nameInput)
                        .setPositiveButton(
                                "创建并编辑",
                                (ignored, which) -> {
                                    String name = nameInput.getText().toString().trim();
                                    if (name.isEmpty()) {
                                        Toast.makeText(
                                                        activity,
                                                        "布局名称不能为空",
                                                        Toast.LENGTH_SHORT)
                                                .show();
                                        return;
                                    }
                                    if (AppPreferences.isPresetLayout(name)) {
                                        Toast.makeText(
                                                        activity,
                                                        "该名称已被预设布局使用",
                                                        Toast.LENGTH_SHORT)
                                                .show();
                                        return;
                                    }
                                    if (preferences.hasCustomLayout(name)) {
                                        Toast.makeText(
                                                        activity,
                                                        "已存在同名布局",
                                                        Toast.LENGTH_SHORT)
                                                .show();
                                        return;
                                    }
                                    preferences.saveCustomLayout(
                                            name, preferences.getActiveMapping());
                                    activate(name);
                                    activity.getWindow()
                                            .getDecorView()
                                            .postDelayed(() -> showCustomEditor(name), 150L);
                                })
                        .setNegativeButton("取消", null)
                        .create();
        dialog.show();
        dialog.getWindow().getDecorView().setFocusableInTouchMode(true);
        dialog.getWindow().getDecorView().requestFocus();
    }

    private void showCustomEditor(String layoutName) {
        Map<String, Map<Integer, Integer>> layouts = preferences.getCustomLayouts();
        Map<Integer, Integer> stored = layouts.get(layoutName);
        if (stored == null) {
            return;
        }
        showEditor(
                layoutName,
                stored,
                mapping -> preferences.saveCustomLayout(layoutName, mapping));
    }

    private void showEditor(
            String layoutName,
            Map<Integer, Integer> stored,
            java.util.function.Consumer<Map<Integer, Integer>> saveMapping) {
        editingMapping = new LinkedHashMap<>(stored);
        mappingLabels = new LinkedHashMap<>();
        captureAction = ButtonMapping.ACTION_NONE;

        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(6), dp(22), dp(8));

        captureHint = new TextView(activity);
        captureHint.setText("点击“更换”后，再按掌机上的物理按键。");
        captureHint.setTextSize(12);
        captureHint.setTextColor(Color.rgb(90, 102, 120));
        captureHint.setPadding(0, 0, 0, dp(10));
        content.addView(captureHint, matchWrap());

        for (int action = 0; action < ButtonMapping.ACTION_LABELS.length; action++) {
            content.addView(createActionRow(action), matchWrap());
        }

        ScrollView scrollView = new ScrollView(activity);
        scrollView.addView(content);

        AlertDialog dialog =
                new AlertDialog.Builder(activity)
                        .setTitle("编辑：" + layoutName)
                        .setView(scrollView)
                        .setPositiveButton("保存", null)
                        .setNeutralButton("恢复标准", null)
                        .setNegativeButton("取消", null)
                        .create();
        editorDialog = dialog;
        dialog.setOnDismissListener(
                ignored -> {
                    captureAction = ButtonMapping.ACTION_NONE;
                    editingMapping = null;
                    mappingLabels = null;
                    captureHint = null;
                    editorDialog = null;
                });

        dialog.setOnShowListener(
                ignored -> {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                            .setOnClickListener(
                                    view -> {
                                        saveMapping.accept(editingMapping);
                                        activate(layoutName);
                                        dialog.dismiss();
                                    });
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
                            .setOnClickListener(
                                    view -> {
                                        editingMapping = new LinkedHashMap<>(ButtonMapping.standard());
                                        refreshMappingLabels();
                                    });
                    dialog.getWindow()
                            .getDecorView()
                            .setOnKeyListener(
                                    (view, keyCode, event) ->
                                            handleCaptureKeyEvent(keyCode, event));
                });

        dialog.setOnKeyListener(
                (ignored, keyCode, event) -> handleCaptureKeyEvent(keyCode, event));
        dialog.show();
        dialog.getWindow().getDecorView().setFocusableInTouchMode(true);
        dialog.getWindow().getDecorView().requestFocus();
    }

    private boolean handleCaptureKeyEvent(int keyCode, KeyEvent event) {
        if (captureAction == ButtonMapping.ACTION_NONE) {
            return false;
        }
        if (event.getAction() != KeyEvent.ACTION_DOWN || event.getRepeatCount() > 0) {
            return true;
        }
        ButtonMapping.bind(editingMapping, keyCode, captureAction);
        captureAction = ButtonMapping.ACTION_NONE;
        captureHint.setText("已记录按键，继续修改或点击保存。");
        refreshMappingLabels();
        return true;
    }

    private LinearLayout createActionRow(int action) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView actionLabel = text(ButtonMapping.ACTION_LABELS[action], 12, Color.rgb(36, 43, 54));
        actionLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        row.addView(actionLabel, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView keyLabel =
                text(ButtonMapping.keysLabel(editingMapping, action), 10, Color.rgb(104, 115, 132));
        keyLabel.setSingleLine(true);
        mappingLabels.put(action, keyLabel);
        LinearLayout.LayoutParams keyParams =
                new LinearLayout.LayoutParams(0, -2, 1.2f);
        keyParams.setMarginEnd(dp(8));
        row.addView(keyLabel, keyParams);

        Button change = new Button(activity);
        change.setText("更换");
        change.setTextSize(10);
        change.setAllCaps(false);
        change.setOnClickListener(
                view -> {
                    captureAction = action;
                    captureHint.setText(
                            "请按掌机按键，映射到 “"
                                    + ButtonMapping.ACTION_LABELS[action]
                                    + "”");
                    view.clearFocus();
                    if (editorDialog != null && editorDialog.getWindow() != null) {
                        editorDialog.getWindow().getDecorView().requestFocus();
                    }
                });
        change.setOnKeyListener(
                (view, keyCode, event) -> handleCaptureKeyEvent(keyCode, event));
        row.addView(change, new LinearLayout.LayoutParams(dp(66), dp(38)));
        return row;
    }

    private void refreshMappingLabels() {
        for (Map.Entry<Integer, TextView> entry : mappingLabels.entrySet()) {
            entry.getValue()
                    .setText(ButtonMapping.keysLabel(editingMapping, entry.getKey()));
        }
    }

    private void activate(String name) {
        preferences.setActiveLayout(name);
        Map<Integer, Integer> mapping = preferences.getActiveMapping();
        inputMapper.setKeyMapping(mapping);
        listener.onMappingChanged(name, mapping);
    }

    private TextView text(String value, float sizeSp, int color) {
        TextView view = new TextView(activity);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setIncludeFontPadding(false);
        return view;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }
}
