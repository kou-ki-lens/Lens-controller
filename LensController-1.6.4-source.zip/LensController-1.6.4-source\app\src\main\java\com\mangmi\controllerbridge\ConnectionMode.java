package com.mangmi.controllerbridge;

public enum ConnectionMode {
    BLUETOOTH("蓝牙桥接"),
    USB("USB 有线");

    public final String displayName;

    ConnectionMode(String displayName) {
        this.displayName = displayName;
    }
}
