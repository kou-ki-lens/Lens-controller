"use strict";

const { parentPort, workerData } = require("node:worker_threads");
const koffi = require("koffi");

const ws2 = koffi.load("ws2_32.dll");
const WSAGetLastError = ws2.func("WSAGetLastError", "int", []);
const sendFn = ws2.func("send", "int", ["intptr_t", "void *", "int", "int"]);
const socket = workerData.socket;

parentPort.on("message", (message) => {
  if (message.type !== "rumble") {
    return;
  }
  const line = Buffer.from(
    `LENSRUMBLE ${Math.max(0, Math.min(255, message.left))} ${Math.max(
      0,
      Math.min(255, message.right),
    )}\n`,
    "ascii",
  );
  const pointer = koffi.alloc("uint8", line.length);
  try {
    koffi.encode(pointer, koffi.array("uint8", line.length), Array.from(line));
    const sent = sendFn(socket, pointer, line.length, 0);
    if (sent !== line.length) {
      parentPort.postMessage({
        type: "log",
        message: `震动反馈发送失败：WSA 错误 ${WSAGetLastError()}`,
      });
    }
  } catch (error) {
    parentPort.postMessage({
      type: "log",
      message: `震动反馈异常：${error.message}`,
    });
  } finally {
    koffi.free(pointer);
  }
});
