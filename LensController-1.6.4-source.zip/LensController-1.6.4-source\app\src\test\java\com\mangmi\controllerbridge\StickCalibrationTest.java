package com.mangmi.controllerbridge;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class StickCalibrationTest {
    @Test
    public void centerOffsetMapsToZeroAndBothEndsReachFullRange() {
        StickCalibration.Axis axis = new StickCalibration.Axis(-0.75f, 0.9f, 0.12f);

        assertEquals(0f, axis.apply(0.12f), 0.0001f);
        assertEquals(1f, axis.apply(0.91f), 0.0001f);
        assertEquals(-1f, axis.apply(-0.76f), 0.0001f);
    }

    @Test
    public void valuesBeyondCapturedRangeAreClamped() {
        StickCalibration.Axis axis = new StickCalibration.Axis(-0.5f, 0.5f, 0f);

        assertEquals(1f, axis.apply(2f), 0.0001f);
        assertEquals(-1f, axis.apply(-2f), 0.0001f);
    }

    @Test
    public void calibrationAppliesEachAxisIndependently() {
        StickCalibration calibration =
                new StickCalibration(
                        new StickCalibration.Axis(-1f, 1f, 0.2f),
                        new StickCalibration.Axis(-1f, 1f, -0.1f),
                        new StickCalibration.Axis(-1f, 1f, 0f),
                        new StickCalibration.Axis(-1f, 1f, 0f));

        float[] mapped = calibration.apply(0.2f, -0.1f, 0.5f, -0.25f);

        assertEquals(0f, mapped[0], 0.0001f);
        assertEquals(0f, mapped[1], 0.0001f);
        assertEquals(0.5f, mapped[2], 0.0001f);
        assertEquals(-0.25f, mapped[3], 0.0001f);
    }
}
