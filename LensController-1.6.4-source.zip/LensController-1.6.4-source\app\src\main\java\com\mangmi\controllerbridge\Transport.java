package com.mangmi.controllerbridge;

interface Transport {
    interface Callback {
        void onTransportStatus(String message, boolean connected);
    }

    interface RumbleListener {
        void onRumble(int leftMotor, int rightMotor);
    }

    void start(OutputProfile profile, Callback callback);

    void send(ControllerState state, int sequence);

    void stop();

    default void setRumbleListener(RumbleListener listener) {}
}
