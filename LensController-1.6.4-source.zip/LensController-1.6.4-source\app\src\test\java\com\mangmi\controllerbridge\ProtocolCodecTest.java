package com.mangmi.controllerbridge;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.junit.Test;

public class ProtocolCodecTest {
    @Test
    public void roundTripPreservesEveryField() {
        ControllerState state =
                new ControllerState(
                        -127,
                        88,
                        -12,
                        127,
                        0,
                        255,
                        ControllerState.BUTTON_A
                                | ControllerState.BUTTON_RB
                                | ControllerState.BUTTON_DPAD_LEFT);

        byte[] packet = ProtocolCodec.encode(state, OutputProfile.DUALSHOCK_4, 231, true);
        ProtocolCodec.DecodedPacket decoded =
                ProtocolCodec.decode(packet, packet.length);

        assertEquals(state, decoded.state);
        assertEquals(OutputProfile.DUALSHOCK_4, decoded.profile);
        assertEquals(231, decoded.sequence);
        assertTrue(decoded.active);
    }

    @Test
    public void checksumRejectsCorruptPacket() {
        byte[] packet =
                ProtocolCodec.encode(ControllerState.NEUTRAL, OutputProfile.XBOX, 1, true);
        packet[10] ^= 0x40;

        assertThrows(
                IllegalArgumentException.class,
                () -> ProtocolCodec.decode(packet, packet.length));
    }

    @Test
    public void neutralStateIsNotActiveInFlagsUnlessRequested() {
        byte[] packet =
                ProtocolCodec.encode(ControllerState.NEUTRAL, OutputProfile.XBOX, 0, false);
        ProtocolCodec.DecodedPacket decoded =
                ProtocolCodec.decode(packet, packet.length);

        assertFalse(decoded.active);
        assertEquals(ControllerState.NEUTRAL, decoded.state);
    }

    @Test
    public void valuesAreClampedBeforeTransmission() {
        ControllerState state = new ControllerState(999, -999, 200, -200, -8, 999, 0xFFFFF);

        assertEquals(127, state.leftX);
        assertEquals(-127, state.leftY);
        assertEquals(0, state.leftTrigger);
        assertEquals(255, state.rightTrigger);
        assertEquals(0xFFFF, state.buttons);
    }

    @Test
    public void handshakeCarriesCustomControllerName() {
        byte[] packet = ProtocolCodec.encodeHandshake("客厅手柄");
        String text = new String(packet, StandardCharsets.US_ASCII);
        assertTrue(text.startsWith("LENS1 "));
        assertTrue(text.endsWith("\n"));
        String encoded = text.substring(6, text.length() - 1);
        assertEquals(
                "客厅手柄",
                new String(Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8));
    }

    @Test
    public void batteryAndTouchpadStateRoundTrip() {
        ControllerState state =
                new ControllerState(
                        1,
                        2,
                        3,
                        4,
                        5,
                        6,
                        ControllerState.BUTTON_A,
                        76,
                        true,
                        true,
                        4,
                        960,
                        471,
                        false,
                        5,
                        1200,
                        300,
                        true);

        byte[] packet =
                ProtocolCodec.encode(state, OutputProfile.DUALSHOCK_4, 9, true);
        ProtocolCodec.DecodedPacket decoded =
                ProtocolCodec.decode(packet, packet.length);

        assertEquals(state, decoded.state);
        assertEquals(76, decoded.state.batteryPercent);
        assertEquals(4, decoded.state.touch1Id);
        assertEquals(960, decoded.state.touch1X);
    }

}
