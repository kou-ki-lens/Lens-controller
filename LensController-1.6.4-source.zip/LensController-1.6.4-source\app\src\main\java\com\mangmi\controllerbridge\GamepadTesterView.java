package com.mangmi.controllerbridge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

public final class GamepadTesterView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private ControllerState state = ControllerState.NEUTRAL;
    private String deviceName = "等待手柄输入";
    private boolean active;
    private int deadZonePercent = 8;
    private boolean calibrated;
    private OutputProfile outputProfile = OutputProfile.XBOX;

    public GamepadTesterView(Context context) {
        this(context, null);
    }

    public GamepadTesterView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        textPaint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
    }

    public void setInput(ControllerState nextState, String nextDeviceName, boolean nextActive) {
        state = nextState;
        deviceName = nextDeviceName;
        active = nextActive;
        invalidate();
    }

    public void setTuning(int nextDeadZonePercent, boolean nextCalibrated) {
        deadZonePercent = nextDeadZonePercent;
        calibrated = nextCalibrated;
        invalidate();
    }

    public void setOutputProfile(OutputProfile nextProfile) {
        if (outputProfile == nextProfile) {
            return;
        }
        outputProfile = nextProfile;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = getWidth();
        float height = getHeight();
        float pad = dp(20);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(18, 22, 30));
        rect.set(0, 0, width, height);
        canvas.drawRoundRect(rect, dp(26), dp(26), paint);

        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextSize(dp(17));
        textPaint.setColor(Color.WHITE);
        canvas.drawText("实时输入监测", pad, dp(34), textPaint);

        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        textPaint.setTextSize(dp(9));
        textPaint.setColor(active ? Color.rgb(103, 224, 157) : Color.rgb(128, 138, 156));
        canvas.drawText(active ? "ONLINE" : "STANDBY", width - pad, dp(30), textPaint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(active ? Color.rgb(103, 224, 157) : Color.rgb(116, 126, 143));
        canvas.drawCircle(width - pad - dp(50), dp(26), dp(4), paint);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(dp(10));
        textPaint.setColor(Color.rgb(146, 157, 176));
        canvas.drawText(ellipsize(deviceName, width - pad * 2), width / 2f, dp(55), textPaint);

        rect.set(pad, dp(70), width - pad, height - pad);
        paint.setColor(Color.rgb(27, 32, 42));
        canvas.drawRoundRect(rect, dp(20), dp(20), paint);

        float contentLeft = pad + dp(13);
        float contentRight = width - pad - dp(13);
        float contentWidth = contentRight - contentLeft;
        float contentTop = dp(82);
        float contentBottom = height - pad - dp(12);

        drawTrigger(canvas, contentLeft, contentTop + dp(20), contentWidth * 0.38f,
                state.leftTrigger, isPlayStation() ? "L2" : "LT");
        drawTrigger(canvas, contentRight - contentWidth * 0.38f, contentTop + dp(20),
                contentWidth * 0.38f, state.rightTrigger, isPlayStation() ? "R2" : "RT");

        drawBumper(canvas, contentLeft, contentTop + dp(54), contentWidth * 0.31f,
                isPlayStation() ? "L1" : "LB",
                state.hasButton(ControllerState.BUTTON_LB));
        drawBumper(canvas, contentRight - contentWidth * 0.31f, contentTop + dp(54),
                contentWidth * 0.31f, isPlayStation() ? "R1" : "RB",
                state.hasButton(ControllerState.BUTTON_RB));

        if (isPlayStation()) {
            drawTouchpad(canvas, width / 2f, contentTop + dp(83), contentWidth * 0.15f);
        }

        float stickY = contentTop + (contentBottom - contentTop) * 0.37f;
        float stickRadius = Math.min(dp(47), contentWidth * 0.145f);
        drawStick(canvas, contentLeft + contentWidth * 0.31f, stickY, stickRadius,
                state.leftX, state.leftY, "L");
        drawStick(canvas, contentRight - contentWidth * 0.31f, stickY, stickRadius,
                state.rightX, state.rightY, "R");

        // Keep both lower control clusters on one baseline. Their captions sit directly
        // beneath each cluster instead of between the sticks and face buttons.
        float lowerY = contentBottom - dp(94);
        float dpadX = contentLeft + contentWidth * 0.25f;
        float faceX = contentRight - contentWidth * 0.25f;
        drawDpad(canvas, dpadX, lowerY);
        drawFaceCluster(canvas, faceX, lowerY);
        drawControlLabel(canvas, dpadX, lowerY + dp(52), "D-PAD");
        drawControlLabel(canvas, faceX, lowerY + dp(52), "FACE BUTTONS");

        float statusY = contentBottom - dp(15);
        drawSmallButton(canvas, width / 2f - dp(64), statusY,
                isPlayStation() ? "SHARE" : "BACK",
                ControllerState.BUTTON_BACK);
        drawSmallButton(canvas, width / 2f - dp(6), statusY,
                isPlayStation() ? "OPTIONS" : "START",
                ControllerState.BUTTON_START);
        drawSmallButton(canvas, width / 2f + dp(52), statusY,
                isPlayStation() ? "PS" : "GUIDE",
                ControllerState.BUTTON_GUIDE);

        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        textPaint.setTextSize(dp(8));
        textPaint.setColor(Color.rgb(121, 132, 150));
        canvas.drawText(
                "死区 " + deadZonePercent + "%  ·  " + (calibrated ? "已校准" : "未校准"),
                contentLeft,
                contentBottom + dp(1),
                textPaint);
    }

    private void drawStick(
            Canvas canvas, float cx, float cy, float radius, int x, int y, String label) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.rgb(63, 73, 90));
        canvas.drawCircle(cx, cy, radius, paint);
        canvas.drawCircle(cx, cy, radius * 0.47f, paint);

        paint.setStrokeWidth(dp(1.5f));
        paint.setColor(Color.rgb(43, 51, 65));
        canvas.drawLine(cx - radius, cy, cx + radius, cy, paint);
        canvas.drawLine(cx, cy - radius, cx, cy + radius, paint);

        float dotX = cx + x / 127f * radius * 0.64f;
        float dotY = cy + y / 127f * radius * 0.64f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(34, 248, 200, 78));
        canvas.drawCircle(dotX, dotY, dp(15), paint);
        paint.setColor(Color.rgb(248, 200, 78));
        canvas.drawCircle(dotX, dotY, dp(7), paint);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextSize(dp(9));
        textPaint.setColor(Color.rgb(133, 145, 164));
        canvas.drawText(label + " STICK", cx, cy + radius + dp(10), textPaint);
    }

    private void drawFaceCluster(Canvas canvas, float cx, float cy) {
        float offset = dp(30);
        drawFaceButton(canvas, cx, cy - offset,
                isPlayStation() ? "△" : "Y", ControllerState.BUTTON_Y,
                Color.rgb(248, 200, 78));
        drawFaceButton(canvas, cx - offset, cy,
                isPlayStation() ? "□" : "X", ControllerState.BUTTON_X,
                isPlayStation() ? Color.rgb(226, 112, 174) : Color.rgb(96, 171, 255));
        drawFaceButton(canvas, cx + offset, cy,
                isPlayStation() ? "○" : "B", ControllerState.BUTTON_B,
                Color.rgb(250, 111, 112));
        drawFaceButton(canvas, cx, cy + offset,
                isPlayStation() ? "×" : "A", ControllerState.BUTTON_A,
                Color.rgb(96, 171, 255));
    }

    private void drawTouchpad(Canvas canvas, float cx, float cy, float width) {
        float height = dp(20);
        rect.set(cx - width / 2f, cy - height / 2f, cx + width / 2f, cy + height / 2f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(31, 37, 48));
        canvas.drawRoundRect(rect, dp(11), dp(11), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.rgb(118, 130, 149));
        canvas.drawRoundRect(rect, dp(11), dp(11), paint);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextSize(dp(7));
        textPaint.setColor(Color.rgb(145, 157, 176));
        canvas.drawText("TOUCH", cx, cy + dp(2.5f), textPaint);
    }

    private boolean isPlayStation() {
        return outputProfile != OutputProfile.XBOX;
    }

    private void drawFaceButton(Canvas canvas, float cx, float cy, String label, int mask, int color) {
        boolean pressed = state.hasButton(mask);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(pressed ? color : Color.rgb(39, 46, 59));
        canvas.drawCircle(cx, cy, dp(12.5f), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(pressed ? color : Color.argb(105, 139, 151, 170));
        canvas.drawCircle(cx, cy, dp(12.5f), paint);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextSize(dp(9));
        textPaint.setColor(pressed ? Color.rgb(18, 22, 30) : color);
        canvas.drawText(label, cx, cy + dp(3.2f), textPaint);
    }

    private void drawDpad(Canvas canvas, float cx, float cy) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(43, 51, 64));
        canvas.drawCircle(cx, cy, dp(39), paint);
        drawDpadArm(canvas, cx, cy - dp(20), false, true);
        drawDpadArm(canvas, cx, cy + dp(20), false, false);
        drawDpadArm(canvas, cx - dp(20), cy, true, true);
        drawDpadArm(canvas, cx + dp(20), cy, true, false);
        paint.setColor(Color.rgb(59, 68, 83));
        canvas.drawCircle(cx, cy, dp(5), paint);
    }

    private void drawControlLabel(Canvas canvas, float cx, float y, String label) {
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(dp(8));
        textPaint.setColor(Color.rgb(126, 138, 156));
        canvas.drawText(label, cx, y, textPaint);
    }

    private void drawDpadArm(Canvas canvas, float cx, float cy, boolean horizontal, boolean first) {
        int mask;
        if (horizontal) {
            mask = first ? ControllerState.BUTTON_DPAD_LEFT : ControllerState.BUTTON_DPAD_RIGHT;
        } else {
            mask = first ? ControllerState.BUTTON_DPAD_UP : ControllerState.BUTTON_DPAD_DOWN;
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(
                state.hasButton(mask)
                        ? Color.rgb(248, 200, 78)
                        : Color.rgb(51, 60, 74));
        if (horizontal) {
            rect.set(cx - dp(10), cy - dp(6), cx + dp(10), cy + dp(6));
        } else {
            rect.set(cx - dp(6), cy - dp(10), cx + dp(6), cy + dp(10));
        }
        canvas.drawRoundRect(rect, dp(3), dp(3), paint);
    }

    private void drawTrigger(
            Canvas canvas, float x, float y, float width, int value, String label) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(43, 50, 63));
        rect.set(x, y, x + width, y + dp(5));
        canvas.drawRoundRect(rect, dp(3), dp(3), paint);
        paint.setColor(Color.rgb(248, 200, 78));
        rect.set(x, y, x + width * value / 255f, y + dp(5));
        canvas.drawRoundRect(rect, dp(3), dp(3), paint);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(dp(8));
        textPaint.setColor(Color.rgb(133, 145, 163));
        canvas.drawText(label + "  " + value, x, y - dp(5), textPaint);
    }

    private void drawBumper(
            Canvas canvas, float x, float y, float width, String label, boolean pressed) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(pressed ? Color.rgb(248, 200, 78) : Color.rgb(40, 47, 60));
        rect.set(x, y, x + width, y + dp(23));
        canvas.drawRoundRect(rect, dp(11), dp(11), paint);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextSize(dp(8));
        textPaint.setColor(pressed ? Color.rgb(18, 22, 30) : Color.rgb(161, 172, 189));
        canvas.drawText(label, x + width / 2f, y + dp(15), textPaint);
    }

    private void drawSmallButton(Canvas canvas, float x, float y, String label, int mask) {
        boolean pressed = state.hasButton(mask);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(pressed ? Color.rgb(248, 200, 78) : Color.rgb(40, 47, 60));
        rect.set(x, y - dp(9), x + dp(52), y + dp(9));
        canvas.drawRoundRect(rect, dp(8), dp(8), paint);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextSize(dp(6.8f));
        textPaint.setColor(pressed ? Color.rgb(18, 22, 30) : Color.rgb(137, 149, 167));
        canvas.drawText(label, x + dp(26), y + dp(2.4f), textPaint);
    }

    private String ellipsize(String value, float maxWidth) {
        if (textPaint.measureText(value) <= maxWidth) {
            return value;
        }
        String suffix = "…";
        while (value.length() > 1 && textPaint.measureText(value + suffix) > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }
        return value + suffix;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
