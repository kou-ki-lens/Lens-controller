"use strict";

const koffi = require("koffi");

const SYSTEMTIME = koffi.struct("LENS_SYSTEMTIME", {
  Year: "uint16",
  Month: "uint16",
  DayOfWeek: "uint16",
  Day: "uint16",
  Hour: "uint16",
  Minute: "uint16",
  Second: "uint16",
  Milliseconds: "uint16",
});

const DEVICE_INFO = koffi.struct("LENS_BLUETOOTH_DEVICE_INFO", {
  dwSize: "uint32",
  Address: "uint64",
  ulClassofDevice: "uint32",
  fConnected: "int32",
  fRemembered: "int32",
  fAuthenticated: "int32",
  stLastSeen: SYSTEMTIME,
  stLastUsed: SYSTEMTIME,
  szName: koffi.array("char16", 248),
});

const SEARCH_PARAMS = koffi.struct("LENS_BLUETOOTH_DEVICE_SEARCH_PARAMS", {
  dwSize: "uint32",
  fReturnAuthenticated: "int32",
  fReturnRemembered: "int32",
  fReturnUnknown: "int32",
  fReturnConnected: "int32",
  fIssueInquiry: "int32",
  cTimeoutMultiplier: "uint8",
  hRadio: "void *",
});

const bth = koffi.load("bthprops.cpl");
const findFirst = bth.func("BluetoothFindFirstDevice", "void *", ["void *", "void *"]);
const findNext = bth.func("BluetoothFindNextDevice", "int", ["void *", "void *"]);
const findClose = bth.func("BluetoothFindDeviceClose", "int", ["void *"]);

function discoverBluetoothDevices({ includeUnknown = false } = {}) {
  const searchPointer = koffi.alloc(SEARCH_PARAMS, 1);
  const infoPointer = koffi.alloc(DEVICE_INFO, 1);
  const results = [];
  let handle = null;
  try {
    koffi.encode(searchPointer, SEARCH_PARAMS, {
      dwSize: koffi.sizeof(SEARCH_PARAMS),
      fReturnAuthenticated: 1,
      fReturnRemembered: 1,
      fReturnUnknown: includeUnknown ? 1 : 0,
      fReturnConnected: 1,
      fIssueInquiry: includeUnknown ? 1 : 0,
      cTimeoutMultiplier: includeUnknown ? 3 : 0,
      hRadio: null,
    });
    koffi.encode(infoPointer, DEVICE_INFO, { dwSize: koffi.sizeof(DEVICE_INFO) });
    handle = findFirst(searchPointer, infoPointer);
    if (handle) {
      do {
        const info = koffi.decode(infoPointer, DEVICE_INFO);
        const name = String(info.szName || "");
        results.push({
          name,
          address: BigInt(info.Address)
            .toString(16)
            .toUpperCase()
            .padStart(12, "0"),
          connected: info.fConnected !== 0,
          remembered: info.fRemembered !== 0,
          authenticated: info.fAuthenticated !== 0,
          deviceClass: info.ulClassofDevice,
        });
      } while (findNext(handle, infoPointer) !== 0);
    }
  } finally {
    if (handle) {
      findClose(handle);
    }
    koffi.free(infoPointer);
    koffi.free(searchPointer);
  }
  return results;
}

function selectAndroidDevices(devices) {
  const preferredNames =
    /(AIR X|Lens controller|Android|掌机|handheld|gamepad|controller)/i;
  const isAudio = (device) => ((device.deviceClass >>> 8) & 0x1f) === 4;
  const unique = new Map();
  for (const device of devices) {
    if (device.address && !unique.has(device.address)) {
      unique.set(device.address, device);
    }
  }
  return [...unique.values()]
    .filter((device) => !isAudio(device))
    .sort((left, right) => {
      const score = (device) =>
        (preferredNames.test(device.name) ? 8 : 0) +
        (device.connected ? 4 : 0) +
        (device.remembered ? 2 : 0) +
        (device.authenticated ? 1 : 0);
      return score(right) - score(left);
    });
}

function findAndroidDevices({ includeUnknown = false } = {}) {
  return selectAndroidDevices(discoverBluetoothDevices({ includeUnknown }));
}

function findAndroidDevice(options = {}) {
  return findAndroidDevices(options)[0] || null;
}

module.exports = {
  DEVICE_INFO,
  SEARCH_PARAMS,
  discoverBluetoothDevices,
  findAndroidDevice,
  findAndroidDevices,
  selectAndroidDevices,
};
