﻿$ErrorActionPreference = "Stop"

$currentRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
foreach ($process in Get-CimInstance Win32_Process -ErrorAction SilentlyContinue) {
    $commandLine = [string]$process.CommandLine
    $isLensGui =
        $process.Name -eq "powershell.exe" -and
        $commandLine -match "LensControllerPC\.ps1" -and
        $commandLine -notlike "*$currentRoot\LensControllerPC.ps1*"
    $isLensService =
        $process.Name -eq "node.exe" -and
        $commandLine -match "server\.js" -and
        (
            $commandLine -match "Lens controller" -or
            [string]$process.ExecutablePath -match "\\runtime\\node\.exe$"
        )
    if ($isLensGui -or $isLensService) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}
Start-Sleep -Milliseconds 400

$service = Get-Service -Name ViGEmBus -ErrorAction SilentlyContinue
if (-not $service) {
    $driverInstaller = Join-Path $PSScriptRoot "driver\ViGEmBus_1.22.0_x64_x86_arm64.exe"
    if (-not (Test-Path -LiteralPath $driverInstaller)) {
        throw "未找到 ViGEmBus 驱动安装包。"
    }
    $process = Start-Process `
        -FilePath $driverInstaller `
        -ArgumentList "/quiet /norestart" `
        -Wait `
        -PassThru
    if ($process.ExitCode -ne 0) {
        throw "ViGEmBus 驱动安装失败，错误码：$($process.ExitCode)"
    }
    Set-Content `
        -LiteralPath (Join-Path $PSScriptRoot "driver-installed-by-lens.flag") `
        -Value "1" `
        -Encoding ASCII
}

$rules = @(
    @{ Name = "Mangmi Bridge USB Discovery"; Protocol = "UDP"; Port = 47653 },
    @{ Name = "Mangmi Bridge USB Input"; Protocol = "TCP"; Port = 47654 }
)
foreach ($rule in $rules) {
    try {
        if (-not (Get-NetFirewallRule -DisplayName $rule.Name -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule `
                -DisplayName $rule.Name `
                -Direction Inbound `
                -Action Allow `
                -Protocol $rule.Protocol `
                -LocalPort $rule.Port `
                -RemoteAddress LocalSubnet `
                -Profile Any | Out-Null
        }
    } catch {
        # ADB reverse works without inbound network access.
    }
}

$nodePath = Join-Path $PSScriptRoot "runtime\node.exe"
if (Test-Path -LiteralPath $nodePath) {
    try {
        if (-not (Get-NetFirewallRule -DisplayName "Lens controller PC Service" -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule `
                -DisplayName "Lens controller PC Service" `
                -Direction Inbound `
                -Action Allow `
                -Program $nodePath `
                -Profile Any | Out-Null
        }
    } catch {
        # The TCP/UDP port rules still cover the fixed service ports.
    }
}
