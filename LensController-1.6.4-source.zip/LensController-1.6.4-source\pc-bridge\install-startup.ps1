﻿$ErrorActionPreference = "Stop"

$startScript = Join-Path $PSScriptRoot "start-pc.vbs"
if (-not (Test-Path -LiteralPath $startScript)) {
    throw "未找到 PC 配套程序启动脚本：$startScript"
}

$startupDirectory = [Environment]::GetFolderPath("Startup")
$shortcutPath = Join-Path $startupDirectory "Lens controller PC.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
$shortcut.Arguments = "`"$startScript`" -Autostart"
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.WindowStyle = 7
$shortcut.Description = "Lens controller 蓝牙/USB 虚拟手柄服务"
$iconPath = Join-Path $PSScriptRoot "app.ico"
if (Test-Path -LiteralPath $iconPath) {
    $shortcut.IconLocation = "$iconPath,0"
}
$shortcut.Save()

Write-Host "已启用 Windows 登录自启动：$shortcutPath" -ForegroundColor Green
