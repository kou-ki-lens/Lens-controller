package com.mangmi.controllerbridge;

import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ButtonMapping {
    public static final int ACTION_A = 0;
    public static final int ACTION_B = 1;
    public static final int ACTION_X = 2;
    public static final int ACTION_Y = 3;
    public static final int ACTION_LB = 4;
    public static final int ACTION_RB = 5;
    public static final int ACTION_BACK = 6;
    public static final int ACTION_START = 7;
    public static final int ACTION_GUIDE = 8;
    public static final int ACTION_LS = 9;
    public static final int ACTION_RS = 10;
    public static final int ACTION_DPAD_UP = 11;
    public static final int ACTION_DPAD_DOWN = 12;
    public static final int ACTION_DPAD_LEFT = 13;
    public static final int ACTION_DPAD_RIGHT = 14;
    public static final int ACTION_LT = 15;
    public static final int ACTION_RT = 16;
    public static final int ACTION_NONE = -1;

    public static final String[] ACTION_LABELS = {
        "A / Cross",
        "B / Circle",
        "X / Square",
        "Y / Triangle",
        "LB / L1",
        "RB / R1",
        "Back / Share",
        "Start / Options",
        "Guide / PS",
        "左摇杆按下",
        "右摇杆按下",
        "十字键上",
        "十字键下",
        "十字键左",
        "十字键右",
        "左扳机 LT",
        "右扳机 RT"
    };

    private ButtonMapping() {}

    public static Map<Integer, Integer> standard() {
        LinkedHashMap<Integer, Integer> map = new LinkedHashMap<>();
        map.put(KeyEvent.KEYCODE_BUTTON_A, ACTION_A);
        map.put(KeyEvent.KEYCODE_BUTTON_B, ACTION_B);
        map.put(KeyEvent.KEYCODE_BUTTON_X, ACTION_X);
        map.put(KeyEvent.KEYCODE_BUTTON_Y, ACTION_Y);
        map.put(KeyEvent.KEYCODE_BUTTON_L1, ACTION_LB);
        map.put(KeyEvent.KEYCODE_BUTTON_R1, ACTION_RB);
        map.put(KeyEvent.KEYCODE_BACK, ACTION_BACK);
        map.put(KeyEvent.KEYCODE_BUTTON_SELECT, ACTION_START);
        map.put(KeyEvent.KEYCODE_BUTTON_START, ACTION_START);
        map.put(KeyEvent.KEYCODE_BUTTON_MODE, ACTION_GUIDE);
        map.put(KeyEvent.KEYCODE_BUTTON_THUMBL, ACTION_LS);
        map.put(KeyEvent.KEYCODE_BUTTON_THUMBR, ACTION_RS);
        map.put(KeyEvent.KEYCODE_DPAD_UP, ACTION_DPAD_UP);
        map.put(KeyEvent.KEYCODE_DPAD_DOWN, ACTION_DPAD_DOWN);
        map.put(KeyEvent.KEYCODE_DPAD_LEFT, ACTION_DPAD_LEFT);
        map.put(KeyEvent.KEYCODE_DPAD_RIGHT, ACTION_DPAD_RIGHT);
        map.put(KeyEvent.KEYCODE_BUTTON_L2, ACTION_LT);
        map.put(KeyEvent.KEYCODE_BUTTON_R2, ACTION_RT);
        // Generic Android gamepads use numbered buttons when no vendor key layout exists.
        map.put(KeyEvent.KEYCODE_BUTTON_1, ACTION_A);
        map.put(KeyEvent.KEYCODE_BUTTON_2, ACTION_B);
        map.put(KeyEvent.KEYCODE_BUTTON_4, ACTION_X);
        map.put(KeyEvent.KEYCODE_BUTTON_5, ACTION_Y);
        map.put(KeyEvent.KEYCODE_BUTTON_7, ACTION_LB);
        map.put(KeyEvent.KEYCODE_BUTTON_8, ACTION_RB);
        map.put(KeyEvent.KEYCODE_BUTTON_9, ACTION_LT);
        map.put(KeyEvent.KEYCODE_BUTTON_10, ACTION_RT);
        map.put(KeyEvent.KEYCODE_BUTTON_11, ACTION_LS);
        map.put(KeyEvent.KEYCODE_BUTTON_12, ACTION_RS);
        map.put(KeyEvent.KEYCODE_BUTTON_13, ACTION_START);
        map.put(KeyEvent.KEYCODE_BUTTON_14, ACTION_BACK);
        map.put(KeyEvent.KEYCODE_BUTTON_15, ACTION_GUIDE);
        return map;
    }

    public static int buttonBit(int action) {
        return action >= ACTION_A && action <= ACTION_DPAD_RIGHT ? 1 << action : 0;
    }

    public static List<Integer> keysForAction(
            Map<Integer, Integer> mapping, int requestedAction) {
        List<Integer> keys = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : mapping.entrySet()) {
            if (entry.getValue() == requestedAction) {
                keys.add(entry.getKey());
            }
        }
        return keys;
    }

    public static String keyName(int keyCode) {
        String name = KeyEvent.keyCodeToString(keyCode);
        if (name.startsWith("KEYCODE_")) {
            name = name.substring("KEYCODE_".length());
        }
        return name.replace('_', ' ');
    }

    public static String keysLabel(Map<Integer, Integer> mapping, int action) {
        List<Integer> keys = keysForAction(mapping, action);
        if (keys.isEmpty()) {
            return "未设置";
        }
        StringBuilder label = new StringBuilder();
        for (int key : keys) {
            if (label.length() > 0) {
                label.append(" / ");
            }
            label.append(keyName(key));
        }
        return label.toString();
    }

    public static void bind(
            Map<Integer, Integer> mapping, int keyCode, int action) {
        mapping.entrySet().removeIf(entry -> entry.getValue() == action);
        mapping.entrySet().removeIf(entry -> entry.getKey() == keyCode);
        mapping.put(keyCode, action);
    }
}
