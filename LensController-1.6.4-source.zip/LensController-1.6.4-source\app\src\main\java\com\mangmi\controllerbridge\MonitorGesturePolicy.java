package com.mangmi.controllerbridge;

/**
 * Keeps the physical-controller monitor gesture identical to the 1.6.2 behavior.
 *
 * <p>Touch devices use a long press on the monitor area. Devices without a
 * touchscreen require both of these conditions: the monitor area is selected and
 * X/Square is held to enter monitoring. While monitoring is active, holding
 * B/Circle exits it.</p>
 */
public final class MonitorGesturePolicy {
    public static final int NONE = 0;
    public static final int ENTER = 1;
    public static final int EXIT = 2;

    private MonitorGesturePolicy() {}

    public static int resolve(
            boolean touchScreenAvailable,
            boolean monitorActive,
            boolean monitorFocused,
            int action) {
        if (touchScreenAvailable) {
            return NONE;
        }
        if (monitorActive && action == ButtonMapping.ACTION_B) {
            return EXIT;
        }
        if (!monitorActive
                && monitorFocused
                && action == ButtonMapping.ACTION_X) {
            return ENTER;
        }
        return NONE;
    }
}
