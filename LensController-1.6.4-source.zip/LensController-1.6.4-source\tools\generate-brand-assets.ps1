﻿$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$root = Split-Path $PSScriptRoot -Parent
$sourcePath = Join-Path $root "branding\lens-logo-source.jpg"
if (-not (Test-Path -LiteralPath $sourcePath)) {
    throw "Logo source not found: $sourcePath"
}

$source = [System.Drawing.Bitmap]::FromFile($sourcePath)
try {
    $minX = $source.Width
    $minY = $source.Height
    $maxX = 0
    $maxY = 0
    for ($y = 300; $y -lt 1360; $y += 2) {
        for ($x = 300; $x -lt 1750; $x += 2) {
            $pixel = $source.GetPixel($x, $y)
            $luma = ($pixel.R + $pixel.G + $pixel.B) / 3
            if ($luma -lt 190) {
                $minX = [Math]::Min($minX, $x)
                $minY = [Math]::Min($minY, $y)
                $maxX = [Math]::Max($maxX, $x)
                $maxY = [Math]::Max($maxY, $y)
            }
        }
    }
    $padding = 44
    $minX = [Math]::Max(0, $minX - $padding)
    $minY = [Math]::Max(0, $minY - $padding)
    $maxX = [Math]::Min($source.Width - 1, $maxX + $padding)
    $maxY = [Math]::Min($source.Height - 1, $maxY + $padding)
    $side = [Math]::Max($maxX - $minX + 1, $maxY - $minY + 1)
    $centerX = ($minX + $maxX) / 2
    $centerY = ($minY + $maxY) / 2
    $cropX = [Math]::Max(0, [Math]::Floor($centerX - $side / 2))
    $cropY = [Math]::Max(0, [Math]::Floor($centerY - $side / 2))

    function New-MarkBitmap(
        [int]$size,
        [double]$coverage,
        [string]$outputPath,
        [int]$red = 8,
        [int]$green = 11,
        [int]$blue = 16
    ) {
        $bitmap = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        $graphics.Clear([System.Drawing.Color]::White)
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $drawSize = [int]($size * $coverage)
        $offset = [int](($size - $drawSize) / 2)
        $destination = New-Object System.Drawing.Rectangle($offset, $offset, $drawSize, $drawSize)
        $sourceRect = New-Object System.Drawing.Rectangle($cropX, $cropY, $side, $side)
        $graphics.DrawImage($source, $destination, $sourceRect, [System.Drawing.GraphicsUnit]::Pixel)
        $graphics.Dispose()

        $minAxis = [int]($offset)
        $maxAxis = [int]($offset + $drawSize)
        for ($y = 0; $y -lt $size; $y++) {
            for ($x = 0; $x -lt $size; $x++) {
                $pixel = $bitmap.GetPixel($x, $y)
                if ($x -lt $minAxis -or $x -ge $maxAxis -or $y -lt $minAxis -or $y -ge $maxAxis) {
                    $bitmap.SetPixel($x, $y, [System.Drawing.Color]::Transparent)
                    continue
                }
                $luma = ($pixel.R + $pixel.G + $pixel.B) / 3
                $alpha = if ($luma -ge 247) {
                    0
                } elseif ($luma -le 35) {
                    255
                } else {
                    [int](255 * (247 - $luma) / 212)
                }
                $bitmap.SetPixel(
                    $x,
                    $y,
                    [System.Drawing.Color]::FromArgb($alpha, $red, $green, $blue)
                )
            }
        }
        $bitmap.Save($outputPath, [System.Drawing.Imaging.ImageFormat]::Png)
        return $bitmap
    }

    $branding = Join-Path $root "branding"
    $drawable = Join-Path $root "app\src\main\res\drawable-nodpi"
    $pcBridge = Join-Path $root "pc-bridge"
    New-Item -ItemType Directory -Path $branding, $drawable -Force | Out-Null
    Copy-Item -LiteralPath $sourcePath -Destination (Join-Path $branding "lens-logo-source.jpg") -Force

    $tight = New-MarkBitmap 1024 0.90 (Join-Path $branding "lens-mark.png")
    $white = New-MarkBitmap 1024 0.90 (Join-Path $branding "lens-mark-white.png") 255 255 255
    $adaptive = New-MarkBitmap 1024 0.64 (Join-Path $drawable "ic_lens_foreground.png")

    $sizes = @(16, 24, 32, 48, 64, 128, 256)
    $images = New-Object System.Collections.Generic.List[byte[]]
    foreach ($size in $sizes) {
        $scaled = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
        $graphics = [System.Drawing.Graphics]::FromImage($scaled)
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.DrawImage($tight, 0, 0, $size, $size)
        $graphics.Dispose()
        $stream = New-Object System.IO.MemoryStream
        $scaled.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png)
        $images.Add($stream.ToArray())
        $stream.Dispose()
        $scaled.Dispose()
    }

    $icoPath = Join-Path $pcBridge "app.ico"
    $file = [System.IO.File]::Create($icoPath)
    $writer = New-Object System.IO.BinaryWriter($file)
    try {
        $writer.Write([uint16]0)
        $writer.Write([uint16]1)
        $writer.Write([uint16]$sizes.Count)
        $offset = 6 + 16 * $sizes.Count
        for ($i = 0; $i -lt $sizes.Count; $i++) {
            $size = $sizes[$i]
            $writer.Write([byte]$(if ($size -ge 256) { 0 } else { $size }))
            $writer.Write([byte]$(if ($size -ge 256) { 0 } else { $size }))
            $writer.Write([byte]0)
            $writer.Write([byte]0)
            $writer.Write([uint16]1)
            $writer.Write([uint16]32)
            $writer.Write([uint32]$images[$i].Length)
            $writer.Write([uint32]$offset)
            $offset += $images[$i].Length
        }
        foreach ($image in $images) {
            $writer.Write($image)
        }
    } finally {
        $writer.Dispose()
        $file.Dispose()
    }

    $whiteImages = New-Object System.Collections.Generic.List[byte[]]
    foreach ($size in $sizes) {
        $scaled = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
        $graphics = [System.Drawing.Graphics]::FromImage($scaled)
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.DrawImage($white, 0, 0, $size, $size)
        $graphics.Dispose()
        $stream = New-Object System.IO.MemoryStream
        $scaled.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png)
        $whiteImages.Add($stream.ToArray())
        $stream.Dispose()
        $scaled.Dispose()
    }

    $whiteIcoPath = Join-Path $pcBridge "app-white.ico"
    $file = [System.IO.File]::Create($whiteIcoPath)
    $writer = New-Object System.IO.BinaryWriter($file)
    try {
        $writer.Write([uint16]0)
        $writer.Write([uint16]1)
        $writer.Write([uint16]$sizes.Count)
        $offset = 6 + 16 * $sizes.Count
        for ($i = 0; $i -lt $sizes.Count; $i++) {
            $size = $sizes[$i]
            $writer.Write([byte]$(if ($size -ge 256) { 0 } else { $size }))
            $writer.Write([byte]$(if ($size -ge 256) { 0 } else { $size }))
            $writer.Write([byte]0)
            $writer.Write([byte]0)
            $writer.Write([uint16]1)
            $writer.Write([uint16]32)
            $writer.Write([uint32]$whiteImages[$i].Length)
            $writer.Write([uint32]$offset)
            $offset += $whiteImages[$i].Length
        }
        foreach ($image in $whiteImages) {
            $writer.Write($image)
        }
    } finally {
        $writer.Dispose()
        $file.Dispose()
    }

    $tight.Dispose()
    $white.Dispose()
    $adaptive.Dispose()

    $wizardLarge = New-Object System.Drawing.Bitmap(164, 314, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $graphics = [System.Drawing.Graphics]::FromImage($wizardLarge)
    $graphics.Clear([System.Drawing.Color]::White)
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $mark = [System.Drawing.Image]::FromFile((Join-Path $branding "lens-mark.png"))
    $graphics.DrawImage($mark, 24, 35, 116, 116)
    $mark.Dispose()
    $font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = [System.Drawing.StringAlignment]::Center
    $graphics.DrawString("Lens`ncontroller", $font, [System.Drawing.Brushes]::Black, (New-Object System.Drawing.RectangleF(5, 175, 154, 70)), $format)
    $font.Dispose()
    $format.Dispose()
    $graphics.Dispose()
    $wizardLarge.Save((Join-Path $branding "wizard-large.bmp"), [System.Drawing.Imaging.ImageFormat]::Bmp)
    $wizardLarge.Dispose()

    $wizardSmall = New-Object System.Drawing.Bitmap(55, 55, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $graphics = [System.Drawing.Graphics]::FromImage($wizardSmall)
    $graphics.Clear([System.Drawing.Color]::White)
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $mark = [System.Drawing.Image]::FromFile((Join-Path $branding "lens-mark.png"))
    $graphics.DrawImage($mark, 3, 3, 49, 49)
    $mark.Dispose()
    $graphics.Dispose()
    $wizardSmall.Save((Join-Path $branding "wizard-small.bmp"), [System.Drawing.Imaging.ImageFormat]::Bmp)
    $wizardSmall.Dispose()
} finally {
    $source.Dispose()
}

Write-Host "Brand assets generated." -ForegroundColor Green
