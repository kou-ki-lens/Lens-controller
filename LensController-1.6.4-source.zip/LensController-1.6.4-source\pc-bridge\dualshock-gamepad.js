"use strict";

const koffi = require("koffi");
const path = require("node:path");

const VIGEM_SUCCESS = 0x20000000;

const REPORT_FIELDS = koffi.pack("LENS_PS_REPORT_FIELDS", {
  bThumbLX: "uint8",
  bThumbLY: "uint8",
  bThumbRX: "uint8",
  bThumbRY: "uint8",
  wButtons: "uint16",
  bSpecial: "uint8",
  bTriggerL: "uint8",
  bTriggerR: "uint8",
  wTimestamp: "uint16",
  bBatteryLvl: "uint8",
  wGyroX: "int16",
  wGyroY: "int16",
  wGyroZ: "int16",
  wAccelX: "int16",
  wAccelY: "int16",
  wAccelZ: "int16",
  unknown1: koffi.array("uint8", 5),
  bBatteryLvlSpecial: "uint8",
  unknown2: koffi.array("uint8", 2),
  bTouchPacketsN: "uint8",
  touch: koffi.array("uint8", 27),
  padding: koffi.array("uint8", 3),
});

const REPORT_EX = koffi.union("LENS_PS_REPORT_EX", {
  Report: REPORT_FIELDS,
  ReportBuffer: koffi.array("uint8", 63),
});

let rumbleNotificationType;

function getRumbleNotificationType() {
  if (!rumbleNotificationType) {
    const lightbar = koffi.struct("LENS_PS_LIGHTBAR_COLOR", {
      Red: "uint8",
      Green: "uint8",
      Blue: "uint8",
    });
    rumbleNotificationType = koffi.proto(
      "__stdcall",
      "LENS_PS_RUMBLE_NOTIFICATION",
      "void",
      ["void *", "void *", "uint8", "uint8", lightbar, "void *"],
    );
  }
  return rumbleNotificationType;
}

class DualShockGamepad {
  constructor(onVibration, buildReport, options = {}) {
    this.onVibration = onVibration;
    this.buildReport = buildReport;
    this.enableNotifications = options.enableNotifications !== false;
    this.client = null;
    this.target = null;
    this.lib = null;
    this.notificationCallback = null;
  }

  connect() {
    this.lib = koffi.load(path.join(__dirname, "native", "ViGEmClient.dll"));
    const alloc = this.lib.func("vigem_alloc", "void *", []);
    const connect = this.lib.func("vigem_connect", "int", ["void *"]);
    const allocTarget = this.lib.func("vigem_target_ds4_alloc", "void *", []);
    const addTarget = this.lib.func("vigem_target_add", "int", ["void *", "void *"]);
    this.removeTarget = this.lib.func("vigem_target_remove", "int", [
      "void *",
      "void *",
    ]);
    this.freeTarget = this.lib.func("vigem_target_free", "void", ["void *"]);
    this.disconnectClient = this.lib.func("vigem_disconnect", "void", ["void *"]);
    this.freeClient = this.lib.func("vigem_free", "void", ["void *"]);
    this.updateReport = this.lib.func("vigem_target_ds4_update_ex", "int", [
      "void *",
      "void *",
      REPORT_EX,
    ]);

    this.client = alloc();
    if (!this.client) {
      throw new Error("无法创建 ViGEm 客户端");
    }
    checkResult(connect(this.client), "连接 ViGEmBus");

    this.target = allocTarget();
    if (!this.target) {
      throw new Error("无法创建虚拟 DualShock 4 对象");
    }
    let addResult = addTarget(this.client, this.target);
    for (let retry = 0; (addResult >>> 0) === 0xe0000007 && retry < 5; retry += 1) {
      sleepSync(120);
      addResult = addTarget(this.client, this.target);
    }
    checkResult(addResult, "插入虚拟 DualShock 4");

    if (this.enableNotifications) {
      this.registerRumble();
    }
  }

  registerRumble() {
    const notification = getRumbleNotificationType();
    this.unregisterNotification = this.lib.func(
      "vigem_target_ds4_unregister_notification",
      "void",
      ["void *"],
    );
    const registerNotification = this.lib.func(
      "vigem_target_ds4_register_notification",
      "int",
      ["void *", "void *", "LENS_PS_RUMBLE_NOTIFICATION *", "void *"],
    );
    this.notificationCallback = koffi.register(
      (client, target, largeMotor, smallMotor) => {
        this.onVibration(largeMotor, smallMotor);
      },
      koffi.pointer(notification),
    );
    checkResult(
      registerNotification(
        this.client,
        this.target,
        this.notificationCallback,
        null,
      ),
      "注册 DualShock 4 震动通知",
    );
  }

  update(input) {
    if (!this.target) {
      return;
    }
    checkResult(
      this.updateReport(this.client, this.target, this.buildReport(input)),
      "更新 DualShock 4 状态",
    );
  }

  disconnect() {
    if (this.target && this.unregisterNotification) {
      this.unregisterNotification(this.target);
    }
    if (this.notificationCallback) {
      koffi.unregister(this.notificationCallback);
      this.notificationCallback = null;
    }
    if (this.client && this.target && this.removeTarget) {
      try {
        this.removeTarget(this.client, this.target);
      } catch {
        // The bus removes orphaned targets when the process exits.
      }
    }
    if (this.target && this.freeTarget) {
      this.freeTarget(this.target);
    }
    this.target = null;
    if (this.client && this.disconnectClient) {
      this.disconnectClient(this.client);
    }
    if (this.client && this.freeClient) {
      this.freeClient(this.client);
    }
    this.client = null;
  }
}

function checkResult(result, operation) {
  if ((result >>> 0) === VIGEM_SUCCESS) {
    return;
  }
  throw new Error(`${operation}失败：错误 0x${(result >>> 0).toString(16)}`);
}

function sleepSync(milliseconds) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, milliseconds);
}

module.exports = {
  DualShockGamepad,
};
