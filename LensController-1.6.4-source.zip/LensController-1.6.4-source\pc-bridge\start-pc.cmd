@echo off
setlocal
chcp 65001 >nul
title Lens controller PC 配套程序
cd /d "%~dp0"
start "" wscript.exe "%~dp0start-pc.vbs" %*
exit /b 0
