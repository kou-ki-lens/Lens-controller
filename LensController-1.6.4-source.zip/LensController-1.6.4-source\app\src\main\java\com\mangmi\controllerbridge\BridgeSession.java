package com.mangmi.controllerbridge;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;

import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class BridgeSession {
    private static final long HEARTBEAT_MS = 250L;

    public interface Listener {
        void onBridgeStatus(String message, boolean connected);
    }

    private final Context context;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService sender;
    private Transport transport;
    private volatile ControllerState currentState = ControllerState.NEUTRAL;
    private volatile boolean running;
    private volatile boolean connected;
    private volatile long stateRevision;
    private int sequence;
    private long sentRevision = -1L;
    private long lastSentAt;
    private final AtomicBoolean sendQueued = new AtomicBoolean();
    private Listener listener;
    private Transport.RumbleListener rumbleListener;

    public BridgeSession(Context context) {
        this.context = context.getApplicationContext();
    }

    public synchronized void start(
            ConnectionMode mode, OutputProfile profile, Listener listener) {
        stop();
        this.listener = listener;
        this.running = true;
        this.connected = false;
        this.sequence = 0;
        this.currentState = ControllerState.NEUTRAL;
        this.stateRevision = 0L;
        this.sentRevision = -1L;
        this.lastSentAt = 0L;
        this.sendQueued.set(false);

        sender =
                Executors.newSingleThreadScheduledExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "Lens-Input-Sender");
                            thread.setDaemon(true);
                            thread.setPriority(Thread.MAX_PRIORITY);
                            return thread;
                        });
        sender.execute(() -> Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO));
        sender.scheduleWithFixedDelay(
                this::heartbeatTick, HEARTBEAT_MS, HEARTBEAT_MS, TimeUnit.MILLISECONDS);

        transport =
                mode == ConnectionMode.BLUETOOTH
                        ? new BluetoothRfcommTransport(context)
                        : new UsbTcpTransport(context);
        transport.setRumbleListener(rumbleListener);
        transport.start(profile, this::handleTransportStatus);
    }

    public synchronized void updateState(ControllerState state) {
        if (state.equals(currentState)) {
            return;
        }
        currentState = state;
        stateRevision++;
        queueLatestState();
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isConnected() {
        return connected;
    }

    public void setRumbleListener(Transport.RumbleListener listener) {
        rumbleListener = listener;
        if (transport != null) {
            transport.setRumbleListener(listener);
        }
    }

    public synchronized void stop() {
        running = false;
        connected = false;
        sendQueued.set(false);
        if (sender != null) {
            sender.shutdownNow();
            sender = null;
        }
        if (transport != null) {
            transport.stop();
            transport = null;
        }
    }

    private void queueLatestState() {
        ScheduledExecutorService activeSender = sender;
        if (!running || !connected || activeSender == null) {
            return;
        }
        if (!sendQueued.compareAndSet(false, true)) {
            return;
        }
        try {
            activeSender.execute(this::sendLatest);
        } catch (RejectedExecutionException ignored) {
            sendQueued.set(false);
        }
    }

    private void sendLatest() {
        try {
            sendIfNeeded(false);
        } finally {
            sendQueued.set(false);
            if (running && connected && stateRevision != sentRevision) {
                queueLatestState();
            }
        }
    }

    private void heartbeatTick() {
        sendIfNeeded(false);
    }

    private void sendIfNeeded(boolean force) {
        if (!running || !connected || transport == null) {
            return;
        }

        ControllerState state = currentState;
        long revision = stateRevision;
        long now = System.nanoTime() / 1_000_000L;
        boolean changed = revision != sentRevision;
        if (!force && !changed && now - lastSentAt < HEARTBEAT_MS) {
            return;
        }
        lastSentAt = now;
        sequence = (sequence + 1) & 0xFF;
        try {
            transport.send(state, sequence);
            sentRevision = revision;
        } catch (RuntimeException exception) {
            handleTransportStatus("发送失败：" + safeMessage(exception), false);
        }
    }

    private void handleTransportStatus(String message, boolean nowConnected) {
        connected = nowConnected;
        if (nowConnected) {
            queueLatestState();
        }
        mainHandler.post(
                () -> {
                    if (listener != null) {
                        listener.onBridgeStatus(message, nowConnected);
                    }
                });
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
    }
}
