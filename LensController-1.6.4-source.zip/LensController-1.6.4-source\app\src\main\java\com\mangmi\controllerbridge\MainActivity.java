package com.mangmi.controllerbridge;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.input.InputManager;
import android.net.Uri;
import android.os.Build;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final int REQUEST_BLUETOOTH = 210;
    private static final int REQUEST_ENABLE_BLUETOOTH = 211;
    private static final int REQUEST_PICK_SCREENSAVER = 320;
    private static final int DIRECTION_LEFT = 0;
    private static final int DIRECTION_RIGHT = 1;
    private static final int DIRECTION_UP = 2;
    private static final int DIRECTION_DOWN = 3;

    private static final int INK = Color.rgb(20, 24, 33);
    private static final int MUTED = Color.rgb(105, 115, 133);
    private static final int ACCENT = Color.rgb(248, 200, 78);
    private static final int PAPER = Color.rgb(245, 247, 251);
    private static final int CARD = Color.WHITE;

    private GamepadInputMapper inputMapper;
    private BridgeSession bridgeSession;
    private AppPreferences preferences;
    private MappingDialogController mappingDialogController;
    private GamepadTesterView testerView;
    private FrameLayout monitorFrame;
    private TextView monitorDisabledOverlay;
    private NavigationCursorView navigationCursor;
    private FrameLayout rootLayout;
    private ScreensaverView screensaverView;
    private TextView statusText;
    private TextView deviceText;
    private TextView hintText;
    private TextView startButton;
    private TextView stopButton;
    private TextView xboxButton;
    private TextView ds4Button;
    private TextView bluetoothButton;
    private TextView usbButton;
    private TextView screenSaverSummaryText;
    private TextView screenSaverHintText;
    private TextView deadZoneSummaryText;
    private TextView calibrationSummaryText;
    private TextView customLayoutButton;
    private TextView editPresetMappingButton;
    private TextView nameSummaryText;
    private TextView axisDirectionSummaryText;
    private TextView screenSaverPickerButton;
    private TextView screenSaverDefaultButton;
    private TextView screenSaverPreviewButton;
    private TextView screenSaverIntervalButton;
    private TextView screenSaverLoopButton;
    private TextView screenSaverExitButton;
    private TextView screenSaverGamepadExitButton;
    private TextView deadZoneButton;
    private TextView calibrationButton;
    private TextView nameButton;
    private TextView axisDirectionButton;
    private CheckBox vibrationToggle;
    private View statusDot;
    private InputManager inputManager;
    private ScrollView sideScroll;
    private final List<View> navigationTargets = new ArrayList<>();
    private final Handler calibrationHandler = new Handler(Looper.getMainLooper());
    private final Handler inputUiHandler = new Handler(Looper.getMainLooper());
    private final Handler batteryHandler = new Handler(Looper.getMainLooper());
    private final Handler navigationHandler = new Handler(Looper.getMainLooper());
    private final Handler screensaverHandler = new Handler(Looper.getMainLooper());
    private final Runnable inputUiRefresh = this::renderInputMonitor;
    private final Runnable batteryRefresh = this::refreshBattery;
    private final Runnable navigationCursorRefresh = this::updateNavigationCursor;
    private final Runnable navigationRepeatAction = this::repeatNavigationMovement;
    private View calibrationOverlay;
    private TextView calibrationStatusText;
    private boolean inputUiRefreshPosted;
    private boolean touchScreenAvailable;
    private boolean monitorActive;
    private boolean navigationCursorVisible;
    private boolean screensaverConfigPromptVisible;
    private boolean touchMonitorLongPressTriggered;
    private boolean restoreNavigationFocusOnNextInput;
    private boolean longPressTriggered;
    private int longPressKeyCode = KeyEvent.KEYCODE_UNKNOWN;
    private int navigationIndex;
    private int navigationRepeatDirection = -1;
    private int navigationRepeatKeyCode = KeyEvent.KEYCODE_UNKNOWN;
    private int screensaverExitKeyCode = KeyEvent.KEYCODE_UNKNOWN;
    private int screensaverExitPressCount;
    private long screensaverExitFirstPressAt;
    private boolean screensaverExitLongTriggered;
    private int backPressCount;
    private long lastBackPressAt;
    private final Runnable longPressAction = this::handleLongPressAction;
    private final Runnable screensaverLongPressAction = this::handleScreensaverLongPress;
    private final Runnable touchMonitorLongPressAction = this::toggleMonitorByLongPress;
    private int batteryPercent = ControllerState.UNKNOWN_BATTERY;
    private boolean batteryCharging;
    private TouchpadState touchpadState = TouchpadState.NONE;
    private HandheldVibrationController vibrationController;

    private OutputProfile outputProfile = OutputProfile.XBOX;
    private ConnectionMode connectionMode = ConnectionMode.BLUETOOTH;
    private boolean waitingToStartAfterPermission;
    private boolean screensaverDismissedForConnection;
    private float originalScreenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        preferences = new AppPreferences(this);
        touchScreenAvailable =
                getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
        monitorActive = false;
        if (AppPreferences.STANDARD_LAYOUT.equals(preferences.getActiveLayoutName())) {
            preferences.setActiveLayout(AppPreferences.presetLayoutName(OutputProfile.XBOX));
        }
        inputMapper = new GamepadInputMapper();
        inputMapper.setDeadZonePercent(preferences.getDeadZonePercent());
        inputMapper.setCalibration(preferences.getCalibration());
        inputMapper.setKeyMapping(preferences.getActiveMapping());
        inputMapper.setAxisOptions(
                preferences.isLeftXInverted(),
                preferences.isLeftYInverted(),
                preferences.isRightXInverted(),
                preferences.isRightYInverted(),
                preferences.shouldSwapSticks());
        bridgeSession = new BridgeSession(this);
        vibrationController = new HandheldVibrationController(this);
        vibrationController.setEnabled(preferences.isVibrationEnabled());
        bridgeSession.setRumbleListener(vibrationController::rumble);
        refreshBattery();
        inputManager = (InputManager) getSystemService(INPUT_SERVICE);
        mappingDialogController =
                new MappingDialogController(
                        this,
                        preferences,
                        inputMapper,
                        (name, mapping) -> {
                            inputMapper.reset();
                            bridgeSession.updateState(ControllerState.NEUTRAL);
                            testerView.setInput(
                                    ControllerState.NEUTRAL,
                                    controllerDisplayName(),
                                    bridgeSession.isConnected());
                            refreshLayoutSummary();
                            Toast.makeText(
                                            this,
                                            "已启用 " + name,
                                            Toast.LENGTH_SHORT)
                                    .show();
                        });
        setContentView(buildInterface());
        setupNavigationTargets();
        configureSystemBars();
        refreshSelection();
        refreshInputMonitor();
        refreshCustomizationSummary();
        activateNavigationMode(!touchScreenAvailable);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (inputManager != null) {
            inputManager.registerInputDeviceListener(inputDeviceListener, null);
        }
        refreshBattery();
        batteryHandler.removeCallbacks(batteryRefresh);
        batteryHandler.postDelayed(batteryRefresh, 30_000L);
        if (bridgeSession.isConnected()
                && !screensaverDismissedForConnection
                && screensaverView == null) {
            rootLayout.post(() -> showScreensaver(false));
        }
    }

    @Override
    protected void onPause() {
        inputUiHandler.removeCallbacks(inputUiRefresh);
        batteryHandler.removeCallbacks(batteryRefresh);
        navigationHandler.removeCallbacks(longPressAction);
        stopNavigationRepeat();
        navigationHandler.removeCallbacks(touchMonitorLongPressAction);
        screensaverHandler.removeCallbacksAndMessages(null);
        screensaverConfigPromptVisible = false;
        navigationCursorVisible = false;
        updateNavigationCursor();
        inputUiRefreshPosted = false;
        hideScreensaver(false);
        if (calibrationOverlay != null) {
            calibrationHandler.removeCallbacksAndMessages(null);
            inputMapper.cancelCalibration();
            hideCalibrationOverlay();
        }
        if (inputManager != null) {
            inputManager.unregisterInputDeviceListener(inputDeviceListener);
        }
        inputMapper.reset();
        bridgeSession.updateState(ControllerState.NEUTRAL);
        refreshInputMonitor();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        inputUiHandler.removeCallbacks(inputUiRefresh);
        batteryHandler.removeCallbacks(batteryRefresh);
        navigationHandler.removeCallbacks(longPressAction);
        stopNavigationRepeat();
        navigationHandler.removeCallbacks(touchMonitorLongPressAction);
        screensaverHandler.removeCallbacksAndMessages(null);
        calibrationHandler.removeCallbacksAndMessages(null);
        hideCalibrationOverlay();
        hideScreensaver(false);
        bridgeSession.stop();
        vibrationController.stop();
        super.onDestroy();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        boolean gamepadEvent = isGamepadSource(event.getSource(), event.getDevice());
        if (screensaverView != null) {
            if (!gamepadEvent) {
                return false;
            }
            if (handleScreensaverGamepadExit(event)) {
                return true;
            }
            if (inputMapper.handleKeyEvent(event)) {
                afterInputChanged();
            }
            return true;
        }
        int action = inputMapper.getKeyMapping().getOrDefault(
                event.getKeyCode(), ButtonMapping.ACTION_NONE);
        if (gamepadEvent) {
            ensureNavigationFocusRestored();
        }
        boolean longPressHandled = handleLongPressTracking(event, action);
        if (longPressHandled) {
            return true;
        }
        if (!monitorActive) {
            if (gamepadEvent && handleNavigationKey(event, action)) {
                return true;
            }
            return gamepadEvent;
        }
        if (inputMapper.handleKeyEvent(event)) {
            afterInputChanged();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent event) {
        boolean gamepadEvent = isGamepadSource(event.getSource(), event.getDevice());
        if (screensaverView != null) {
            if (gamepadEvent && inputMapper.handleMotionEvent(event)) {
                afterInputChanged();
            }
            return gamepadEvent;
        }
        if (!monitorActive) {
            if (gamepadEvent) {
                handleDirectionalNavigation(event);
            }
            return gamepadEvent;
        }
        if (inputMapper.handleMotionEvent(event)) {
            afterInputChanged();
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }

    private boolean handleLongPressTracking(KeyEvent event, int action) {
        if (!isGamepadSource(event.getSource(), event.getDevice())) {
            return false;
        }
        boolean shouldTrack = monitorGesture(action) != MonitorGesturePolicy.NONE;
        if (event.getAction() == KeyEvent.ACTION_DOWN
                && event.getRepeatCount() == 0
                && shouldTrack) {
            longPressKeyCode = event.getKeyCode();
            longPressTriggered = false;
            navigationHandler.removeCallbacks(longPressAction);
            navigationHandler.postDelayed(longPressAction, 650L);
            return false;
        }
        if (event.getKeyCode() != longPressKeyCode) {
            return false;
        }
        if (event.getAction() == KeyEvent.ACTION_UP) {
            navigationHandler.removeCallbacks(longPressAction);
            boolean handled = longPressTriggered;
            longPressTriggered = false;
            longPressKeyCode = KeyEvent.KEYCODE_UNKNOWN;
            return handled;
        }
        return longPressTriggered;
    }

    private void ensureNavigationFocusRestored() {
        if (!restoreNavigationFocusOnNextInput || monitorActive || monitorFrame == null) {
            return;
        }
        navigationIndex = Math.max(0, navigationTargets.indexOf(monitorFrame));
        monitorFrame.requestFocus();
        restoreNavigationFocusOnNextInput = false;
    }

    private void handleLongPressAction() {
        if (longPressKeyCode == KeyEvent.KEYCODE_UNKNOWN) {
            return;
        }
        int action = inputMapper.getKeyMapping().getOrDefault(
                longPressKeyCode, ButtonMapping.ACTION_NONE);
        int monitorGesture = monitorGesture(action);
        if (monitorGesture == MonitorGesturePolicy.EXIT) {
            longPressTriggered = true;
            activateNavigationMode(true);
        } else if (monitorGesture == MonitorGesturePolicy.ENTER) {
            longPressTriggered = true;
            activateMonitorMode();
        }
    }

    private int monitorGesture(int action) {
        return MonitorGesturePolicy.resolve(
                touchScreenAvailable,
                monitorActive,
                monitorFrame != null && monitorFrame.isFocused(),
                action);
    }

    private boolean handleNavigationKey(KeyEvent event, int action) {
        if (event.getAction() == KeyEvent.ACTION_UP) {
            if (event.getKeyCode() == navigationRepeatKeyCode) {
                stopNavigationRepeat();
            }
            return true;
        }
        if (event.getAction() != KeyEvent.ACTION_DOWN) {
            return false;
        }
        int direction = directionForDpad(event.getKeyCode(), action);
        if (direction >= 0) {
            if (event.getRepeatCount() == 0) {
                stopNavigationRepeat();
                navigationRepeatDirection = direction;
                navigationRepeatKeyCode = event.getKeyCode();
                moveNavigationFocus(direction);
                navigationHandler.postDelayed(navigationRepeatAction, 360L);
            }
            return true;
        }
        if (event.getRepeatCount() > 0) {
            return true;
        }
        if (action == ButtonMapping.ACTION_A) {
            stopNavigationRepeat();
            View focused = getCurrentFocus();
            if (focused != null) {
                focused.performClick();
            }
            return true;
        }
        if (action == ButtonMapping.ACTION_B) {
            stopNavigationRepeat();
            registerExitPress();
            return true;
        }
        return false;
    }

    private void repeatNavigationMovement() {
        if (monitorActive || screensaverView != null || navigationRepeatDirection < 0) {
            stopNavigationRepeat();
            return;
        }
        moveNavigationFocus(navigationRepeatDirection);
        navigationHandler.postDelayed(navigationRepeatAction, 140L);
    }

    private void stopNavigationRepeat() {
        navigationHandler.removeCallbacks(navigationRepeatAction);
        navigationRepeatDirection = -1;
        navigationRepeatKeyCode = KeyEvent.KEYCODE_UNKNOWN;
    }

    private void handleDirectionalNavigation(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_UP
                || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            if (navigationRepeatKeyCode == KeyEvent.KEYCODE_UNKNOWN) {
                stopNavigationRepeat();
            }
            return;
        }
        if (event.getActionMasked() != MotionEvent.ACTION_MOVE) {
            return;
        }
        float x = event.getAxisValue(MotionEvent.AXIS_X);
        float y = event.getAxisValue(MotionEvent.AXIS_Y);
        float hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X);
        float hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y);
        if (navigationRepeatKeyCode != KeyEvent.KEYCODE_UNKNOWN) {
            return;
        }
        if (Math.abs(hatX) > 0.5f || Math.abs(hatY) > 0.5f) {
            x = hatX;
            y = hatY;
        }
        if (Math.max(Math.abs(x), Math.abs(y)) < 0.65f) {
            if (navigationRepeatKeyCode == KeyEvent.KEYCODE_UNKNOWN) {
                stopNavigationRepeat();
            }
            return;
        }
        int direction;
        if (Math.abs(x) > Math.abs(y)) {
            direction = x < 0 ? DIRECTION_LEFT : DIRECTION_RIGHT;
        } else {
            direction = y < 0 ? DIRECTION_UP : DIRECTION_DOWN;
        }
        if (navigationRepeatKeyCode != KeyEvent.KEYCODE_UNKNOWN
                || navigationRepeatDirection != direction) {
            stopNavigationRepeat();
            navigationRepeatDirection = direction;
            navigationRepeatKeyCode = KeyEvent.KEYCODE_UNKNOWN;
            moveNavigationFocus(direction);
            navigationHandler.postDelayed(navigationRepeatAction, 360L);
        }
    }

    private void registerExitPress() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackPressAt > 1_500L) {
            backPressCount = 0;
        }
        lastBackPressAt = now;
        backPressCount++;
        if (backPressCount >= 3) {
            backPressCount = 0;
            Toast.makeText(
                            this,
                            "正在退出 Lens controller",
                            Toast.LENGTH_LONG)
                    .show();
            navigationHandler.postDelayed(this::finish, 900L);
        } else {
            Toast.makeText(
                            this,
                            "再按 " + (3 - backPressCount) + " 次 B / 圆形键退出应用",
                            Toast.LENGTH_SHORT)
                    .show();
        }
    }

    private void activateNavigationMode(boolean announce) {
        stopNavigationRepeat();
        restoreNavigationFocusOnNextInput = false;
        monitorActive = false;
        navigationHandler.removeCallbacks(longPressAction);
        longPressTriggered = false;
        longPressKeyCode = KeyEvent.KEYCODE_UNKNOWN;
        hideScreensaver(true);
        setMonitorUiEnabled(false);
        inputMapper.reset();
        touchpadState = TouchpadState.NONE;
        bridgeSession.updateState(controllerState());
        refreshInputMonitor();
        updateStatus(
                touchScreenAvailable
                        ? "监测未启用 · 长按监测功能区开启"
                        : "监测未启用 · 选定监测区后长按 X / 方形进入",
                false,
                true);
        if (monitorFrame != null) {
            navigationIndex = Math.max(0, navigationTargets.indexOf(monitorFrame));
            monitorFrame.post(
                    () -> {
                        if (!monitorActive && screensaverView == null) {
                            monitorFrame.requestFocus();
                            postNavigationCursorUpdate();
                        }
                    });
            navigationCursorVisible = announce || !touchScreenAvailable;
            if (navigationCursorVisible) {
                postNavigationCursorUpdate();
            } else {
                updateNavigationCursor();
            }
        }
        if (announce) {
            Toast.makeText(
                            this,
                            touchScreenAvailable
                                    ? "导航模式：方向键或左摇杆选择，长按监测功能区开关监测"
                                    : "导航模式：方向键或左摇杆选择，长按 X / 方形进入监测",
                            Toast.LENGTH_LONG)
                    .show();
        }
    }

    private void activateMonitorMode() {
        stopNavigationRepeat();
        restoreNavigationFocusOnNextInput = false;
        monitorActive = true;
        navigationHandler.removeCallbacks(longPressAction);
        longPressTriggered = false;
        longPressKeyCode = KeyEvent.KEYCODE_UNKNOWN;
        hideScreensaver(true);
        setMonitorUiEnabled(true);
        navigationCursorVisible = false;
        updateNavigationCursor();
        stopNavigationRepeat();
        inputMapper.reset();
        updateStatus("实时输入监测已开启 · 长按 B / 圆形退出", bridgeSession.isConnected(), true);
        refreshInputMonitor();
        Toast.makeText(this, "已进入实时输入监测", Toast.LENGTH_SHORT).show();
    }

    private void moveNavigationFocus(int direction) {
        if (navigationTargets.isEmpty()) {
            return;
        }
        navigationCursorVisible = true;
        postNavigationCursorUpdate();
        View focused = getCurrentFocus();
        if (focused == null) {
            focused = navigationTargets.get(
                    Math.max(0, Math.min(navigationIndex, navigationTargets.size() - 1)));
        }
        Rect currentRect = navigationRect(focused);
        float currentX = currentRect.exactCenterX();
        float currentY = currentRect.exactCenterY();
        View best = null;
        double bestScore = Double.MAX_VALUE;
        int bestIndex = navigationIndex;
        boolean focusedInSide = isDescendantOf(focused, sideScroll);
        boolean focusedIsMonitor = focused == monitorFrame;

        if (focusedInSide && direction == DIRECTION_RIGHT) {
            for (int i = 0; i < navigationTargets.size(); i++) {
                View candidate = navigationTargets.get(i);
                if (candidate == focused
                        || candidate == monitorFrame
                        || !isDescendantOf(candidate, sideScroll)
                        || !candidate.isShown()
                        || !candidate.isEnabled()) {
                    continue;
                }
                Rect candidateRect = navigationRect(candidate);
                float dx = candidateRect.exactCenterX() - currentX;
                if (dx >= dp(4)
                        && sameVisualRow(currentRect, candidateRect)) {
                    double score = dx + Math.abs(candidateRect.exactCenterY() - currentY) * 2.2;
                    if (score < bestScore) {
                        bestScore = score;
                        best = candidate;
                        bestIndex = i;
                    }
                }
            }
            if (best == null) {
                best = monitorFrame;
                bestIndex = navigationTargets.indexOf(monitorFrame);
            }
        } else if (focusedIsMonitor && direction == DIRECTION_LEFT) {
            for (int i = 0; i < navigationTargets.size(); i++) {
                View candidate = navigationTargets.get(i);
                if (candidate == monitorFrame
                        || !isDescendantOf(candidate, sideScroll)
                        || !candidate.isShown()
                        || !candidate.isEnabled()) {
                    continue;
                }
                Rect candidateRect = navigationRect(candidate);
                if (candidateRect.exactCenterX() >= currentX) {
                    continue;
                }
                double verticalDistance =
                        Math.abs(candidateRect.exactCenterY() - currentY);
                double horizontalDistance =
                        Math.max(0, currentRect.left - candidateRect.right);
                double score = verticalDistance * 8 + horizontalDistance * 0.1;
                if (score < bestScore) {
                    bestScore = score;
                    best = candidate;
                    bestIndex = i;
                }
            }
        } else {
            for (int i = 0; i < navigationTargets.size(); i++) {
                View candidate = navigationTargets.get(i);
                if (candidate == focused || !candidate.isShown() || !candidate.isEnabled()) {
                    continue;
                }
                boolean candidateInSide = isDescendantOf(candidate, sideScroll);
                if ((focusedInSide || focusedIsMonitor) && !candidateInSide) {
                    continue;
                }
                if (candidate == monitorFrame && (focusedInSide || !focusedIsMonitor)) {
                    continue;
                }
                Rect candidateRect = navigationRect(candidate);
                float candidateX = candidateRect.exactCenterX();
                float candidateY = candidateRect.exactCenterY();
                double score;
                if (direction == DIRECTION_LEFT || direction == DIRECTION_RIGHT) {
                    if (!sameVisualRow(currentRect, candidateRect)) {
                        continue;
                    }
                    float centerDelta = candidateX - currentX;
                    if ((direction == DIRECTION_LEFT && centerDelta >= -dp(4))
                            || (direction == DIRECTION_RIGHT && centerDelta <= dp(4))) {
                        continue;
                    }
                    score = Math.abs(centerDelta);
                } else {
                    float centerDelta = candidateY - currentY;
                    if ((direction == DIRECTION_UP && centerDelta >= -dp(4))
                            || (direction == DIRECTION_DOWN && centerDelta <= dp(4))) {
                        continue;
                    }
                    // A vertical move must first enter the nearest visual row. The
                    // old weighted score allowed a farther row with a similar X
                    // coordinate to win, which skipped full-width options.
                    score =
                            Math.abs(centerDelta) * 1000f
                                    + Math.abs(candidateX - currentX);
                }
                if (score < bestScore) {
                    bestScore = score;
                    best = candidate;
                    bestIndex = i;
                }
            }
        }
        if (best == null) {
            if (!focusedIsMonitor
                    && (direction == DIRECTION_UP || direction == DIRECTION_DOWN)) {
                int amount = direction == DIRECTION_UP ? -dp(180) : dp(180);
                sideScroll.smoothScrollBy(0, amount);
                postNavigationCursorUpdate();
            }
            return;
        }
        navigationIndex = bestIndex;
        View target = best;
        target.requestFocus();
        target.requestRectangleOnScreen(
                new Rect(0, 0, target.getWidth(), target.getHeight()), true);
        target.postDelayed(navigationCursorRefresh, 90L);
    }

    private static Rect navigationRect(View view) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        return new Rect(
                location[0],
                location[1],
                location[0] + view.getWidth(),
                location[1] + view.getHeight());
    }

    private static boolean sameVisualRow(Rect first, Rect second) {
        int overlap = Math.min(first.bottom, second.bottom) - Math.max(first.top, second.top);
        return overlap >= Math.min(first.height(), second.height()) * 0.42f;
    }

    private static boolean isDescendantOf(View child, ViewGroup ancestor) {
        if (child == null || ancestor == null) {
            return false;
        }
        View current = child;
        while (current != null) {
            if (current == ancestor) {
                return true;
            }
            current =
                    current.getParent() instanceof View
                            ? (View) current.getParent()
                            : null;
        }
        return false;
    }

    private static int directionForDpad(int keyCode, int action) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || action == ButtonMapping.ACTION_DPAD_LEFT) {
            return DIRECTION_LEFT;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || action == ButtonMapping.ACTION_DPAD_RIGHT) {
            return DIRECTION_RIGHT;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP || action == ButtonMapping.ACTION_DPAD_UP) {
            return DIRECTION_UP;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN || action == ButtonMapping.ACTION_DPAD_DOWN) {
            return DIRECTION_DOWN;
        }
        return -1;
    }

    static boolean isGamepadSource(int source, InputDevice device) {
        int sources = device == null ? source : device.getSources();
        return (sources & (InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK)) != 0;
    }

    private final InputManager.InputDeviceListener inputDeviceListener =
            new InputManager.InputDeviceListener() {
                @Override
                public void onInputDeviceAdded(int deviceId) {
                    // The device is identified by its first input event.
                }

                @Override
                public void onInputDeviceRemoved(int deviceId) {
                    if (inputMapper.usesDevice(deviceId)) {
                        inputMapper.reset();
                        bridgeSession.updateState(ControllerState.NEUTRAL);
                        refreshInputMonitor();
                        updateStatus("手柄连接已断开", false, false);
                    }
                }

                @Override
                public void onInputDeviceChanged(int deviceId) {
                    // Axis ranges are read directly from each event's InputDevice.
                }
            };

    private View buildInterface() {
        FrameLayout root = new FrameLayout(this);
        rootLayout = root;
        GradientDrawable background =
                new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        new int[] {Color.rgb(248, 249, 252), Color.rgb(235, 239, 246)});
        root.setBackground(background);
        applyInsets(root);

        LinearLayout columns = new LinearLayout(this);
        columns.setOrientation(LinearLayout.HORIZONTAL);
        columns.setPadding(dp(20), dp(14), dp(20), dp(18));
        root.addView(
                columns,
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));

        sideScroll = new ScrollView(this);
        sideScroll.setFillViewport(true);
        sideScroll.setClipToPadding(false);
        LinearLayout.LayoutParams sideParams =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.92f);
        sideParams.setMarginEnd(dp(14));
        columns.addView(sideScroll, sideParams);

        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setPadding(0, 0, dp(2), dp(6));
        sideScroll.addView(
                side,
                new ScrollView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));

        side.addView(buildHero(), matchWrap());
        side.addView(space(10));

        LinearLayout statusCard = card(CARD, 15, 12, 14, 12, 14);
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusDot = new View(this);
        GradientDrawable dot = rounded(Color.rgb(142, 151, 168), 99);
        statusDot.setBackground(dot);
        statusRow.addView(statusDot, new LinearLayout.LayoutParams(dp(8), dp(8)));
        statusText = label("未启动", 13, MUTED, Typeface.BOLD);
        LinearLayout.LayoutParams statusTextParams =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        statusTextParams.setMarginStart(dp(9));
        statusRow.addView(statusText, statusTextParams);
        statusCard.addView(statusRow, matchWrap());
        side.addView(statusCard, matchWrap());
        side.addView(space(13));

        LinearLayout profileHeader = new LinearLayout(this);
        profileHeader.setGravity(Gravity.CENTER_VERTICAL);
        profileHeader.addView(
                sectionLabel("01  选择电脑看到的手柄"),
                new LinearLayout.LayoutParams(0, -2, 1f));
        editPresetMappingButton = utilityButton("编辑预设", false);
        profileHeader.addView(
                editPresetMappingButton, new LinearLayout.LayoutParams(dp(78), dp(28)));
        side.addView(profileHeader, matchWrap());
        side.addView(space(7));
        LinearLayout profileRow = new LinearLayout(this);
        profileRow.setOrientation(LinearLayout.HORIZONTAL);
        xboxButton = modeButton("XBOX", "Xbox 360 布局", true);
        ds4Button = modeButton("DUALSHOCK", "DualShock 4 布局", false);
        customLayoutButton = modeButton("自定义", "按键布局", false);
        profileRow.addView(xboxButton, weighted());
        profileRow.addView(space(8, true), weightedSpace());
        profileRow.addView(ds4Button, weighted());
        profileRow.addView(space(8, true), weightedSpace());
        profileRow.addView(customLayoutButton, weighted());
        side.addView(profileRow, matchWrap());
        xboxButton.setOnClickListener(
                view -> {
                    if (!bridgeSession.isRunning()) {
                        selectOutputProfile(OutputProfile.XBOX);
                    }
                });
        ds4Button.setOnClickListener(
                view -> {
                    if (!bridgeSession.isRunning()) {
                        selectOutputProfile(OutputProfile.DUALSHOCK_4);
                    }
                });
        customLayoutButton.setOnClickListener(
                view -> mappingDialogController.showLayoutPicker());
        editPresetMappingButton.setOnClickListener(
                view -> mappingDialogController.showPresetEditor(outputProfile));
        side.addView(space(13));

        side.addView(sectionLabel("02  选择掌机到电脑的连接"), matchWrap());
        side.addView(space(7));
        LinearLayout connectionRow = new LinearLayout(this);
        connectionRow.setOrientation(LinearLayout.HORIZONTAL);
        bluetoothButton = modeButton("蓝牙", "无线桥接", true);
        usbButton = modeButton("USB 有线", "低延迟桥接", false);
        connectionRow.addView(bluetoothButton, weighted());
        connectionRow.addView(space(8, true), weightedSpace());
        connectionRow.addView(usbButton, weighted());
        side.addView(connectionRow, matchWrap());
        bluetoothButton.setOnClickListener(
                view -> {
                    if (!bridgeSession.isRunning()) {
                        connectionMode = ConnectionMode.BLUETOOTH;
                        refreshSelection();
                    }
                });
        usbButton.setOnClickListener(
                view -> {
                    if (!bridgeSession.isRunning()) {
                        connectionMode = ConnectionMode.USB;
                        refreshSelection();
                    }
                });
        side.addView(space(10));

        LinearLayout hintCard = card(Color.rgb(255, 249, 229), 14, 12, 14, 12, 14);
        hintText = label("", 11, Color.rgb(112, 91, 39), Typeface.NORMAL);
        hintText.setLineSpacing(dp(2), 1f);
        hintCard.addView(hintText, matchWrap());
        side.addView(hintCard, matchWrap());
        side.addView(space(12));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        startButton = actionButton("开始桥接", true);
        stopButton = actionButton("停止", false);
        actionRow.addView(startButton, new LinearLayout.LayoutParams(0, dp(48), 1.65f));
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(0, dp(48), 0.75f);
        stopParams.setMarginStart(dp(8));
        actionRow.addView(stopButton, stopParams);
        side.addView(actionRow, matchWrap());
        startButton.setOnClickListener(view -> toggleBridge());
        stopButton.setOnClickListener(view -> stopBridge("连接已停止"));

        side.addView(space(10));
        LinearLayout deviceRow = new LinearLayout(this);
        deviceRow.setGravity(Gravity.CENTER_VERTICAL);
        deviceText = label("未检测到掌机手柄", 10, MUTED, Typeface.NORMAL);
        deviceText.setSingleLine(true);
        deviceRow.addView(deviceText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView testBadge = label("INPUT TEST", 8, Color.rgb(91, 104, 124), Typeface.BOLD);
        testBadge.setBackground(rounded(Color.rgb(228, 233, 241), 99));
        testBadge.setPadding(dp(7), dp(3), dp(7), dp(3));
        deviceRow.addView(testBadge);
        side.addView(deviceRow, matchWrap());
        side.addView(space(14));

        side.addView(sectionLabel("03  连接后的屏保"), matchWrap());
        side.addView(space(7));
        LinearLayout screenSaverCard = card(CARD, 15, 12, 12, 12, 12);
        LinearLayout screenSaverHead = new LinearLayout(this);
        screenSaverHead.setGravity(Gravity.CENTER_VERTICAL);
        screenSaverHead.addView(
                label("幻灯片与最低亮度", 12, INK, Typeface.BOLD),
                new LinearLayout.LayoutParams(0, -2, 1f));
        screenSaverSummaryText = label("", 9, MUTED, Typeface.NORMAL);
        screenSaverHead.addView(screenSaverSummaryText);
        screenSaverCard.addView(screenSaverHead, matchWrap());
        screenSaverHintText =
                label("连接成功后自动播放；连续轻触 3 次返回主界面。",
                        9, Color.rgb(110, 121, 139), Typeface.NORMAL);
        LinearLayout.LayoutParams screenSaverHintParams = matchWrap();
        screenSaverHintParams.topMargin = dp(5);
        screenSaverCard.addView(screenSaverHintText, screenSaverHintParams);
        LinearLayout screenSaverActions = new LinearLayout(this);
        screenSaverActions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams screenSaverActionsParams = matchWrap();
        screenSaverActionsParams.topMargin = dp(9);
        screenSaverPickerButton = utilityButton("选择图片", true);
        screenSaverDefaultButton = utilityButton("一键默认", false);
        screenSaverPreviewButton = utilityButton("进入屏保", false);
        screenSaverActions.addView(
                screenSaverPickerButton, new LinearLayout.LayoutParams(0, dp(38), 1.2f));
        screenSaverActions.addView(space(6, true));
        screenSaverActions.addView(
                screenSaverDefaultButton, new LinearLayout.LayoutParams(0, dp(38), 1f));
        screenSaverActions.addView(space(6, true));
        screenSaverActions.addView(
                screenSaverPreviewButton, new LinearLayout.LayoutParams(0, dp(38), 0.8f));
        screenSaverCard.addView(screenSaverActions, screenSaverActionsParams);
        LinearLayout screenSaverOptions = new LinearLayout(this);
        screenSaverOptions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams screenSaverOptionsParams = matchWrap();
        screenSaverOptionsParams.topMargin = dp(7);
        screenSaverIntervalButton = utilityButton("切换间隔", false);
        screenSaverLoopButton = utilityButton("全循环", false);
        screenSaverExitButton = utilityButton("退出次数", false);
        screenSaverOptions.addView(
                screenSaverIntervalButton, new LinearLayout.LayoutParams(0, dp(34), 1f));
        screenSaverOptions.addView(space(6, true), weightedSpace());
        screenSaverOptions.addView(
                screenSaverLoopButton, new LinearLayout.LayoutParams(0, dp(34), 1f));
        screenSaverOptions.addView(space(6, true), weightedSpace());
        screenSaverOptions.addView(
                screenSaverExitButton, new LinearLayout.LayoutParams(0, dp(34), 1f));
        screenSaverCard.addView(screenSaverOptions, screenSaverOptionsParams);
        screenSaverGamepadExitButton = utilityButton("手柄退出：未设置", false);
        LinearLayout.LayoutParams gamepadExitParams =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        gamepadExitParams.topMargin = dp(7);
        screenSaverCard.addView(screenSaverGamepadExitButton, gamepadExitParams);
        side.addView(screenSaverCard, matchWrap());
        screenSaverPickerButton.setOnClickListener(view -> chooseScreenSaverImages());
        screenSaverDefaultButton.setOnClickListener(
                view -> {
                    preferences.resetScreensaver();
                    refreshScreensaverSummary();
                    Toast.makeText(
                                    this,
                                    "已恢复 12 张默认屏保",
                                    Toast.LENGTH_SHORT)
                            .show();
                });
        screenSaverPreviewButton.setOnClickListener(view -> showScreensaver(true));
        screenSaverIntervalButton.setOnClickListener(view -> showScreensaverIntervalDialog());
        screenSaverLoopButton.setOnClickListener(view -> showScreensaverLoopDialog());
        screenSaverExitButton.setOnClickListener(view -> showScreensaverExitDialog());
        screenSaverGamepadExitButton.setOnClickListener(
                view -> showScreensaverGamepadExitDialog(null));
        side.addView(space(14));

        side.addView(sectionLabel("04  摇杆调校"), matchWrap());
        side.addView(space(7));
        LinearLayout tuningCard = card(CARD, 15, 12, 12, 12, 12);
        LinearLayout deadZoneRow = new LinearLayout(this);
        deadZoneRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout deadZoneLabels = new LinearLayout(this);
        deadZoneLabels.setOrientation(LinearLayout.VERTICAL);
        deadZoneLabels.addView(label("摇杆死区", 12, INK, Typeface.BOLD));
        deadZoneSummaryText = label("", 9, MUTED, Typeface.NORMAL);
        deadZoneLabels.addView(deadZoneSummaryText);
        deadZoneRow.addView(deadZoneLabels, new LinearLayout.LayoutParams(0, -2, 1f));
        deadZoneButton = utilityButton("调整", false);
        deadZoneRow.addView(deadZoneButton, new LinearLayout.LayoutParams(dp(74), dp(36)));
        tuningCard.addView(deadZoneRow, matchWrap());
        tuningCard.addView(space(9));

        LinearLayout calibrationRow = new LinearLayout(this);
        calibrationRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout calibrationLabels = new LinearLayout(this);
        calibrationLabels.setOrientation(LinearLayout.VERTICAL);
        calibrationLabels.addView(label("摇杆中心与行程", 12, INK, Typeface.BOLD));
        calibrationSummaryText = label("", 9, MUTED, Typeface.NORMAL);
        calibrationLabels.addView(calibrationSummaryText);
        calibrationRow.addView(calibrationLabels, new LinearLayout.LayoutParams(0, -2, 1f));
        calibrationButton = utilityButton("开始校准", false);
        calibrationRow.addView(calibrationButton, new LinearLayout.LayoutParams(dp(92), dp(36)));
        tuningCard.addView(calibrationRow, matchWrap());
        tuningCard.addView(space(9));

        LinearLayout axisDirectionRow = new LinearLayout(this);
        axisDirectionRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout axisDirectionLabels = new LinearLayout(this);
        axisDirectionLabels.setOrientation(LinearLayout.VERTICAL);
        axisDirectionLabels.addView(label("摇杆方向与交换", 12, INK, Typeface.BOLD));
        axisDirectionSummaryText = label("", 9, MUTED, Typeface.NORMAL);
        axisDirectionLabels.addView(axisDirectionSummaryText);
        axisDirectionRow.addView(
                axisDirectionLabels, new LinearLayout.LayoutParams(0, -2, 1f));
        axisDirectionButton = utilityButton("设置", false);
        axisDirectionRow.addView(
                axisDirectionButton, new LinearLayout.LayoutParams(dp(74), dp(36)));
        tuningCard.addView(axisDirectionRow, matchWrap());
        tuningCard.addView(space(7));
        vibrationToggle =
                optionCheckBox("启用掌机震动反馈", preferences.isVibrationEnabled());
        tuningCard.addView(vibrationToggle, matchWrap());
        side.addView(tuningCard, matchWrap());
        deadZoneButton.setOnClickListener(view -> showDeadZoneDialog());
        calibrationButton.setOnClickListener(view -> showCalibrationIntro());
        axisDirectionButton.setOnClickListener(view -> showAxisDirectionDialog());
        vibrationToggle.setOnCheckedChangeListener(
                (button, checked) -> {
                    preferences.setVibrationEnabled(checked);
                    vibrationController.setEnabled(checked);
                    if (!checked) {
                        vibrationController.rumble(0, 0);
                    }
                });
        side.addView(space(14));

        side.addView(sectionLabel("05  设备与手柄名称"), matchWrap());
        side.addView(space(7));
        LinearLayout nameCard = card(CARD, 15, 12, 12, 12, 12);
        LinearLayout nameRow = new LinearLayout(this);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout nameLabels = new LinearLayout(this);
        nameLabels.setOrientation(LinearLayout.VERTICAL);
        nameLabels.addView(label("蓝牙名与手柄名", 12, INK, Typeface.BOLD));
        nameSummaryText = label("", 9, MUTED, Typeface.NORMAL);
        nameSummaryText.setSingleLine(true);
        nameLabels.addView(nameSummaryText);
        nameRow.addView(nameLabels, new LinearLayout.LayoutParams(0, -2, 1f));
        nameButton = utilityButton("修改", false);
        nameRow.addView(nameButton, new LinearLayout.LayoutParams(dp(74), dp(36)));
        nameCard.addView(nameRow, matchWrap());
        side.addView(nameCard, matchWrap());
        nameButton.setOnClickListener(view -> showNameDialog());

        testerView = new GamepadTesterView(this);
        testerView.setOutputProfile(outputProfile);
        monitorFrame = new FrameLayout(this);
        monitorFrame.setFocusable(true);
        monitorFrame.setClickable(true);
        monitorFrame.setContentDescription("实时输入监测功能区");
        monitorFrame.addView(
                testerView,
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        monitorDisabledOverlay =
                label(
                        touchScreenAvailable
                                ? "监测未启用\n长按此区域开启监测"
                                : "监测未启用\n请选定并长按 X / 方形键进入",
                        17,
                        Color.WHITE,
                        Typeface.BOLD);
        monitorDisabledOverlay.setGravity(Gravity.CENTER);
        monitorDisabledOverlay.setLineSpacing(dp(5), 1f);
        monitorDisabledOverlay.setPadding(dp(24), dp(18), dp(24), dp(18));
        monitorDisabledOverlay.setBackground(rounded(Color.argb(190, 20, 24, 33), 18));
        FrameLayout.LayoutParams overlayParams =
                new FrameLayout.LayoutParams(dp(520), ViewGroup.LayoutParams.WRAP_CONTENT);
        overlayParams.gravity = Gravity.CENTER;
        monitorFrame.addView(monitorDisabledOverlay, overlayParams);
        monitorFrame.setOnClickListener(
                view -> {
                    navigationCursorVisible = !touchScreenAvailable;
                    postNavigationCursorUpdate();
                    if (touchScreenAvailable) {
                        Toast.makeText(
                                        this,
                                        "请长按监测功能区开关实时输入监测",
                                        Toast.LENGTH_SHORT)
                                .show();
                    }
                });
        LinearLayout.LayoutParams testerParams =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.08f);
        columns.addView(monitorFrame, testerParams);
        navigationCursor = new NavigationCursorView(this);
        FrameLayout.LayoutParams cursorParams =
                new FrameLayout.LayoutParams(dp(78), dp(78));
        navigationCursor.setElevation(dp(100));
        navigationCursor.setVisibility(View.GONE);
        root.addView(navigationCursor, cursorParams);
        return root;
    }

    private void setupNavigationTargets() {
        navigationTargets.clear();
        addNavigationTarget(monitorFrame);
        addNavigationTarget(xboxButton);
        addNavigationTarget(ds4Button);
        addNavigationTarget(customLayoutButton);
        addNavigationTarget(editPresetMappingButton);
        addNavigationTarget(bluetoothButton);
        addNavigationTarget(usbButton);
        addNavigationTarget(startButton);
        addNavigationTarget(stopButton);
        addNavigationTarget(screenSaverPickerButton);
        addNavigationTarget(screenSaverDefaultButton);
        addNavigationTarget(screenSaverPreviewButton);
        addNavigationTarget(screenSaverIntervalButton);
        addNavigationTarget(screenSaverLoopButton);
        addNavigationTarget(screenSaverExitButton);
        addNavigationTarget(screenSaverGamepadExitButton);
        addNavigationTarget(deadZoneButton);
        addNavigationTarget(calibrationButton);
        addNavigationTarget(axisDirectionButton);
        addNavigationTarget(vibrationToggle);
        addNavigationTarget(nameButton);
    }

    private void addNavigationTarget(View view) {
        if (view == null || navigationTargets.contains(view)) {
            return;
        }
        view.setFocusable(true);
        view.setFocusableInTouchMode(true);
        if (touchScreenAvailable) {
            int touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
            view.setOnTouchListener(
                    new View.OnTouchListener() {
                        private float downX;
                        private float downY;
                        private boolean moved;

                        @Override
                        public boolean onTouch(View target, MotionEvent event) {
                            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                                downX = event.getX();
                                downY = event.getY();
                                moved = false;
                                touchMonitorLongPressTriggered = false;
                                target.setPressed(true);
                                if (target == monitorFrame) {
                                    navigationHandler.removeCallbacks(
                                            touchMonitorLongPressAction);
                                    navigationHandler.postDelayed(
                                            touchMonitorLongPressAction, 600L);
                                }
                                return true;
                            }
                            if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                                float dx = event.getX() - downX;
                                float dy = event.getY() - downY;
                                if (dx * dx + dy * dy > touchSlop * touchSlop) {
                                    moved = true;
                                    target.setPressed(false);
                                    if (target == monitorFrame) {
                                        navigationHandler.removeCallbacks(
                                                touchMonitorLongPressAction);
                                    }
                                }
                                return true;
                            }
                            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                                target.setPressed(false);
                                if (target == monitorFrame) {
                                    navigationHandler.removeCallbacks(
                                            touchMonitorLongPressAction);
                                }
                                if (!moved && !touchMonitorLongPressTriggered) {
                                    target.performClick();
                                }
                                touchMonitorLongPressTriggered = false;
                                return true;
                            }
                            if (event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                                target.setPressed(false);
                                if (target == monitorFrame) {
                                    navigationHandler.removeCallbacks(
                                            touchMonitorLongPressAction);
                                }
                                touchMonitorLongPressTriggered = false;
                                return true;
                            }
                            return false;
                        }
                    });
        }
        view.setOnFocusChangeListener(
                (target, hasFocus) -> {
                    if (hasFocus && navigationCursorVisible) {
                        postNavigationCursorUpdate();
                    } else if (!hasFocus) {
                        navigationCursor.setVisibility(View.GONE);
                    }
                });
        navigationTargets.add(view);
    }

    private void setMonitorUiEnabled(boolean enabled) {
        if (monitorDisabledOverlay != null) {
            monitorDisabledOverlay.setVisibility(enabled ? View.GONE : View.VISIBLE);
        }
        if (testerView == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            testerView.setRenderEffect(
                    enabled
                            ? null
                            : RenderEffect.createBlurEffect(
                                    dp(13), dp(13), Shader.TileMode.CLAMP));
        } else {
            testerView.setAlpha(enabled ? 1f : 0.28f);
        }
    }

    private void toggleMonitorByLongPress() {
        if (!touchScreenAvailable
                || touchMonitorLongPressTriggered
                || screensaverView != null
                || calibrationOverlay != null) {
            return;
        }
        touchMonitorLongPressTriggered = true;
        if (rootLayout != null) {
            rootLayout.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM);
        }
        if (monitorActive) {
            activateNavigationMode(false);
        } else {
            activateMonitorMode();
        }
    }

    private void postNavigationCursorUpdate() {
        if (navigationCursor == null || rootLayout == null) {
            return;
        }
        navigationCursor.removeCallbacks(navigationCursorRefresh);
        navigationCursor.postDelayed(navigationCursorRefresh, 70L);
    }

    private void updateNavigationCursor() {
        if (navigationCursor == null) {
            return;
        }
        View focused = getCurrentFocus();
        if (!navigationCursorVisible
                || monitorActive
                || screensaverView != null
                || calibrationOverlay != null
                || focused == null
                || !navigationTargets.contains(focused)
                || !focused.isShown()) {
            navigationCursor.setVisibility(View.GONE);
            return;
        }
        Rect visible = new Rect();
        if (!focused.getGlobalVisibleRect(visible) || visible.isEmpty()) {
            navigationCursor.setVisibility(View.GONE);
            return;
        }
        int[] targetLocation = new int[2];
        int[] rootLocation = new int[2];
        focused.getLocationOnScreen(targetLocation);
        rootLayout.getLocationOnScreen(rootLocation);
        float left = targetLocation[0] - rootLocation[0];
        float top = targetLocation[1] - rootLocation[1];
        int size = Math.round(dp(78));
        float centerX =
                left + (focused == monitorFrame ? dp(34) : Math.min(focused.getWidth() * 0.18f, dp(19)));
        float centerY = top + focused.getHeight() / 2f;
        float x = Math.max(dp(2), Math.min(rootLayout.getWidth() - size - dp(2), centerX - size / 2f));
        float y = Math.max(dp(2), Math.min(rootLayout.getHeight() - size - dp(2), centerY - size / 2f));
        navigationCursor.setX(x);
        navigationCursor.setY(y);
        navigationCursor.setEmphasized(focused == monitorFrame);
        navigationCursor.setVisibility(View.VISIBLE);
        navigationCursor.bringToFront();
    }

    private View buildHero() {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(16), dp(13), dp(16), dp(14));
        GradientDrawable background = rounded(INK, 18);
        hero.setBackground(background);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = label("Lens controller", 23, Color.WHITE, Typeface.BOLD);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = label("ANDROID", 8, INK, Typeface.BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(rounded(ACCENT, 99));
        top.addView(badge, new LinearLayout.LayoutParams(dp(62), dp(23)));
        hero.addView(top, matchWrap());

        TextView subtitle =
                label("把掌机变成电脑上的独立手柄", 11, Color.rgb(173, 182, 198), Typeface.NORMAL);
        LinearLayout.LayoutParams subtitleParams = matchWrap();
        subtitleParams.topMargin = dp(4);
        hero.addView(subtitle, subtitleParams);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams chipParams = matchWrap();
        chipParams.topMargin = dp(11);
        chips.addView(chip("USB / BT", Color.rgb(79, 91, 111)), new LinearLayout.LayoutParams(-2, -2));
        chips.addView(space(6, true));
        chips.addView(chip("LOW LATENCY", Color.rgb(79, 91, 111)), new LinearLayout.LayoutParams(-2, -2));
        chips.addView(space(6, true));
        chips.addView(
                chip("XBOX · DS4", Color.rgb(79, 91, 111)),
                new LinearLayout.LayoutParams(-2, -2));
        hero.addView(chips, chipParams);
        return hero;
    }

    private TextView chip(String text, int color) {
        TextView view = label(text, 8, Color.rgb(216, 223, 234), Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(8), dp(4), dp(8), dp(4));
        view.setBackground(rounded(color, 99));
        return view;
    }

    private TextView sectionLabel(String text) {
        return label(text, 9, Color.rgb(92, 103, 121), Typeface.BOLD);
    }

    private TextView modeButton(String title, String subtitle, boolean selected) {
        TextView button = new TextView(this);
        button.setText(title + "\n" + subtitle);
        button.setTextSize(10);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        button.setGravity(Gravity.CENTER);
        button.setLineSpacing(dp(2), 1f);
        button.setPadding(dp(5), dp(7), dp(5), dp(7));
        button.setTag(selected);
        return button;
    }

    private TextView actionButton(String text, boolean primary) {
        TextView button = label(text, 12, primary ? INK : Color.rgb(77, 89, 108), Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setClickable(true);
        button.setFocusable(true);
        if (!primary) {
            button.setBackground(rounded(Color.rgb(231, 235, 242), 14, Color.rgb(214, 220, 230)));
        }
        return button;
    }

    private TextView utilityButton(String text, boolean accent) {
        TextView button =
                label(
                        text,
                        10,
                        accent ? INK : Color.rgb(73, 84, 102),
                        Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setClickable(true);
        button.setFocusable(true);
        button.setBackground(
                accent
                        ? rounded(ACCENT, 11)
                        : rounded(Color.rgb(238, 241, 247), 11, Color.rgb(217, 223, 233)));
        return button;
    }

    private LinearLayout card(
            int color, int radius, int left, int top, int right, int bottom) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(left), dp(top), dp(right), dp(bottom));
        card.setBackground(rounded(color, radius));
        card.setElevation(dp(1));
        return card;
    }

    private void refreshSelection() {
        if (xboxButton == null) {
            return;
        }
        styleModeButton(xboxButton, outputProfile == OutputProfile.XBOX, INK);
        styleModeButton(ds4Button, outputProfile == OutputProfile.DUALSHOCK_4, INK);
        styleModeButton(bluetoothButton, connectionMode == ConnectionMode.BLUETOOTH, INK);
        styleModeButton(usbButton, connectionMode == ConnectionMode.USB, INK);
        styleModeButton(
                customLayoutButton,
                preferences.hasCustomLayout(preferences.getActiveLayoutName()),
                INK);
        if (testerView != null) {
            testerView.setOutputProfile(outputProfile);
        }
        startButton.setBackground(rounded(ACCENT, 14));
        stopButton.setAlpha(0.72f);

        if (connectionMode == ConnectionMode.BLUETOOTH) {
            hintText.setText(
                    "首次配对：Windows 蓝牙 → 添加设备 → "
                            + preferences.getBluetoothName()
                            + "。\n"
                            + "蓝牙同样通过 PC 配套程序输出 Xbox / DualShock 4，"
                            + "不会显示成 Android 通用 HID 手柄。");
        } else {
            hintText.setText(
                    "USB 线连接电脑 → 允许 USB 调试 → 运行配套 PC 程序。\n"
                            + "未开启调试时，也可在掌机打开 USB 网络共享。\n"
                            + "PC 端会输出 Xbox 360 或 DualShock 4 布局。");
        }
        setControlsEnabled(!bridgeSession.isRunning());
    }

    private void selectOutputProfile(OutputProfile profile) {
        outputProfile = profile;
        String layoutName = AppPreferences.presetLayoutName(profile);
        preferences.setActiveLayout(layoutName);
        inputMapper.setKeyMapping(preferences.getPresetMapping(profile));
        inputMapper.reset();
        bridgeSession.updateState(controllerState());
        refreshSelection();
        refreshLayoutSummary();
        refreshInputMonitor();
    }

    private void refreshCustomizationSummary() {
        refreshScreensaverSummary();
        int deadZone = preferences.getDeadZonePercent();
        deadZoneSummaryText.setText(deadZone + "% · 出厂建议 8%");
        boolean calibrated = preferences.isCalibrated();
        calibrationSummaryText.setText(calibrated ? "已保存自定中心与行程" : "当前使用硬件默认值");
        axisDirectionSummaryText.setText(axisDirectionSummary());
        nameSummaryText.setText(
                "蓝牙 " + preferences.getBluetoothName()
                        + " · 手柄 " + preferences.getControllerName());
        refreshLayoutSummary();
        if (testerView != null) {
            testerView.setTuning(deadZone, calibrated);
        }
    }

    private void refreshScreensaverSummary() {
        int count = preferences.getScreensaverUris().size();
        String loopMode = preferences.isScreensaverRandom() ? "随机" : "全循环";
        screenSaverSummaryText.setText(
                (count == 0 ? "默认 12 张" : "自定义 " + count + " 张")
                        + " · "
                        + preferences.getScreensaverIntervalSeconds()
                        + "秒 · "
                        + loopMode);
        if (screenSaverHintText != null) {
            screenSaverHintText.setText(
                    "图片全屏播放；"
                            + (touchScreenAvailable
                                    ? "触控板持续可用，轻触 "
                                            + preferences.getScreensaverExitTaps()
                                            + " 次退出。"
                                    : "无触摸掌机模式。")
                            + "手柄退出："
                            + preferences.screensaverGamepadExitSummary());
        }
        if (screenSaverIntervalButton != null) {
            screenSaverIntervalButton.setText(
                    "间隔 " + preferences.getScreensaverIntervalSeconds() + "秒");
            screenSaverLoopButton.setText(preferences.isScreensaverRandom() ? "随机循环" : "全循环");
            screenSaverExitButton.setText(
                    "退出 " + preferences.getScreensaverExitTaps() + "次");
            screenSaverGamepadExitButton.setText(
                    "手柄退出：" + preferences.screensaverGamepadExitSummary());
            boolean configured = preferences.isScreensaverGamepadExitConfigured();
            screenSaverGamepadExitButton.setTextColor(INK);
            screenSaverGamepadExitButton.setBackground(
                    configured
                            ? rounded(
                                    Color.rgb(238, 241, 247),
                                    11,
                                    Color.rgb(217, 223, 233))
                            : rounded(ACCENT, 11));
        }
    }

    private void refreshLayoutSummary() {
        String active = preferences.getActiveLayoutName();
        boolean customActive = preferences.hasCustomLayout(active);
        customLayoutButton.setText(
                customActive ? "自定义\n" + active : "自定义\n按键布局");
        styleModeButton(
                customLayoutButton,
                customActive,
                INK);
        editPresetMappingButton.setText(
                "编辑 " + outputProfile.displayName);
    }

    private void chooseScreenSaverImages() {
        Intent intent =
                new Intent(Intent.ACTION_OPEN_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("image/*")
                        .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        .addFlags(
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_PICK_SCREENSAVER);
    }

    private void showScreensaverIntervalDialog() {
        int original = preferences.getScreensaverIntervalSeconds();
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(10), dp(22), 0);
        TextView value = label(original + " 秒", 20, INK, Typeface.BOLD);
        value.setGravity(Gravity.CENTER);
        content.addView(value, matchWrap());
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(58);
        seekBar.setProgress(original - 2);
        content.addView(seekBar, matchWrap());
        content.addView(
                label("可设置 2–60 秒；间隔越短，功耗越高。", 10, MUTED, Typeface.NORMAL),
                matchWrap());
        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                        value.setText((progress + 2) + " 秒");
                    }

                    @Override public void onStartTrackingTouch(SeekBar bar) {}
                    @Override public void onStopTrackingTouch(SeekBar bar) {}
                });
        new AlertDialog.Builder(this)
                .setTitle("幻灯片切换间隔")
                .setView(content)
                .setPositiveButton(
                        "保存",
                        (dialog, which) -> {
                            preferences.setScreensaverIntervalSeconds(seekBar.getProgress() + 2);
                            refreshScreensaverSummary();
                        })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showScreensaverLoopDialog() {
        String[] modes = {"全循环", "随机循环"};
        int selected = preferences.isScreensaverRandom() ? 1 : 0;
        new AlertDialog.Builder(this)
                .setTitle("幻灯片循环模式")
                .setSingleChoiceItems(
                        modes,
                        selected,
                        (dialog, which) -> {
                            preferences.setScreensaverRandom(which == 1);
                            refreshScreensaverSummary();
                            dialog.dismiss();
                        })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showScreensaverExitDialog() {
        int original = preferences.getScreensaverExitTaps();
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(10), dp(22), 0);
        TextView value = label(original + " 次", 20, INK, Typeface.BOLD);
        value.setGravity(Gravity.CENTER);
        content.addView(value, matchWrap());
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(17);
        seekBar.setProgress(original - 3);
        content.addView(seekBar, matchWrap());
        content.addView(
                label("可设置 3–20 次轻触。", 10, MUTED, Typeface.NORMAL),
                matchWrap());
        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                        value.setText((progress + 3) + " 次");
                    }

                    @Override public void onStartTrackingTouch(SeekBar bar) {}
                    @Override public void onStopTrackingTouch(SeekBar bar) {}
                });
        new AlertDialog.Builder(this)
                .setTitle("屏保退出轻触次数")
                .setView(content)
                .setPositiveButton(
                        "保存",
                        (dialog, which) -> {
                            preferences.setScreensaverExitTaps(seekBar.getProgress() + 3);
                            refreshScreensaverSummary();
                        })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showScreensaverGamepadExitDialog(Runnable afterSave) {
        String originalMethod = preferences.getScreensaverGamepadExitMethod();
        String originalKey = preferences.getScreensaverGamepadExitKey();
        int originalCount = preferences.getScreensaverGamepadExitCount();
        int originalHold = preferences.getScreensaverGamepadExitHoldSeconds();

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), 0);
        TextView explanation =
                label(
                        "无触摸掌机进入屏保后，所有普通手柄操作都会停用，只保留这里设置的退出手势。",
                        11,
                        MUTED,
                        Typeface.NORMAL);
        explanation.setLineSpacing(dp(2), 1f);
        content.addView(explanation, matchWrap());
        content.addView(space(8));
        content.addView(label("退出方式", 11, INK, Typeface.BOLD));

        RadioGroup methodGroup = new RadioGroup(this);
        methodGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton pressButton = new RadioButton(this);
        pressButton.setText("连续按键");
        pressButton.setId(View.generateViewId());
        RadioButton holdButton = new RadioButton(this);
        holdButton.setText("长按按键");
        holdButton.setId(View.generateViewId());
        methodGroup.addView(pressButton);
        methodGroup.addView(holdButton);
        methodGroup.check(
                AppPreferences.GAMEPAD_EXIT_HOLD.equals(originalMethod)
                        ? holdButton.getId()
                        : pressButton.getId());
        content.addView(methodGroup, matchWrap());

        content.addView(label("使用哪个按键", 11, INK, Typeface.BOLD));
        RadioGroup keyGroup = new RadioGroup(this);
        keyGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton startButtonOption = new RadioButton(this);
        startButtonOption.setText("Start");
        startButtonOption.setId(View.generateViewId());
        RadioButton homeButtonOption = new RadioButton(this);
        homeButtonOption.setText("Home / Mode");
        homeButtonOption.setId(View.generateViewId());
        RadioButton selectButtonOption = new RadioButton(this);
        selectButtonOption.setText("Select");
        selectButtonOption.setId(View.generateViewId());
        keyGroup.addView(startButtonOption);
        keyGroup.addView(homeButtonOption);
        keyGroup.addView(selectButtonOption);
        int keyId =
                AppPreferences.GAMEPAD_EXIT_HOME.equals(originalKey)
                        ? homeButtonOption.getId()
                        : AppPreferences.GAMEPAD_EXIT_SELECT.equals(originalKey)
                                ? selectButtonOption.getId()
                                : startButtonOption.getId();
        keyGroup.check(keyId);
        content.addView(keyGroup, matchWrap());

        TextView pressValue = label(originalCount + " 次", 18, INK, Typeface.BOLD);
        pressValue.setGravity(Gravity.CENTER);
        SeekBar pressBar = new SeekBar(this);
        pressBar.setMax(8);
        pressBar.setProgress(originalCount - 2);
        content.addView(pressValue, matchWrap());
        content.addView(pressBar, matchWrap());

        TextView holdValue = label(originalHold + " 秒", 18, INK, Typeface.BOLD);
        holdValue.setGravity(Gravity.CENTER);
        SeekBar holdBar = new SeekBar(this);
        holdBar.setMax(9);
        holdBar.setProgress(originalHold - 1);
        content.addView(holdValue, matchWrap());
        content.addView(holdBar, matchWrap());

        Runnable refreshVisibility =
                () -> {
                    boolean hold = methodGroup.getCheckedRadioButtonId() == holdButton.getId();
                    pressValue.setVisibility(hold ? View.GONE : View.VISIBLE);
                    pressBar.setVisibility(hold ? View.GONE : View.VISIBLE);
                    holdValue.setVisibility(hold ? View.VISIBLE : View.GONE);
                    holdBar.setVisibility(hold ? View.VISIBLE : View.GONE);
                };
        methodGroup.setOnCheckedChangeListener((group, checkedId) -> refreshVisibility.run());
        pressBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        pressValue.setText((progress + 2) + " 次");
                    }

                    @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                    @Override public void onStopTrackingTouch(SeekBar seekBar) {}
                });
        holdBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        holdValue.setText((progress + 1) + " 秒");
                    }

                    @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                    @Override public void onStopTrackingTouch(SeekBar seekBar) {}
                });
        refreshVisibility.run();

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.addView(content);
        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("屏保手柄退出")
                        .setView(scroller)
                        .setPositiveButton("保存", null)
                        .setNegativeButton("取消", null)
                        .create();
        dialog.setOnShowListener(
                ignored -> {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                            .setOnClickListener(
                                    view -> {
                                            String method =
                                                    methodGroup.getCheckedRadioButtonId()
                                                                    == holdButton.getId()
                                                            ? AppPreferences.GAMEPAD_EXIT_HOLD
                                                            : AppPreferences.GAMEPAD_EXIT_PRESS;
                                            String key =
                                                    keyGroup.getCheckedRadioButtonId()
                                                                    == homeButtonOption.getId()
                                                            ? AppPreferences.GAMEPAD_EXIT_HOME
                                                            : keyGroup.getCheckedRadioButtonId()
                                                                            == selectButtonOption
                                                                                    .getId()
                                                                    ? AppPreferences.GAMEPAD_EXIT_SELECT
                                                                    : AppPreferences.GAMEPAD_EXIT_START;
                                            preferences.configureScreensaverGamepadExit(
                                                    method,
                                                    key,
                                                    pressBar.getProgress() + 2,
                                                    holdBar.getProgress() + 1);
                                            refreshScreensaverSummary();
                                            dialog.dismiss();
                                            Toast.makeText(
                                                            this,
                                                            "屏保手柄退出已保存",
                                                            Toast.LENGTH_SHORT)
                                                    .show();
                                            if (afterSave != null) {
                                                rootLayout.post(afterSave);
                                            }
                                    });
                });
        dialog.show();
        attachDialogGamepadKeys(dialog);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).requestFocus();
    }

    private void showDeadZoneDialog() {
        int original = preferences.getDeadZonePercent();
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(10), dp(22), 0);

        TextView value = label(original + "%", 20, INK, Typeface.BOLD);
        value.setGravity(Gravity.CENTER);
        content.addView(value, matchWrap());

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(29);
        seekBar.setProgress(original - 1);
        content.addView(seekBar, matchWrap());

        TextView explanation =
                label("数值越大，越能过滤摇杆漂移，但会损失少量微调范围。",
                        10, MUTED, Typeface.NORMAL);
        explanation.setLineSpacing(dp(2), 1f);
        content.addView(explanation, matchWrap());

        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                        int percent = progress + 1;
                        value.setText(percent + "%");
                        inputMapper.setDeadZonePercent(percent);
                        deadZoneSummaryText.setText(percent + "% · 出厂建议 8%");
                        testerView.setTuning(percent, preferences.isCalibrated());
                    }

                    @Override public void onStartTrackingTouch(SeekBar bar) {}
                    @Override public void onStopTrackingTouch(SeekBar bar) {}
                });

        new AlertDialog.Builder(this)
                .setTitle("摇杆死区")
                .setView(content)
                .setPositiveButton(
                        "保存",
                        (dialog, which) -> {
                            int percent = seekBar.getProgress() + 1;
                            preferences.setDeadZonePercent(percent);
                            inputMapper.setDeadZonePercent(percent);
                            refreshCustomizationSummary();
                        })
                .setNegativeButton(
                        "取消",
                        (dialog, which) -> {
                            inputMapper.setDeadZonePercent(original);
                            refreshCustomizationSummary();
                        })
                .show();
    }

    private String axisDirectionSummary() {
        List<String> changes = new ArrayList<>();
        if (preferences.isLeftXInverted()) changes.add("左X反");
        if (preferences.isLeftYInverted()) changes.add("左Y反");
        if (preferences.isRightXInverted()) changes.add("右X反");
        if (preferences.isRightYInverted()) changes.add("右Y反");
        if (preferences.shouldSwapSticks()) changes.add("交换双摇杆");
        return changes.isEmpty() ? "标准方向 · 适用于大部分 Android 手柄" : String.join(" · ", changes);
    }

    private void showAxisDirectionDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), 0);

        CheckBox invertLeftX =
                optionCheckBox("左摇杆左右反转", preferences.isLeftXInverted());
        CheckBox invertLeftY =
                optionCheckBox("左摇杆上下反转", preferences.isLeftYInverted());
        CheckBox invertRightX =
                optionCheckBox("右摇杆左右反转", preferences.isRightXInverted());
        CheckBox invertRightY =
                optionCheckBox("右摇杆上下反转", preferences.isRightYInverted());
        CheckBox swapSticks =
                optionCheckBox("交换左右摇杆", preferences.shouldSwapSticks());
        content.addView(invertLeftX);
        content.addView(invertLeftY);
        content.addView(invertRightX);
        content.addView(invertRightY);
        content.addView(swapSticks);

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("摇杆方向与交换")
                        .setMessage("如果左右或上下方向相反，可在这里修正。")
                        .setView(content)
                        .setPositiveButton("保存", null)
                        .setNeutralButton("恢复标准", null)
                        .setNegativeButton("取消", null)
                        .create();
        dialog.setOnShowListener(
                ignored -> {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                            .setOnClickListener(
                                    view -> {
                                        preferences.setAxisOptions(
                                                invertLeftX.isChecked(),
                                                invertLeftY.isChecked(),
                                                invertRightX.isChecked(),
                                                invertRightY.isChecked(),
                                                swapSticks.isChecked());
                                        inputMapper.setAxisOptions(
                                                invertLeftX.isChecked(),
                                                invertLeftY.isChecked(),
                                                invertRightX.isChecked(),
                                                invertRightY.isChecked(),
                                                swapSticks.isChecked());
                                        inputMapper.reset();
                                        bridgeSession.updateState(ControllerState.NEUTRAL);
                                        refreshCustomizationSummary();
                                        dialog.dismiss();
                                    });
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
                            .setOnClickListener(
                                    view -> {
                                        invertLeftX.setChecked(false);
                                        invertLeftY.setChecked(false);
                                        invertRightX.setChecked(false);
                                        invertRightY.setChecked(false);
                                        swapSticks.setChecked(false);
                                    });
                });
        dialog.show();
    }

    private CheckBox optionCheckBox(String text, boolean checked) {
        CheckBox option = new CheckBox(this);
        option.setText(text);
        option.setTextSize(12);
        option.setTextColor(Color.rgb(53, 63, 78));
        option.setChecked(checked);
        option.setPadding(0, dp(5), 0, dp(5));
        return option;
    }

    private void showNameDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), 0);

        content.addView(label("蓝牙连接名称", 11, INK, Typeface.BOLD));
        EditText bluetoothName = new EditText(this);
        bluetoothName.setText(preferences.getBluetoothName());
        bluetoothName.setSingleLine(true);
        content.addView(bluetoothName, matchWrap());

        TextView bluetoothHint =
                label("Windows 配对列表中会显示这个名称，下次开始蓝牙桥接时生效。",
                        9, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams bluetoothHintParams = matchWrap();
        bluetoothHintParams.bottomMargin = dp(10);
        content.addView(bluetoothHint, bluetoothHintParams);

        content.addView(label("手柄显示名称", 11, INK, Typeface.BOLD));
        EditText controllerName = new EditText(this);
        controllerName.setText(preferences.getControllerName());
        controllerName.setSingleLine(true);
        content.addView(controllerName, matchWrap());

        content.addView(
                label("用于掌机界面与 PC 日志；Windows 虚拟设备仍保持选定的手柄兼容类型。",
                        9, MUTED, Typeface.NORMAL),
                matchWrap());

        new AlertDialog.Builder(this)
                .setTitle("设备与手柄名称")
                .setView(content)
                .setPositiveButton(
                        "保存",
                        (dialog, which) -> {
                            preferences.setBluetoothName(
                                    bluetoothName.getText().toString());
                            preferences.setControllerName(
                                    controllerName.getText().toString());
                            refreshCustomizationSummary();
                            refreshInputMonitor();
                            Toast.makeText(
                                            this,
                                            "名称已保存，蓝牙名称将在下次桥接时应用",
                                            Toast.LENGTH_LONG)
                                    .show();
                        })
                .setNegativeButton("取消", null)
                .show();
    }

    private String controllerDisplayName() {
        if (!inputMapper.hasDevice()) {
            return "等待手柄输入";
        }
        String configured = preferences.getControllerName();
        String physical = inputMapper.deviceName();
        String display =
                physical.equals("等待手柄输入") ? configured : configured + " · " + physical;
        if (batteryPercent >= 0) {
            display += " · " + batteryPercent + "%" + (batteryCharging ? " ⚡" : "");
        }
        return display;
    }

    private void showCalibrationIntro() {
        new AlertDialog.Builder(this)
                .setTitle("摇杆校准")
                .setMessage(
                        "校准分两步：\n\n"
                                + "1. 松开两个摇杆并保持不动 2 秒。\n"
                                + "2. 在 6 秒内让两个摇杆各绕完整一圈。\n\n"
                                + "校准时请保持桥接界面在前台。")
                .setPositiveButton(
                        "开始",
                        (dialog, which) -> startCalibrationFlow())
                .setNegativeButton("取消", null)
                .show();
    }

    private void startCalibrationFlow() {
        calibrationHandler.removeCallbacksAndMessages(null);
        inputMapper.beginCenterCapture();
        showCalibrationOverlay("第 1 / 2 步\n请松开两个摇杆，正在采集中心位置…");

        calibrationHandler.postDelayed(
                () -> {
                    if (calibrationOverlay == null) {
                        return;
                    }
                    inputMapper.beginRangeCapture();
                    calibrationStatusText.setText(
                            "第 2 / 2 步\n请将两个摇杆缓慢推到边缘，并各绕完整一圈…");
                },
                2_000L);
        for (long delay : new long[] {4_000L, 6_000L}) {
            calibrationHandler.postDelayed(
                    () -> {
                        if (calibrationOverlay == null || calibrationStatusText == null) {
                            return;
                        }
                        calibrationStatusText.setText(
                                "正在采集摇杆行程…\n已记录 "
                                        + inputMapper.calibrationSampleCount()
                                        + " 个输入帧");
                    },
                    delay);
        }
        calibrationHandler.postDelayed(
                () -> {
                    if (calibrationOverlay == null) {
                        return;
                    }
                    boolean captured = inputMapper.hasRangeSamples();
                    StickCalibration calibration = inputMapper.finishCalibration();
                    if (captured) {
                        preferences.saveCalibration(calibration);
                    }
                    hideCalibrationOverlay();
                    refreshCustomizationSummary();
                    Toast.makeText(
                                    this,
                                    captured
                                            ? "摇杆校准已保存"
                                            : "未采集到摇杆行程，已保留原校准",
                                    Toast.LENGTH_LONG)
                            .show();
                },
                8_000L);
    }

    private void showCalibrationOverlay(String message) {
        hideCalibrationOverlay();
        FrameLayout scrim = new FrameLayout(this);
        scrim.setBackgroundColor(Color.argb(150, 10, 13, 18));
        scrim.setClickable(true);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(24), dp(22), dp(24), dp(18));
        panel.setBackground(rounded(Color.WHITE, 20));

        TextView title = label("摇杆校准", 20, INK, Typeface.BOLD);
        panel.addView(title, matchWrap());

        calibrationStatusText = label(message, 13, Color.rgb(69, 80, 96), Typeface.NORMAL);
        calibrationStatusText.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(10);
        panel.addView(calibrationStatusText, statusParams);

        TextView cancel = utilityButton("取消校准", false);
        LinearLayout.LayoutParams cancelParams =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        cancelParams.topMargin = dp(18);
        panel.addView(cancel, cancelParams);
        cancel.setOnClickListener(
                view -> {
                    calibrationHandler.removeCallbacksAndMessages(null);
                    inputMapper.cancelCalibration();
                    hideCalibrationOverlay();
                    Toast.makeText(this, "已取消摇杆校准", Toast.LENGTH_SHORT).show();
                });

        FrameLayout.LayoutParams panelParams =
                new FrameLayout.LayoutParams(dp(430), ViewGroup.LayoutParams.WRAP_CONTENT);
        panelParams.gravity = Gravity.CENTER;
        scrim.addView(panel, panelParams);
        rootLayout.addView(
                scrim,
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        calibrationOverlay = scrim;
    }

    private void hideCalibrationOverlay() {
        if (calibrationOverlay != null && rootLayout != null) {
            rootLayout.removeView(calibrationOverlay);
        }
        calibrationOverlay = null;
        calibrationStatusText = null;
    }

    private void showScreensaver(boolean preview) {
        if (rootLayout == null || screensaverView != null) {
            return;
        }
        if (!preferences.isScreensaverGamepadExitConfigured()) {
            if (!preview) {
                screensaverDismissedForConnection = true;
            }
            promptScreensaverExitSetup(preview);
            return;
        }
        navigationCursorVisible = false;
        updateNavigationCursor();
        originalScreenBrightness = getWindow().getAttributes().screenBrightness;
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.screenBrightness = 0.01f;
        getWindow().setAttributes(attributes);
        hideSystemBarsForScreensaver();

        screensaverView = new ScreensaverView(this);
        screensaverView.configure(
                preferences.getScreensaverUris(),
                preferences.getScreensaverIntervalSeconds(),
                preferences.isScreensaverRandom(),
                preferences.getScreensaverExitTaps(),
                touchScreenAvailable,
                screensaverExitHint(),
                () -> hideScreensaver(true),
                this::setTouchpadState);
        rootLayout.addView(
                screensaverView,
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        screensaverView.startSlideshow();
    }

    private void hideScreensaver(boolean dismissedByUser) {
        screensaverHandler.removeCallbacksAndMessages(null);
        screensaverExitKeyCode = KeyEvent.KEYCODE_UNKNOWN;
        screensaverExitPressCount = 0;
        screensaverExitLongTriggered = false;
        if (screensaverView != null) {
            screensaverView.stopSlideshow();
            rootLayout.removeView(screensaverView);
            screensaverView = null;
        }
        if (dismissedByUser) {
            screensaverDismissedForConnection = true;
        }
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.screenBrightness = originalScreenBrightness;
        getWindow().setAttributes(attributes);
        restoreSystemBars();
        restoreNavigationAfterScreensaver();
    }

    private void restoreNavigationAfterScreensaver() {
        if (monitorActive || monitorFrame == null || rootLayout == null) {
            return;
        }
        restoreNavigationFocusOnNextInput = true;
        rootLayout.postDelayed(
                () -> {
                    if (monitorActive
                            || screensaverView != null
                            || calibrationOverlay != null) {
                        return;
                    }
                    navigationIndex =
                            Math.max(0, navigationTargets.indexOf(monitorFrame));
                    monitorFrame.requestFocus();
                    if (navigationCursorVisible) {
                        postNavigationCursorUpdate();
                    }
                },
                180L);
    }

    private void promptScreensaverExitSetup(boolean retryAfterSave) {
        if (screensaverConfigPromptVisible) {
            Toast.makeText(this, "请先完成屏保手柄退出设置", Toast.LENGTH_SHORT).show();
            return;
        }
        screensaverConfigPromptVisible = true;
        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("先设置屏保退出方式")
                        .setMessage(
                                "屏保会停用除退出组合外的全部掌机手柄操作。"
                                        + "为防止无触摸掌机进入屏保后无法退出，必须先设置 Start、Home/Mode 或 Select 的按键次数或长按时间。")
                        .setPositiveButton(
                                "现在设置",
                                (ignored, which) -> {
                                    screensaverConfigPromptVisible = false;
                                    rootLayout.post(
                                            () ->
                                                    showScreensaverGamepadExitDialog(
                                                            () -> showScreensaver(retryAfterSave)));
                                })
                        .setNegativeButton(
                                "暂不进入",
                                (ignored, which) -> {
                                    screensaverConfigPromptVisible = false;
                                    screensaverDismissedForConnection = true;
                                })
                        .setOnCancelListener(
                                ignored -> {
                                    screensaverConfigPromptVisible = false;
                                    screensaverDismissedForConnection = true;
                                })
                        .create();
        attachDialogGamepadKeys(dialog);
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).requestFocus();
    }

    private String screensaverExitHint() {
        String gamepad = preferences.screensaverGamepadExitSummary();
        return touchScreenAvailable
                ? "轻触 " + preferences.getScreensaverExitTaps() + " 次或 " + gamepad + " 退出"
                : gamepad + " 退出";
    }

    private boolean handleScreensaverGamepadExit(KeyEvent event) {
        if (!preferences.isScreensaverGamepadExitConfigured()
                || !matchesScreensaverExitKey(event.getKeyCode())) {
            return false;
        }
        if (AppPreferences.GAMEPAD_EXIT_HOLD.equals(
                preferences.getScreensaverGamepadExitMethod())) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                screensaverExitKeyCode = event.getKeyCode();
                screensaverExitLongTriggered = false;
                screensaverHandler.removeCallbacks(screensaverLongPressAction);
                screensaverHandler.postDelayed(
                        screensaverLongPressAction,
                        preferences.getScreensaverGamepadExitHoldSeconds() * 1_000L);
            } else if (event.getAction() == KeyEvent.ACTION_UP
                    && event.getKeyCode() == screensaverExitKeyCode) {
                screensaverHandler.removeCallbacks(screensaverLongPressAction);
                screensaverExitKeyCode = KeyEvent.KEYCODE_UNKNOWN;
                screensaverExitLongTriggered = false;
            }
            return true;
        }

        if (event.getAction() != KeyEvent.ACTION_DOWN || event.getRepeatCount() > 0) {
            return true;
        }
        long now = android.os.SystemClock.elapsedRealtime();
        if (screensaverExitPressCount == 0 || now - screensaverExitFirstPressAt > 2_000L) {
            screensaverExitPressCount = 1;
            screensaverExitFirstPressAt = now;
        } else {
            screensaverExitPressCount++;
        }
        if (screensaverExitPressCount >= preferences.getScreensaverGamepadExitCount()) {
            screensaverExitPressCount = 0;
            exitScreensaverByGamepad();
        }
        return true;
    }

    private void handleScreensaverLongPress() {
        if (screensaverView == null
                || screensaverExitLongTriggered
                || screensaverExitKeyCode == KeyEvent.KEYCODE_UNKNOWN
                || !matchesScreensaverExitKey(screensaverExitKeyCode)) {
            return;
        }
        screensaverExitLongTriggered = true;
        exitScreensaverByGamepad();
    }

    private boolean matchesScreensaverExitKey(int keyCode) {
        String configured = preferences.getScreensaverGamepadExitKey();
        if (AppPreferences.GAMEPAD_EXIT_HOME.equals(configured)) {
            return keyCode == KeyEvent.KEYCODE_BUTTON_MODE || keyCode == KeyEvent.KEYCODE_HOME;
        }
        if (AppPreferences.GAMEPAD_EXIT_SELECT.equals(configured)) {
            return keyCode == KeyEvent.KEYCODE_BUTTON_SELECT;
        }
        return keyCode == KeyEvent.KEYCODE_BUTTON_START;
    }

    private void exitScreensaverByGamepad() {
        screensaverHandler.removeCallbacksAndMessages(null);
        screensaverExitKeyCode = KeyEvent.KEYCODE_UNKNOWN;
        screensaverExitPressCount = 0;
        hideScreensaver(true);
        if (!monitorActive && monitorFrame != null) {
            navigationCursorVisible = true;
            monitorFrame.requestFocus();
            postNavigationCursorUpdate();
        }
        if (rootLayout != null) {
            rootLayout.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM);
        }
        Toast.makeText(this, "屏保已退出，手柄操作已恢复", Toast.LENGTH_SHORT).show();
    }

    private void hideSystemBarsForScreensaver() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow()
                    .getDecorView()
                    .setSystemUiVisibility(
                            View.SYSTEM_UI_FLAG_FULLSCREEN
                                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private void restoreSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.show(WindowInsets.Type.systemBars());
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    private void styleModeButton(TextView button, boolean selected, int selectedColor) {
        button.setBackground(
                selected
                        ? rounded(INK, 14)
                        : rounded(CARD, 14, Color.rgb(218, 224, 234)));
        button.setTextColor(selected ? Color.WHITE : Color.rgb(72, 83, 101));
        button.setElevation(selected ? dp(2) : 0);
    }

    private void setControlsEnabled(boolean enabled) {
        xboxButton.setEnabled(enabled);
        ds4Button.setEnabled(enabled);
        editPresetMappingButton.setEnabled(enabled);
        customLayoutButton.setEnabled(enabled);
        bluetoothButton.setEnabled(enabled);
        usbButton.setEnabled(enabled);
        xboxButton.setAlpha(enabled ? 1f : 0.62f);
        ds4Button.setAlpha(enabled ? 1f : 0.62f);
        editPresetMappingButton.setAlpha(enabled ? 1f : 0.62f);
        customLayoutButton.setAlpha(enabled ? 1f : 0.62f);
        bluetoothButton.setAlpha(enabled ? 1f : 0.62f);
        usbButton.setAlpha(enabled ? 1f : 0.62f);
        startButton.setText(enabled ? "开始桥接" : "桥接中");
        stopButton.setAlpha(enabled ? 0.72f : 1f);
    }

    private void toggleBridge() {
        if (bridgeSession.isRunning()) {
            stopBridge("连接已停止");
            return;
        }
        if (connectionMode == ConnectionMode.BLUETOOTH) {
            requestBluetoothAndStart();
        } else {
            startBridge();
        }
    }

    private void requestBluetoothAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            List<String> missing = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            }
            if (!missing.isEmpty()) {
                waitingToStartAfterPermission = true;
                requestPermissions(missing.toArray(new String[0]), REQUEST_BLUETOOTH);
                return;
            }
        }

        BluetoothManager manager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) {
            updateStatus("这台设备没有蓝牙适配器", false, true);
            return;
        }
        if (!adapter.isEnabled()) {
            waitingToStartAfterPermission = true;
            startActivityForResult(
                    new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),
                    REQUEST_ENABLE_BLUETOOTH);
            return;
        }
        startBridge();
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_BLUETOOTH) {
            return;
        }
        boolean granted = grantResults.length > 0;
        for (int result : grantResults) {
            granted &= result == PackageManager.PERMISSION_GRANTED;
        }
        if (granted && waitingToStartAfterPermission) {
            waitingToStartAfterPermission = false;
            requestBluetoothAndStart();
        } else {
            waitingToStartAfterPermission = false;
            Toast.makeText(this, "需要附近设备权限才能使用蓝牙手柄", Toast.LENGTH_LONG).show();
            updateStatus("蓝牙权限未授予", false, true);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_SCREENSAVER) {
            if (resultCode == RESULT_OK && data != null) {
                List<String> selected = new ArrayList<>();
                if (data.getClipData() != null) {
                    for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                        addSelectedScreensaverUri(
                                selected, data.getClipData().getItemAt(i).getUri(), data.getFlags());
                    }
                } else if (data.getData() != null) {
                    addSelectedScreensaverUri(selected, data.getData(), data.getFlags());
                }
                if (!selected.isEmpty()) {
                    preferences.setScreensaverUris(selected);
                    refreshScreensaverSummary();
                    Toast.makeText(
                                    this,
                                    "已选择 " + selected.size() + " 张屏保图片",
                                    Toast.LENGTH_SHORT)
                            .show();
                }
            }
            return;
        }
        if (requestCode != REQUEST_ENABLE_BLUETOOTH) {
            return;
        }
        boolean shouldStart = waitingToStartAfterPermission;
        waitingToStartAfterPermission = false;
        if (resultCode == RESULT_OK && shouldStart) {
            startBridge();
        } else {
            updateStatus("蓝牙尚未开启", false, true);
        }
    }

    private void startBridge() {
        hideScreensaver(false);
        screensaverDismissedForConnection = false;
        refreshBattery();
        inputMapper.reset();
        setControlsEnabled(false);
        deviceText.setText(controllerDisplayName());
        bridgeSession.start(
                connectionMode,
                outputProfile,
                (message, connected) -> {
                    updateStatus(message, connected, false);
                    testerView.setInput(
                            inputMapper.state(), controllerDisplayName(), connected);
                    if (connected && !screensaverDismissedForConnection) {
                        showScreensaver(false);
                    } else if (!connected) {
                        if (screensaverView != null) {
                            hideScreensaver(false);
                        }
                        screensaverDismissedForConnection = false;
                    }
                });
        bridgeSession.updateState(controllerState());
        updateStatus("正在启动…", false, false);
    }

    private void stopBridge(String message) {
        hideScreensaver(false);
        screensaverDismissedForConnection = false;
        bridgeSession.stop();
        inputMapper.reset();
        setControlsEnabled(true);
        refreshSelection();
        updateStatus(message, false, true);
        refreshInputMonitor();
    }

    private void addSelectedScreensaverUri(List<String> selected, Uri uri, int flags) {
        if (uri == null) {
            return;
        }
        String value = uri.toString();
        if (selected.contains(value)) {
            return;
        }
        try {
            getContentResolver()
                    .takePersistableUriPermission(
                            uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
            // Some document providers grant temporary read access only.
        }
        selected.add(value);
    }

    private void afterInputChanged() {
        ControllerState state = controllerState();
        bridgeSession.updateState(state);
        if (screensaverView != null) {
            return;
        }
        if (!inputUiRefreshPosted) {
            inputUiRefreshPosted = true;
            inputUiHandler.postDelayed(inputUiRefresh, 33L);
        }
    }

    private void renderInputMonitor() {
        inputUiRefreshPosted = false;
        if (testerView == null || inputMapper == null) {
            return;
        }
        deviceText.setText(controllerDisplayName());
        testerView.setInput(
                inputMapper.state(), controllerDisplayName(), bridgeSession.isConnected());
        if (!bridgeSession.isRunning() && inputMapper.hasDevice()) {
            updateStatus("手柄已就绪，可以开始桥接", false, true);
        }
    }

    private ControllerState controllerState() {
        return inputMapper
                .state()
                .withBattery(batteryPercent, batteryCharging)
                .withTouches(touchpadState);
    }

    private void setTouchpadState(TouchpadState state) {
        touchpadState = outputProfile == OutputProfile.XBOX ? TouchpadState.NONE : state;
        bridgeSession.updateState(controllerState());
    }

    private void refreshBattery() {
        BatteryManager batteryManager =
                (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
        int capacity =
                batteryManager == null
                        ? ControllerState.UNKNOWN_BATTERY
                        : batteryManager.getIntProperty(
                                BatteryManager.BATTERY_PROPERTY_CAPACITY);
        Intent battery =
                registerReceiver(
                        null,
                        new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (capacity < 0 && battery != null) {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            capacity = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
        }
        batteryPercent = capacity >= 0 ? Math.max(0, Math.min(100, capacity)) : ControllerState.UNKNOWN_BATTERY;
        batteryCharging =
                battery != null
                        && battery.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        bridgeSession.updateState(controllerState());
        if (deviceText != null) {
            deviceText.setText(inputMapper.hasDevice() ? controllerDisplayName() : "未检测到掌机手柄");
        }
        batteryHandler.removeCallbacks(batteryRefresh);
        if (!isFinishing()) {
            batteryHandler.postDelayed(batteryRefresh, 30_000L);
        }
    }

    private void refreshInputMonitor() {
        inputUiHandler.removeCallbacks(inputUiRefresh);
        inputUiRefreshPosted = false;
        String displayName = controllerDisplayName();
        testerView.setInput(inputMapper.state(), displayName, false);
        deviceText.setText(inputMapper.hasDevice() ? displayName : "未检测到掌机手柄");
    }

    private void updateStatus(String message, boolean connected, boolean inputReady) {
        statusText.setText(message);
        int color =
                connected
                        ? Color.rgb(75, 190, 123)
                        : inputReady ? Color.rgb(248, 200, 78) : Color.rgb(142, 151, 168);
        statusDot.setBackground(rounded(color, 99));
    }

    private TextView label(String text, float sizeSp, int color, int style) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setTypeface(Typeface.create("sans", style));
        view.setIncludeFontPadding(false);
        return view;
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable rounded(int color, float radiusDp, int strokeColor) {
        GradientDrawable drawable = rounded(color, radiusDp);
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private View space(int heightDp) {
        View view = new View(this);
        view.setLayoutParams(new LinearLayout.LayoutParams(1, dp(heightDp)));
        return view;
    }

    private View space(int widthDp, boolean horizontal) {
        View view = new View(this);
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), 1));
        return view;
    }

    private LinearLayout.LayoutParams weightedSpace() {
        return new LinearLayout.LayoutParams(dp(1), 1);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, dp(50), 1f);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void attachDialogGamepadKeys(AlertDialog dialog) {
        GamepadDialogNavigator.attach(dialog, inputMapper);
    }

    private void configureSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(PAPER);
        window.setNavigationBarColor(INK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.setSystemBarsAppearance(
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    private void applyInsets(View view) {
        view.setOnApplyWindowInsetsListener(
                (target, insets) -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        android.graphics.Insets bars =
                                insets.getInsets(WindowInsets.Type.systemBars());
                        target.setPadding(0, bars.top, 0, 0);
                    } else {
                        target.setPadding(
                                0,
                                insets.getSystemWindowInsetTop(),
                                0,
                                0);
                    }
                    return insets;
                });
    }
}
