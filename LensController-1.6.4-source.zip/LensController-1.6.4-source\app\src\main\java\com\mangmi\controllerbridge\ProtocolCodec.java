package com.mangmi.controllerbridge;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.CRC32;

/**
 * Wire format shared with the Windows companion.
 *
 * <pre>
 * 0..3   "MGB1"
 * 4      protocol version (2)
 * 5      output profile
 * 6      sequence number
 * 7      flags
 * 8..11  left X/Y, right X/Y (signed bytes)
 * 12..13 left/right trigger (unsigned bytes)
 * 14..17 button bit mask (little-endian int32)
 * 18     battery percent, 255 means unknown
 * 19     touch 1 id
 * 20..21 touch 1 X
 * 22..23 touch 1 Y
 * 24     touch 2 id
 * 25..26 touch 2 X
 * 27..28 touch 2 Y
 * 29..31 reserved
 * 32..35 CRC32 of bytes 0..31 (little-endian)
 * </pre>
 */
public final class ProtocolCodec {
    public static final int PACKET_SIZE = 36;
    public static final int VERSION = 2;
    public static final int FLAG_ACTIVE = 1;
    public static final int FLAG_TOUCH1_PRESENT = 1 << 1;
    public static final int FLAG_TOUCH1_ACTIVE = 1 << 2;
    public static final int FLAG_TOUCH2_PRESENT = 1 << 3;
    public static final int FLAG_TOUCH2_ACTIVE = 1 << 4;
    public static final int FLAG_CHARGING = 1 << 5;
    public static final int FLAG_TOUCH_CLICK = 1 << 6;

    private static final byte[] MAGIC = {'M', 'G', 'B', '1'};

    private ProtocolCodec() {}

    public static byte[] encodeHandshake(String controllerName) {
        String safeName =
                controllerName == null || controllerName.isBlank()
                        ? "Lens controller"
                        : controllerName.trim();
        String encoded =
                Base64.getEncoder()
                        .encodeToString(safeName.getBytes(StandardCharsets.UTF_8));
        return ("LENS1 " + encoded + "\n").getBytes(StandardCharsets.US_ASCII);
    }

    public static byte[] encode(
            ControllerState state, OutputProfile profile, int sequence, boolean active) {
        ByteBuffer buffer =
                ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.LITTLE_ENDIAN);
        buffer.put(MAGIC);
        buffer.put((byte) VERSION);
        buffer.put(profile.wireValue);
        buffer.put((byte) (sequence & 0xFF));
        int flags = active ? FLAG_ACTIVE : 0;
        if (state.touch1Id >= 0) {
            flags |= FLAG_TOUCH1_PRESENT;
            if (state.touch1Active) {
                flags |= FLAG_TOUCH1_ACTIVE;
            }
        }
        if (state.touch2Id >= 0) {
            flags |= FLAG_TOUCH2_PRESENT;
            if (state.touch2Active) {
                flags |= FLAG_TOUCH2_ACTIVE;
            }
        }
        if (state.charging) {
            flags |= FLAG_CHARGING;
        }
        if (state.touchClick) {
            flags |= FLAG_TOUCH_CLICK;
        }
        buffer.put((byte) flags);
        buffer.put((byte) state.leftX);
        buffer.put((byte) state.leftY);
        buffer.put((byte) state.rightX);
        buffer.put((byte) state.rightY);
        buffer.put((byte) state.leftTrigger);
        buffer.put((byte) state.rightTrigger);
        buffer.putInt(state.buttons);
        buffer.put((byte) (state.batteryPercent < 0 ? 255 : state.batteryPercent));
        buffer.put((byte) Math.max(0, state.touch1Id));
        buffer.putShort((short) state.touch1X);
        buffer.putShort((short) state.touch1Y);
        buffer.put((byte) Math.max(0, state.touch2Id));
        buffer.putShort((short) state.touch2X);
        buffer.putShort((short) state.touch2Y);
        buffer.put((byte) 0);
        buffer.put((byte) 0);
        buffer.put((byte) 0);

        byte[] packet = buffer.array();
        CRC32 crc = new CRC32();
        crc.update(packet, 0, 32);
        ByteBuffer.wrap(packet, 32, 4).order(ByteOrder.LITTLE_ENDIAN).putInt((int) crc.getValue());
        return packet;
    }

    public static DecodedPacket decode(byte[] data, int length) {
        if (length != PACKET_SIZE) {
            throw new IllegalArgumentException("Unexpected packet length: " + length);
        }
        for (int i = 0; i < MAGIC.length; i++) {
            if (data[i] != MAGIC[i]) {
                throw new IllegalArgumentException("Bad packet magic");
            }
        }

        ByteBuffer buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        int version = data[4] & 0xFF;
        if (version != VERSION) {
            throw new IllegalArgumentException("Unsupported protocol version: " + version);
        }

        CRC32 crc = new CRC32();
        crc.update(data, 0, 32);
        int expectedCrc = buffer.getInt(32);
        if ((int) crc.getValue() != expectedCrc) {
            throw new IllegalArgumentException("Packet checksum mismatch");
        }

        int flags = data[7] & 0xFF;
        boolean touch1Present = (flags & FLAG_TOUCH1_PRESENT) != 0;
        boolean touch2Present = (flags & FLAG_TOUCH2_PRESENT) != 0;
        int battery = data[18] & 0xFF;
        ControllerState state =
                new ControllerState(
                        data[8],
                        data[9],
                        data[10],
                        data[11],
                        data[12] & 0xFF,
                        data[13] & 0xFF,
                        buffer.getInt(14),
                        battery == 255 ? ControllerState.UNKNOWN_BATTERY : battery,
                        (flags & FLAG_CHARGING) != 0,
                        (flags & FLAG_TOUCH1_ACTIVE) != 0,
                        touch1Present ? data[19] & 0x7F : ControllerState.NO_TOUCH_ID,
                        buffer.getShort(20) & 0xFFFF,
                        buffer.getShort(22) & 0xFFFF,
                        (flags & FLAG_TOUCH2_ACTIVE) != 0,
                        touch2Present ? data[24] & 0x7F : ControllerState.NO_TOUCH_ID,
                        buffer.getShort(25) & 0xFFFF,
                        buffer.getShort(27) & 0xFFFF,
                        (flags & FLAG_TOUCH_CLICK) != 0);
        return new DecodedPacket(
                state,
                OutputProfile.fromWireValue(data[5] & 0xFF),
                data[6] & 0xFF,
                (flags & FLAG_ACTIVE) != 0);
    }

    public static final class DecodedPacket {
        public final ControllerState state;
        public final OutputProfile profile;
        public final int sequence;
        public final boolean active;

        public DecodedPacket(
                ControllerState state, OutputProfile profile, int sequence, boolean active) {
            this.state = state;
            this.profile = profile;
            this.sequence = sequence;
            this.active = active;
        }
    }
}
