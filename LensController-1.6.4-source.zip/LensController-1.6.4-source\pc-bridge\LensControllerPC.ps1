﻿param(
    [switch]$Autostart
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
if (-not ("LensNativeWindow" -as [type])) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class LensNativeWindow {
    [DllImport("kernel32.dll")]
    public static extern IntPtr GetConsoleWindow();
    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("shell32.dll")]
    public static extern int SetCurrentProcessExplicitAppUserModelID(
        [MarshalAs(UnmanagedType.LPWStr)] string appId
    );
}
"@
}
[LensNativeWindow]::SetCurrentProcessExplicitAppUserModelID(
    "LensScience.LensController.PC"
) | Out-Null
$consoleHandle = [LensNativeWindow]::GetConsoleWindow()
if ($consoleHandle -ne [IntPtr]::Zero) {
    [LensNativeWindow]::ShowWindow($consoleHandle, 0) | Out-Null
}

$mutexName = "Local\LensControllerPC-6D1CA164"
$showEventName = "Local\LensControllerPC-Show-6D1CA164"
$createdNew = $false
$mutex = New-Object System.Threading.Mutex(
    $true,
    $mutexName,
    [ref]$createdNew
)
$eventCreated = $false
$showEvent = New-Object System.Threading.EventWaitHandle(
    $false,
    [System.Threading.EventResetMode]::AutoReset,
    $showEventName,
    [ref]$eventCreated
)
if (-not $createdNew) {
    if ($null -ne $showEvent) {
        [void]$showEvent.Set()
    } elseif (-not $Autostart) {
        [System.Windows.Forms.MessageBox]::Show(
            "Lens controller 控制面板已经在运行，请在任务栏通知区域查找。",
            "Lens controller",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    exit 0
}

$root = $PSScriptRoot
$nodePath = Join-Path $root "runtime\node.exe"
$serverPath = Join-Path $root "server.js"
$stateDirectory = Join-Path $env:LOCALAPPDATA "LensController"
New-Item -ItemType Directory -Path $stateDirectory -Force | Out-Null
$logPath = Join-Path $stateDirectory "service.log"
$pidPath = Join-Path $stateDirectory "service.pid"
$controllerNamePath = Join-Path $stateDirectory "controller-name.txt"
$launchLogPath = Join-Path $stateDirectory "service-launch.log"
$launchErrorPath = Join-Path $stateDirectory "service-launch-error.log"
$iconPath = Join-Path $root "app.ico"
$taskbarIconPath = Join-Path $root "app-white.ico"
$logoPath = Join-Path $root "lens-mark.png"
$startScript = Join-Path $root "start-pc.vbs"
$startupDirectory = [Environment]::GetFolderPath("Startup")
$startupShortcut = Join-Path $startupDirectory "Lens controller PC.lnk"
$script:updatingCheckbox = $false
$script:allowClose = $false
$script:lastLogSignature = ""
$script:lastStatusKey = ""

function Test-LensService {
    try {
        return @(
            Get-NetTCPConnection -LocalPort 47654 -State Listen -ErrorAction SilentlyContinue
        ).Count -gt 0
    } catch {
        $line = netstat.exe -ano -p tcp |
            Select-String -Pattern ":47654\s+.*LISTENING" |
            Select-Object -First 1
        return $null -ne $line
    }
}

function Start-LensService {
    if (Test-LensService) {
        return
    }
    $requiredFiles = @(
        @{ Path = $nodePath; Label = "内置 Node 运行环境（runtime\node.exe）" },
        @{ Path = $serverPath; Label = "主服务程序（server.js）" },
        @{
            Path = (Join-Path $root "node_modules\koffi\package.json")
            Label = "Koffi 原生模块（node_modules\koffi）"
        },
        @{
            Path = (Join-Path $root "node_modules\@koromix\koffi-win32-x64\win32_x64\koffi.node")
            Label = "Windows x64 原生绑定（koffi.node）"
        },
        @{
            Path = (Join-Path $root "native\ViGEmClient.dll")
            Label = "虚拟手柄客户端（ViGEmClient.dll）"
        },
        @{
            Path = (Join-Path $root "virtual-gamepad.js")
            Label = "虚拟手柄模块（virtual-gamepad.js）"
        },
        @{
            Path = (Join-Path $root "dualshock-gamepad.js")
            Label = "DualShock 4 模块（dualshock-gamepad.js）"
        },
        @{
            Path = (Join-Path $root "protocol.js")
            Label = "输入协议模块（protocol.js）"
        },
        @{
            Path = (Join-Path $root "protocol-stream.js")
            Label = "数据流模块（protocol-stream.js）"
        },
        @{
            Path = (Join-Path $root "adb-reverse.js")
            Label = "USB ADB 模块（adb-reverse.js）"
        },
        @{
            Path = (Join-Path $root "bluetooth-rfcomm-worker.js")
            Label = "蓝牙接收模块（bluetooth-rfcomm-worker.js）"
        },
        @{
            Path = (Join-Path $root "bluetooth-feedback-worker.js")
            Label = "蓝牙反馈模块（bluetooth-feedback-worker.js）"
        },
        @{
            Path = (Join-Path $root "bluetooth-discovery.js")
            Label = "蓝牙发现模块（bluetooth-discovery.js）"
        }
    )
    $missing = @(
        $requiredFiles |
            Where-Object { -not (Test-Path -LiteralPath $_.Path) } |
            ForEach-Object { $_.Label }
    )
    if ($missing.Count -gt 0) {
        throw (
            "安装缺少必要组件：`r`n - " +
            ($missing -join "`r`n - ") +
            "`r`n请关闭杀毒软件拦截后重新运行安装程序。"
        )
    }
    $driver = Get-Service -Name ViGEmBus -ErrorAction SilentlyContinue
    if (-not $driver) {
        $driverScript = Join-Path $root "install-driver.ps1"
        if (-not (Test-Path -LiteralPath $driverScript)) {
            throw "电脑缺少 ViGEmBus 虚拟手柄驱动，且安装目录中没有驱动修复脚本。请重新运行安装程序。"
        }
        try {
            $driverProcess = Start-Process `
                -FilePath "powershell.exe" `
                -ArgumentList @(
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    "`"$driverScript`""
                ) `
                -Verb RunAs `
                -Wait `
                -PassThru
        } catch {
            throw (
                "电脑缺少 ViGEmBus 虚拟手柄驱动，自动修复未获得管理员权限。`r`n" +
                "请右键以管理员身份运行安装目录中的 install-pc.cmd。"
            )
        }
        $driver = Get-Service -Name ViGEmBus -ErrorAction SilentlyContinue
        if (-not $driver) {
            throw (
                "ViGEmBus 驱动修复失败，退出码 $($driverProcess.ExitCode)。`r`n" +
                "请重启电脑后重新运行安装程序。"
            )
        }
    }
    Remove-Item -LiteralPath $launchLogPath, $launchErrorPath -Force -ErrorAction SilentlyContinue
    $process = Start-Process `
        -FilePath $nodePath `
        -ArgumentList "server.js" `
        -WorkingDirectory $root `
        -WindowStyle Hidden `
        -RedirectStandardOutput $launchLogPath `
        -RedirectStandardError $launchErrorPath `
        -PassThru
    for ($attempt = 0; $attempt -lt 60; $attempt++) {
        Start-Sleep -Milliseconds 100
        if (Test-LensService) {
            Set-Content -LiteralPath $pidPath -Value $process.Id -Encoding ASCII
            return
        }
        if ($process.HasExited) {
            $details = @()
            foreach ($path in @($launchErrorPath, $launchLogPath)) {
                if (Test-Path -LiteralPath $path) {
                    $text = Get-Content -LiteralPath $path -Tail 12 -ErrorAction SilentlyContinue
                    if ($text) {
                        $details += $text
                    }
                }
            }
            if ($details.Count -eq 0) {
                $details = @("Node 进程在开始监听端口前退出。")
            }
            throw (
                "后台服务启动失败，退出码 $($process.ExitCode)。`r`n" +
                ($details -join [Environment]::NewLine) +
                "`r`n可查看：$launchErrorPath"
            )
        }
    }
    if (-not $process.HasExited) {
        Set-Content -LiteralPath $pidPath -Value $process.Id -Encoding ASCII
        throw (
            "后台服务进程已经启动，但 6 秒内未监听端口 47654。`r`n" +
            "请查看日志：$launchLogPath"
        )
    }
}

function Stop-LensService {
    $serviceProcessIds = New-Object System.Collections.Generic.HashSet[int]
    try {
        foreach ($connection in @(
            Get-NetTCPConnection -LocalPort 47654 -State Listen -ErrorAction SilentlyContinue
        )) {
            if ($connection.OwningProcess -gt 0) {
                [void]$serviceProcessIds.Add([int]$connection.OwningProcess)
            }
        }
    } catch {
        # The PID file below remains as a fallback.
    }
    if (Test-Path -LiteralPath $pidPath) {
        $storedText = (Get-Content -LiteralPath $pidPath -ErrorAction SilentlyContinue |
            Select-Object -First 1).Trim()
        $storedProcessId = 0
        if ([int]::TryParse($storedText, [ref]$storedProcessId) -and
            $storedProcessId -gt 0) {
            [void]$serviceProcessIds.Add($storedProcessId)
        }
    }

    foreach ($serviceProcessId in $serviceProcessIds) {
        $process = Get-CimInstance Win32_Process `
            -Filter "ProcessId=$serviceProcessId" `
            -ErrorAction SilentlyContinue
        if ($null -eq $process) {
            continue
        }
        if ($process.ExecutablePath -eq $nodePath -and
            $process.CommandLine -match "server\.js") {
            Stop-Process -Id $serviceProcessId -Force -ErrorAction SilentlyContinue
        }
    }
    Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 300
}

function Set-AutoStart([bool]$enabled) {
    if ($enabled) {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($startupShortcut)
        $shortcut.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
        $shortcut.Arguments = "`"$startScript`" -Autostart"
        $shortcut.WorkingDirectory = $root
        $shortcut.WindowStyle = 7
        $shortcut.Description = "Lens controller 蓝牙/USB 虚拟手柄服务"
        if (Test-Path -LiteralPath $taskbarIconPath) {
            $shortcut.IconLocation = "$taskbarIconPath,0"
        }
        $shortcut.Save()
    } else {
        Remove-Item -LiteralPath $startupShortcut -Force -ErrorAction SilentlyContinue
    }
}

function Get-RecentLog {
    if (-not (Test-Path -LiteralPath $logPath)) {
        return "尚未生成服务日志。"
    }
    try {
        $lines = Get-Content -LiteralPath $logPath -Tail 16 -Encoding UTF8
        if ($lines.Count -eq 0) {
            return "尚未生成服务日志。"
        }
        return ($lines -join [Environment]::NewLine)
    } catch {
        return "日志暂时无法读取。"
    }
}

[System.Windows.Forms.Application]::EnableVisualStyles()
$form = New-Object System.Windows.Forms.Form
$form.Text = "Lens controller | PC Service"
$form.ClientSize = New-Object System.Drawing.Size(620, 520)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = New-Object System.Drawing.Size(620, 520)
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(244, 247, 251)
$form.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 9)
$appIcon = if (Test-Path -LiteralPath $taskbarIconPath) {
    New-Object System.Drawing.Icon($taskbarIconPath)
} elseif (Test-Path -LiteralPath $iconPath) {
    New-Object System.Drawing.Icon($iconPath)
} else {
    [System.Drawing.SystemIcons]::Application
}
$form.Icon = $appIcon
$form.ShowIcon = $true

$header = New-Object System.Windows.Forms.Panel
$header.SetBounds(18, 18, 584, 92)
$header.BackColor = [System.Drawing.Color]::FromArgb(23, 28, 38)
$form.Controls.Add($header)

$brandImage = New-Object System.Windows.Forms.PictureBox
$brandLogo = $null
if (Test-Path -LiteralPath $logoPath) {
    $brandLogo = [System.Drawing.Image]::FromFile($logoPath)
    $brandImage.Image = $brandLogo
} else {
    $brandImage.Image = $appIcon.ToBitmap()
}
$brandImage.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$brandImage.BackColor = [System.Drawing.Color]::White
$brandImage.SetBounds(18, 20, 48, 48)
$header.Controls.Add($brandImage)

$title = New-Object System.Windows.Forms.Label
$title.Text = "Lens controller"
$title.ForeColor = [System.Drawing.Color]::White
$title.Font = New-Object System.Drawing.Font(
    "Microsoft YaHei UI",
    20,
    [System.Drawing.FontStyle]::Bold
)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(80, 14)
$header.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "Windows 蓝牙 / USB 虚拟手柄服务"
$subtitle.ForeColor = [System.Drawing.Color]::FromArgb(185, 194, 208)
$subtitle.AutoSize = $true
$subtitle.Location = New-Object System.Drawing.Point(82, 55)
$header.Controls.Add($subtitle)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.SetBounds(18, 124, 584, 96)
$statusPanel.BackColor = [System.Drawing.Color]::White
$form.Controls.Add($statusPanel)

$statusDot = New-Object System.Windows.Forms.Label
$statusDot.Text = "●"
$statusDot.Font = New-Object System.Drawing.Font("Segoe UI Symbol", 20)
$statusDot.AutoSize = $true
$statusDot.Location = New-Object System.Drawing.Point(18, 20)
$statusPanel.Controls.Add($statusDot)

$statusTitle = New-Object System.Windows.Forms.Label
$statusTitle.Text = "正在检查服务…"
$statusTitle.Font = New-Object System.Drawing.Font(
    "Microsoft YaHei UI",
    13,
    [System.Drawing.FontStyle]::Bold
)
$statusTitle.AutoSize = $true
$statusTitle.Location = New-Object System.Drawing.Point(58, 17)
$statusPanel.Controls.Add($statusTitle)

$statusDetail = New-Object System.Windows.Forms.Label
$statusDetail.Text = "USB 47654 · 蓝牙 RFCOMM"
$statusDetail.ForeColor = [System.Drawing.Color]::FromArgb(102, 113, 130)
$statusDetail.AutoSize = $true
$statusDetail.Location = New-Object System.Drawing.Point(60, 51)
$statusPanel.Controls.Add($statusDetail)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = "启动服务"
$startButton.FlatStyle = "Flat"
$startButton.FlatAppearance.BorderSize = 0
$startButton.BackColor = [System.Drawing.Color]::FromArgb(248, 200, 78)
$startButton.ForeColor = [System.Drawing.Color]::FromArgb(23, 28, 38)
$startButton.Font = New-Object System.Drawing.Font(
    "Microsoft YaHei UI",
    10,
    [System.Drawing.FontStyle]::Bold
)
$startButton.SetBounds(18, 232, 278, 44)
$form.Controls.Add($startButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "停止服务"
$stopButton.FlatStyle = "Flat"
$stopButton.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(211, 218, 229)
$stopButton.BackColor = [System.Drawing.Color]::White
$stopButton.ForeColor = [System.Drawing.Color]::FromArgb(70, 81, 99)
$stopButton.Font = New-Object System.Drawing.Font(
    "Microsoft YaHei UI",
    10,
    [System.Drawing.FontStyle]::Bold
)
$stopButton.SetBounds(306, 232, 296, 44)
$form.Controls.Add($stopButton)

$autoStartCheck = New-Object System.Windows.Forms.CheckBox
$autoStartCheck.Text = "Windows 登录时自动启动服务（托盘运行）"
$autoStartCheck.AutoSize = $true
$autoStartCheck.ForeColor = [System.Drawing.Color]::FromArgb(55, 65, 81)
$autoStartCheck.Location = New-Object System.Drawing.Point(20, 292)
$form.Controls.Add($autoStartCheck)

$info = New-Object System.Windows.Forms.Label
$info.Text = "首次蓝牙连接请在 Windows 蓝牙设置中添加掌机里设置的蓝牙名称。`r`n" +
    "USB 模式请连接数据线并允许掌机的 USB 调试。"
$info.ForeColor = [System.Drawing.Color]::FromArgb(96, 107, 124)
$info.SetBounds(20, 322, 580, 42)
$form.Controls.Add($info)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = "Vertical"
$logBox.BackColor = [System.Drawing.Color]::FromArgb(28, 33, 43)
$logBox.ForeColor = [System.Drawing.Color]::FromArgb(195, 204, 218)
$logBox.Font = New-Object System.Drawing.Font("Consolas", 8.5)
$logBox.SetBounds(18, 374, 584, 126)
$form.Controls.Add($logBox)

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = $appIcon
$notify.Text = "Lens controller PC Service"
$notify.Visible = $true
$notifyMenu = New-Object System.Windows.Forms.ContextMenuStrip
$openItem = $notifyMenu.Items.Add("打开控制面板")
$startItem = $notifyMenu.Items.Add("启动服务")
$stopItem = $notifyMenu.Items.Add("停止服务")
[void]$notifyMenu.Items.Add("-")
$exitItem = $notifyMenu.Items.Add("退出 Lens controller")
$notify.ContextMenuStrip = $notifyMenu

function Show-ControlPanel {
    $form.ShowInTaskbar = $true
    $form.Show()
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
        $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    }
    $form.Activate()
}

function Refresh-Status {
    $running = Test-LensService
    $connectedName = ""
    if ($running -and (Test-Path -LiteralPath $controllerNamePath)) {
        $connectedName = (
            Get-Content -LiteralPath $controllerNamePath -Raw -ErrorAction SilentlyContinue
        ).Trim()
    }
    $logSignature = ""
    if (Test-Path -LiteralPath $logPath) {
        try {
            $logInfo = Get-Item -LiteralPath $logPath
            $logSignature = "$($logInfo.Length)|$($logInfo.LastWriteTimeUtc.Ticks)"
        } catch {
            $logSignature = "unreadable"
        }
    }
    $statusKey = "$running|$connectedName|$logSignature"
    if ($statusKey -eq $script:lastStatusKey) {
        return
    }
    $script:lastStatusKey = $statusKey
    if ($running) {
        $statusDot.ForeColor = [System.Drawing.Color]::FromArgb(72, 190, 125)
        $statusTitle.Text = "服务运行中"
        if ($connectedName) {
            $statusDetail.Text = "最近手柄：$connectedName · USB / 蓝牙已就绪"
        } else {
            $statusDetail.Text = "USB 47654 与蓝牙 RFCOMM 正在监听"
        }
    } else {
        $statusDot.ForeColor = [System.Drawing.Color]::FromArgb(157, 165, 178)
        $statusTitle.Text = "服务已停止"
        $statusDetail.Text = "启动服务后，掌机即可通过 USB 或蓝牙连接"
    }
    $startButton.Enabled = -not $running
    $stopButton.Enabled = $running
    if ($running) {
        $startButton.Text = "服务运行中"
        $startButton.BackColor = [System.Drawing.Color]::FromArgb(230, 234, 241)
        $startButton.ForeColor = [System.Drawing.Color]::FromArgb(128, 138, 154)
    } else {
        $startButton.Text = "启动服务"
        $startButton.BackColor = [System.Drawing.Color]::FromArgb(248, 200, 78)
        $startButton.ForeColor = [System.Drawing.Color]::FromArgb(23, 28, 38)
    }
    $script:updatingCheckbox = $true
    $autoStartCheck.Checked = Test-Path -LiteralPath $startupShortcut
    $script:updatingCheckbox = $false
    if ($logSignature -ne $script:lastLogSignature) {
        $script:lastLogSignature = $logSignature
        $logBox.Text = Get-RecentLog
        $logBox.SelectionStart = $logBox.TextLength
        $logBox.ScrollToCaret()
    }
}

$startButton.Add_Click({
    try {
        Start-LensService
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.Message,
            "无法启动服务",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    Refresh-Status
})

$stopButton.Add_Click({
    try {
        Stop-LensService
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.Message,
            "无法停止服务",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    Refresh-Status
})

$autoStartCheck.Add_CheckedChanged({
    if ($script:updatingCheckbox) {
        return
    }
    try {
        Set-AutoStart $autoStartCheck.Checked
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.Message,
            "无法修改自启动",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    Refresh-Status
})

$openItem.Add_Click({ Show-ControlPanel })
$startItem.Add_Click({ Start-LensService; Refresh-Status })
$stopItem.Add_Click({ Stop-LensService; Refresh-Status })
$exitItem.Add_Click({
    $script:allowClose = $true
    Stop-LensService
    $notify.Visible = $false
    $form.Close()
    [System.Windows.Forms.Application]::Exit()
})
$notify.Add_DoubleClick({ Show-ControlPanel })

$form.Add_FormClosing({
    param($sender, $eventArgs)
    if (-not $script:allowClose) {
        $eventArgs.Cancel = $true
        $form.Hide()
        $form.ShowInTaskbar = $false
        $notify.ShowBalloonTip(
            1800,
            "Lens controller",
            "服务仍在后台运行，可双击托盘图标重新打开控制面板。",
            [System.Windows.Forms.ToolTipIcon]::Info
        )
    }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1500
$timer.Add_Tick({
    if ($showEvent.WaitOne(0)) {
        Show-ControlPanel
        Refresh-Status
        return
    }
    if ($form.Visible) {
        Refresh-Status
    }
})
$timer.Start()

$form.Add_Shown({
    try {
        Start-LensService
    } catch {
        $statusTitle.Text = "服务启动失败"
        $statusDetail.Text = $_.Exception.Message
    }
    Refresh-Status
    if ($Autostart) {
        $form.Hide()
        $form.ShowInTaskbar = $false
        $notify.ShowBalloonTip(
            1500,
            "Lens controller",
            "虚拟手柄服务已在后台启动。",
            [System.Windows.Forms.ToolTipIcon]::Info
        )
    }
})

try {
    [System.Windows.Forms.Application]::Run($form)
} finally {
    $timer.Stop()
    $notify.Visible = $false
    $notify.Dispose()
    if ($null -ne $brandLogo) {
        $brandLogo.Dispose()
    }
    $appIcon.Dispose()
    $showEvent.Dispose()
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
