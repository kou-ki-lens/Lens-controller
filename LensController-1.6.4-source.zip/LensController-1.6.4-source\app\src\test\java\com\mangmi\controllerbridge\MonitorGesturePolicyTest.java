package com.mangmi.controllerbridge;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MonitorGesturePolicyTest {
    @Test
    public void noTouchRequiresSelectedMonitorAndXToEnter() {
        assertEquals(
                MonitorGesturePolicy.NONE,
                MonitorGesturePolicy.resolve(
                        false, false, false, ButtonMapping.ACTION_X));
        assertEquals(
                MonitorGesturePolicy.ENTER,
                MonitorGesturePolicy.resolve(
                        false, false, true, ButtonMapping.ACTION_X));
    }

    @Test
    public void noTouchUsesLongBToExitActiveMonitor() {
        assertEquals(
                MonitorGesturePolicy.EXIT,
                MonitorGesturePolicy.resolve(
                        false, true, false, ButtonMapping.ACTION_B));
    }

    @Test
    public void touchDevicesKeepLongPressAreaPath() {
        assertEquals(
                MonitorGesturePolicy.NONE,
                MonitorGesturePolicy.resolve(
                        true, false, true, ButtonMapping.ACTION_X));
    }
}
