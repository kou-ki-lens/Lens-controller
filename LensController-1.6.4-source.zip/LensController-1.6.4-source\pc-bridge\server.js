"use strict";

const dgram = require("node:dgram");
const fs = require("node:fs");
const net = require("node:net");
const os = require("node:os");
const path = require("node:path");
const { Worker } = require("node:worker_threads");
const { decodePacket } = require("./protocol");
const {
  consumeProtocolData,
  createProtocolState,
} = require("./protocol-stream");
const { VirtualGamepad } = require("./virtual-gamepad");
const { startAdbReverse } = require("./adb-reverse");

const DISCOVERY_PORT = 47653;
const DATA_PORT = 47654;
const DISCOVER_REQUEST = "MANGMI_BRIDGE_DISCOVER_V1";
const DISCOVER_RESPONSE = `MANGMI_BRIDGE_SERVER_V1 ${DATA_PORT}`;

let activeGamepad = null;
let activeSocket = null;
let lastProfile = -1;
let stopAdbReverse = () => {};
let bluetoothWorker = null;
let bluetoothFeedbackWorker = null;
let bluetoothConnected = false;
let bluetoothRestartTimer = null;
let lastTouchActive = false;
let lastTouchClick = false;
let lastReportedBattery = -2;
let lastButtons = 0;
let lastRumbleLeft = -1;
let lastRumbleRight = -1;
let logFlushTimer = null;
const pendingLogLines = [];
const bluetoothStreamState = createProtocolState();
const stateDirectory = process.env.LOCALAPPDATA
  ? path.join(process.env.LOCALAPPDATA, "LensController")
  : path.join(os.tmpdir(), "LensController");
try {
  fs.mkdirSync(stateDirectory, { recursive: true });
} catch {
  // File-backed state remains optional if the user profile is read-only.
}
const bluetoothConfigPath = path.join(stateDirectory, "bluetooth-host.json");
const serviceLogPath = path.join(stateDirectory, "service.log");
const previousServiceLogPath = path.join(stateDirectory, "service.previous.log");
const controllerNamePath = path.join(stateDirectory, "controller-name.txt");

function sendRumbleFeedback(leftMotor, rightMotor) {
  const left = Math.max(0, Math.min(255, Number(leftMotor) || 0));
  const right = Math.max(0, Math.min(255, Number(rightMotor) || 0));
  const message = `LENSRUMBLE ${left} ${right}\n`;
  if (left !== lastRumbleLeft || right !== lastRumbleRight) {
    lastRumbleLeft = left;
    lastRumbleRight = right;
    log(`震动反馈：左 ${left} / 右 ${right}`);
  }
  if (activeSocket && !activeSocket.destroyed) {
    activeSocket.write(message);
  }
  if (bluetoothFeedbackWorker) {
    bluetoothFeedbackWorker.postMessage({ type: "rumble", left, right });
  }
}

function log(message) {
  const time = new Date().toLocaleTimeString("zh-CN", { hour12: false });
  const line = `[${time}] ${message}`;
  console.log(line);
  pendingLogLines.push(line);
  if (!logFlushTimer) {
    logFlushTimer = setTimeout(flushLogQueue, 200);
  }
}

function flushLogQueue(synchronous = false) {
  if (logFlushTimer) {
    clearTimeout(logFlushTimer);
    logFlushTimer = null;
  }
  if (pendingLogLines.length === 0) {
    return;
  }
  const payload = `${pendingLogLines.splice(0).join("\r\n")}\r\n`;
  try {
    if (synchronous) {
      rotateLogIfNeeded();
      fs.appendFileSync(serviceLogPath, payload, "utf8");
      return;
    }
    fs.stat(serviceLogPath, (error, stats) => {
      if (!error && stats.size > 1_000_000) {
        try {
          fs.renameSync(serviceLogPath, previousServiceLogPath);
        } catch {
          // Keep appending if another process briefly holds the old log.
        }
      }
      fs.appendFile(serviceLogPath, payload, "utf8", () => {});
    });
  } catch {
    // Console logging remains available if the installation directory is read-only.
  }
}

function rotateLogIfNeeded() {
  try {
    if (fs.existsSync(serviceLogPath) && fs.statSync(serviceLogPath).size > 1_000_000) {
      fs.renameSync(serviceLogPath, previousServiceLogPath);
    }
  } catch {
    // Keep the current log if it cannot be rotated.
  }
}

function disconnectActive() {
  if (activeGamepad) {
    try {
      activeGamepad.update({
        leftX: 0,
        leftY: 0,
        rightX: 0,
        rightY: 0,
        leftTrigger: 0,
        rightTrigger: 0,
        buttons: 0,
      });
    } catch {
      // The bus may already be gone.
    }
    activeGamepad.disconnect();
    activeGamepad = null;
  }
  lastProfile = -1;
}

function ensureGamepad(profile) {
  profile = profile === 1 ? 1 : 0;
  if (activeGamepad && lastProfile === profile) {
    return activeGamepad;
  }
  if (activeGamepad) {
    // The Android app fixes the profile for the lifetime of a TCP session.
    // Ignore a stray mid-session profile flag instead of resetting the device.
    log("忽略同一连接中的手柄类型切换");
    return activeGamepad;
  }
  disconnectActive();
  const gamepad = new VirtualGamepad(profile === 1 ? 1 : 0, sendRumbleFeedback);
  gamepad.connect();
  activeGamepad = gamepad;
  lastProfile = profile;
  log(profile === 1 ? "已插入虚拟 DualShock 4" : "已插入虚拟 Xbox 360 手柄");
  return gamepad;
}

function processInputPacket(frame, source, packetCount) {
  const packet = decodePacket(frame);
  if (!packet.active) {
    return;
  }
  const gamepad = ensureGamepad(packet.profile);
  gamepad.update({ ...packet.state, sequence: packet.sequence });
  if (packet.state.buttons !== lastButtons) {
    lastButtons = packet.state.buttons;
    if (lastButtons !== 0) {
      log(`按钮输入：0x${lastButtons.toString(16).padStart(4, "0")}`);
    }
  }
  const touchActive = packet.state.touch1Active || packet.state.touch2Active;
  if (touchActive !== lastTouchActive) {
    lastTouchActive = touchActive;
    log(
      touchActive
        ? `触控板按下：${packet.state.touch1X},${packet.state.touch1Y}`
        : "触控板已释放",
    );
  }
  if (packet.state.touchClick !== lastTouchClick) {
    lastTouchClick = packet.state.touchClick;
    if (packet.state.touchClick) {
      log(`触控板双击点按：${packet.state.touch1X},${packet.state.touch1Y}`);
    }
  }
  if (packetCount === 1 || packetCount % 1250 === 0) {
    lastReportedBattery = packet.state.batteryPercent;
    log(
      `收到${source}输入包 #${packetCount}，模式 ${
        packet.profile === 1 ? "DualShock 4" : "Xbox 360"
      }，电量 ${packet.state.batteryPercent < 0 ? "未知" : `${packet.state.batteryPercent}%`}`,
    );
  } else if (packet.state.batteryPercent !== lastReportedBattery) {
    lastReportedBattery = packet.state.batteryPercent;
    log(
      `掌机电量更新：${
        packet.state.batteryPercent < 0 ? "未知" : `${packet.state.batteryPercent}%`
      }`,
    );
  }
}

function receiveProtocolData(state, chunk, source) {
  consumeProtocolData(state, chunk, {
    source,
    log,
    onPacket: (frame, packetCount) =>
      processInputPacket(frame, source, packetCount),
    onControllerName: (controllerName) => {
      try {
        fs.writeFileSync(controllerNamePath, controllerName, "utf8");
      } catch {
        // The name is still available in the log.
      }
    },
  });
}

function savedBluetoothAddress() {
  try {
    const config = JSON.parse(fs.readFileSync(bluetoothConfigPath, "utf8"));
    return typeof config.address === "string" ? config.address : "";
  } catch {
    return "";
  }
}

function saveBluetoothAddress(address) {
  if (!address) {
    return;
  }
  try {
    fs.writeFileSync(
      bluetoothConfigPath,
      JSON.stringify({ address }, null, 2),
      "utf8",
    );
  } catch (error) {
    log(`无法保存蓝牙电脑地址：${error.message}`);
  }
}

function startBluetoothBridge() {
  if (bluetoothWorker) {
    return;
  }
  bluetoothWorker = new Worker(
    path.join(__dirname, "bluetooth-rfcomm-worker.js"),
    { workerData: { address: savedBluetoothAddress() } },
  );
  bluetoothWorker.on("message", (message) => {
    if (message.type === "address") {
      saveBluetoothAddress(message.address);
    } else if (message.type === "connected") {
      if (activeSocket) {
        log("USB 已处于活动状态，忽略重复的蓝牙连接");
        stopBluetoothBridge();
        return;
      }
      bluetoothConnected = true;
      saveBluetoothAddress(message.address);
      if (bluetoothFeedbackWorker) {
        bluetoothFeedbackWorker.terminate();
      }
      bluetoothFeedbackWorker = new Worker(
        path.join(__dirname, "bluetooth-feedback-worker.js"),
        { workerData: { socket: message.socket } },
      );
      bluetoothFeedbackWorker.on("message", (feedbackMessage) => {
        if (feedbackMessage.type === "log") {
          log(feedbackMessage.message);
        }
      });
      bluetoothFeedbackWorker.on("error", (error) => {
        log(`蓝牙震动服务错误：${error.message}`);
      });
      Object.assign(bluetoothStreamState, createProtocolState());
      log("蓝牙通道已连接掌机");
    } else if (message.type === "disconnected") {
      if (bluetoothConnected) {
        log("蓝牙通道已断开，正在自动重连");
      }
      bluetoothConnected = false;
      if (bluetoothFeedbackWorker) {
        bluetoothFeedbackWorker.terminate();
        bluetoothFeedbackWorker = null;
      }
      Object.assign(bluetoothStreamState, createProtocolState());
      if (!activeSocket) {
        disconnectActive();
      }
    } else if (message.type === "data") {
      try {
        receiveProtocolData(bluetoothStreamState, message.data, "蓝牙");
      } catch (error) {
        log(`蓝牙数据错误，已重建通道：${error.message}`);
        stopBluetoothBridge();
        scheduleBluetoothBridge(1_500);
      }
    } else if (message.type === "log") {
      log(message.message);
    }
  });
  bluetoothWorker.on("error", (error) => {
    log(`蓝牙后台服务错误：${error.message}`);
  });
}

function stopBluetoothBridge() {
  if (bluetoothRestartTimer) {
    clearTimeout(bluetoothRestartTimer);
    bluetoothRestartTimer = null;
  }
  if (bluetoothWorker) {
    bluetoothWorker.terminate();
    bluetoothWorker = null;
  }
  if (bluetoothFeedbackWorker) {
    bluetoothFeedbackWorker.terminate();
    bluetoothFeedbackWorker = null;
  }
  bluetoothConnected = false;
  Object.assign(bluetoothStreamState, createProtocolState());
}

function scheduleBluetoothBridge(delay = 1_500) {
  if (bluetoothWorker || bluetoothRestartTimer || activeSocket) {
    return;
  }
  bluetoothRestartTimer = setTimeout(() => {
    bluetoothRestartTimer = null;
    if (!activeSocket) {
      startBluetoothBridge();
    }
  }, delay);
}

const discovery = dgram.createSocket("udp4");
discovery.on("error", (error) => {
  log(`UDP 服务错误：${error.message}`);
});
discovery.on("message", (message, remote) => {
  if (message.toString("ascii").trim() !== DISCOVER_REQUEST) {
    return;
  }
  discovery.send(
    Buffer.from(DISCOVER_RESPONSE, "ascii"),
    remote.port,
    remote.address,
    (error) => {
      if (!error) {
        log(`掌机正在搜索电脑：${remote.address}:${remote.port}`);
      }
    },
  );
});
discovery.bind(DISCOVERY_PORT, "0.0.0.0", () => {
  discovery.setBroadcast(true);
  log(`USB 发现服务已监听 UDP ${DISCOVERY_PORT}`);
});

const tcpServer = net.createServer((socket) => {
  stopBluetoothBridge();
  if (activeSocket) {
    activeSocket.destroy();
  }
  activeSocket = socket;
  const streamState = createProtocolState();
  log(`掌机已连接：${socket.remoteAddress}:${socket.remotePort}`);

  socket.setNoDelay(true);
  socket.setKeepAlive(true, 1000);
  socket.on("data", (chunk) => {
    try {
      receiveProtocolData(streamState, chunk, "");
    } catch (error) {
      log(`忽略无效数据：${error.message}`);
      socket.destroy();
    }
  });
  socket.on("error", (error) => {
    log(`TCP 连接错误：${error.message}`);
  });
  socket.on("close", () => {
    if (activeSocket === socket) {
      activeSocket = null;
      if (!bluetoothConnected) {
        disconnectActive();
      }
      log("USB 连接已断开");
      scheduleBluetoothBridge();
    }
  });
});

tcpServer.on("error", (error) => {
  log(`TCP 服务错误：${error.message}`);
});
tcpServer.listen(DATA_PORT, "0.0.0.0", () => {
  log(`输入服务已监听 TCP ${DATA_PORT}`);
  stopAdbReverse = startAdbReverse(log);
  startBluetoothBridge();
  log("请在掌机上点击“开始桥接”；USB 与蓝牙都会自动连接");
});

function shutdown() {
  log("正在退出…");
  flushLogQueue(true);
  if (activeSocket) {
    activeSocket.destroy();
  }
  disconnectActive();
  if (bluetoothWorker) {
    stopBluetoothBridge();
  }
  if (bluetoothFeedbackWorker) {
    bluetoothFeedbackWorker.terminate();
    bluetoothFeedbackWorker = null;
  }
  if (bluetoothRestartTimer) {
    clearTimeout(bluetoothRestartTimer);
    bluetoothRestartTimer = null;
  }
  stopAdbReverse();
  tcpServer.close();
  discovery.close();
  setTimeout(() => process.exit(0), 100);
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
