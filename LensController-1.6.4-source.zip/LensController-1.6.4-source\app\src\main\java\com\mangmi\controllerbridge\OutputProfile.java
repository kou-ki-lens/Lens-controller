package com.mangmi.controllerbridge;

public enum OutputProfile {
    XBOX("Xbox 360", (byte) 0),
    DUALSHOCK_4("DualShock 4", (byte) 1);

    public final String displayName;
    public final byte wireValue;

    OutputProfile(String displayName, byte wireValue) {
        this.displayName = displayName;
        this.wireValue = wireValue;
    }

    public static OutputProfile fromWireValue(int value) {
        for (OutputProfile profile : values()) {
            if (profile.wireValue == value) {
                return profile;
            }
        }
        return XBOX;
    }
}
