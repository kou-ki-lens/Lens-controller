"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const {
  BUTTONS,
  decodePacket,
  encodePacket,
} = require("../protocol");
const {
  consumeProtocolData,
  createProtocolState,
  parseHandshakeName,
} = require("../protocol-stream");
const {
  encodeDs4BatteryLevel,
  encodeTouchBytes,
  encodeTouchCoordinates,
  getDs4ReportExType,
  toDs4ExtendedReport,
  toDs4Report,
  toXusbReport,
} = require("../virtual-gamepad");
const koffi = require("koffi");
const { selectAndroidDevices } = require("../bluetooth-discovery");

test("protocol round trip", () => {
  const original = {
    state: {
      leftX: -127,
      leftY: 88,
      rightX: -12,
      rightY: 127,
      leftTrigger: 0,
      rightTrigger: 255,
      buttons: BUTTONS.A | BUTTONS.RB | BUTTONS.DPAD_LEFT,
      batteryPercent: 76,
      charging: true,
      touch1Active: true,
      touch1Id: 4,
      touch1X: 960,
      touch1Y: 471,
      touch2Active: false,
      touch2Id: 5,
      touch2X: 1200,
      touch2Y: 300,
      touchClick: true,
    },
    profile: 1,
    sequence: 231,
    active: true,
  };
  assert.deepEqual(decodePacket(encodePacket(original)), original);
});

test("checksum rejects corrupted input", () => {
  const packet = encodePacket({
    state: {
      leftX: 0,
      leftY: 0,
      rightX: 0,
      rightY: 0,
      leftTrigger: 0,
      rightTrigger: 0,
      buttons: 0,
    },
  });
  packet[10] ^= 0x40;
  assert.throws(() => decodePacket(packet), /checksum/);
});

test("Xbox report maps digital and analog state", () => {
  const report = toXusbReport({
    leftX: 127,
    leftY: -127,
    rightX: 0,
    rightY: 0,
    leftTrigger: 200,
    rightTrigger: 12,
    buttons: BUTTONS.A | BUTTONS.X | BUTTONS.START | BUTTONS.DPAD_UP,
  });
  assert.equal(report.wButtons & 0x1000, 0x1000);
  assert.equal(report.wButtons & 0x4000, 0x4000);
  assert.equal(report.wButtons & 0x0010, 0x0010);
  assert.equal(report.wButtons & 0x0001, 0x0001);
  assert.equal(report.sThumbLX, 32767);
  assert.equal(report.sThumbLY, 32767);
  assert.equal(report.bLeftTrigger, 200);
});

test("XInput maps Android Y-down values to Y-up", () => {
  const report = toXusbReport({
    leftX: 0,
    leftY: -100,
    rightX: 0,
    rightY: 100,
    leftTrigger: 0,
    rightTrigger: 0,
    buttons: 0,
  });
  assert.ok(report.sThumbLY > 0);
  assert.ok(report.sThumbRY < 0);
});

test("DualShock report follows cross/circle/square/triangle layout", () => {
  const report = toDs4Report({
    leftX: 0,
    leftY: 0,
    rightX: 0,
    rightY: 0,
    leftTrigger: 0,
    rightTrigger: 255,
    buttons: BUTTONS.A | BUTTONS.B | BUTTONS.X | BUTTONS.Y | BUTTONS.DPAD_RIGHT,
  });
  assert.equal(report.bThumbLX, 128);
  assert.equal(report.bThumbLY, 128);
  assert.equal(report.bTriggerR, 255);
  assert.equal(report.wButtons & 0x0f, 2);
  assert.equal(report.wButtons & (1 << 4), 1 << 4);
  assert.equal(report.wButtons & (1 << 5), 1 << 5);
  assert.equal(report.wButtons & (1 << 6), 1 << 6);
  assert.equal(report.wButtons & (1 << 7), 1 << 7);
});

test("extended PlayStation report carries battery and touchpad coordinates", () => {
  const report = toDs4ExtendedReport({
    leftX: 0,
    leftY: 0,
    rightX: 0,
    rightY: 0,
    leftTrigger: 0,
    rightTrigger: 0,
    buttons: BUTTONS.A,
    batteryPercent: 76,
    charging: true,
    touch1Active: true,
    touch1Id: 4,
    touch1X: 960,
    touch1Y: 471,
    touchClick: true,
    sequence: 9,
  });
  assert.equal(koffi.sizeof(getDs4ReportExType()), 63);
  assert.equal(report.Report.bBatteryLvl, 0x18);
  assert.equal(report.Report.bTouchPacketsN, 1);
  assert.equal(report.Report.touch[1], 4);
  assert.equal(report.Report.bSpecial & 2, 2);
  assert.deepEqual(
    encodeTouchCoordinates(960, 471),
    report.Report.touch.slice(2, 5),
  );
  const extended = toDs4ExtendedReport({
    leftX: 0,
    leftY: 0,
    rightX: 0,
    rightY: 0,
    leftTrigger: 0,
    rightTrigger: 0,
    buttons: BUTTONS.A,
    batteryPercent: 76,
    charging: true,
    touch1Active: true,
    touch1Id: 4,
    touch1X: 960,
    touch1Y: 471,
    touchClick: true,
    sequence: 9,
  });
  assert.equal(extended.Report.touch.length, 27);
  assert.equal(extended.Report.touch[0], 9);
  assert.equal(extended.Report.bSpecial & 2, 2);
  assert.deepEqual(extended.Report.touch.slice(2, 5), [192, 115, 29]);
  assert.deepEqual(encodeTouchBytes({
    bPacketCounter: 9,
    bIsUpTrackingNum1: 4,
    bTouchData1: [1, 2, 3],
    bIsUpTrackingNum2: 0x80,
    bTouchData2: [4, 5, 6],
  }).slice(0, 9), [9, 4, 1, 2, 3, 128, 4, 5, 6]);
});

test("PlayStation battery uses the Sony nibble encoding", () => {
  assert.equal(encodeDs4BatteryLevel(-1, false), 0x0a);
  assert.equal(encodeDs4BatteryLevel(0, false), 0x00);
  assert.equal(encodeDs4BatteryLevel(76, false), 0x08);
  assert.equal(encodeDs4BatteryLevel(76, true), 0x18);
  assert.equal(encodeDs4BatteryLevel(100, true), 0x2a);
  assert.equal(encodeDs4BatteryLevel(100, false), 0x0a);
});

test("Bluetooth discovery prioritizes a remembered Android handheld", () => {
  const selected = selectAndroidDevices([
    {
      name: "LinkBuds S",
      address: "AC800AFE077C",
      remembered: true,
      deviceClass: 0x240404,
    },
    {
      name: "客厅掌机",
      address: "F074E47D8662",
      remembered: true,
      authenticated: true,
      deviceClass: 0x5a020c,
    },
    {
      name: "附近的手机",
      address: "B88E82EF921E",
      remembered: false,
      authenticated: false,
      deviceClass: 0x5a020c,
    },
  ]);

  assert.equal(selected[0].address, "F074E47D8662");
  assert.equal(selected.some((device) => device.name === "LinkBuds S"), false);
});

test("controller name handshake accepts fragmented UTF-8 names", () => {
  const state = createProtocolState();
  const names = [];
  const encodedName = Buffer.from("掌机 客厅", "utf8").toString("base64");
  const handshake = Buffer.from(`LENS1 ${encodedName}\n`, "ascii");
  consumeProtocolData(state, handshake.subarray(0, 7), {
    onControllerName: (name) => names.push(name),
  });
  consumeProtocolData(state, handshake.subarray(7), {
    onControllerName: (name) => names.push(name),
  });

  assert.equal(state.handshakeComplete, true);
  assert.deepEqual(names, ["掌机 客厅"]);
});

test("packet framing remains valid after the name handshake", () => {
  const state = createProtocolState();
  const packets = [];
  const packet = encodePacket({
    state: {
      leftX: 1,
      leftY: 2,
      rightX: 3,
      rightY: 4,
      leftTrigger: 5,
      rightTrigger: 6,
      buttons: BUTTONS.A,
    },
    profile: 0,
    sequence: 7,
    active: true,
  });
  const payload = Buffer.concat([
    Buffer.from("LENS1 TGVucyBjb250cm9sbGVy\n", "ascii"),
    packet,
    packet,
  ]);
  consumeProtocolData(state, payload.subarray(0, 31), {
    onPacket: (frame) => packets.push(Buffer.from(frame)),
  });
  consumeProtocolData(state, payload.subarray(31), {
    onPacket: (frame) => packets.push(Buffer.from(frame)),
  });

  assert.equal(packets.length, 2);
  assert.deepEqual(decodePacket(packets[0]).state.buttons, BUTTONS.A);
  assert.equal(state.pending.length, 0);
});

test("legacy packet-only connections keep working", () => {
  const state = createProtocolState();
  const packets = [];
  const packet = encodePacket({
    state: {
      leftX: 0,
      leftY: 0,
      rightX: 0,
      rightY: 0,
      leftTrigger: 0,
      rightTrigger: 0,
      buttons: 0,
    },
  });
  consumeProtocolData(state, packet, {
    onPacket: (frame) => packets.push(frame),
  });

  assert.equal(packets.length, 1);
  assert.equal(parseHandshakeName("LENS1 TGVucyBjb250cm9sbGVy"), "Lens controller");
});

test("high-frequency batches preserve every input frame", () => {
  const state = createProtocolState();
  const packet = encodePacket({
    state: {
      leftX: 10,
      leftY: -10,
      rightX: 20,
      rightY: -20,
      leftTrigger: 0,
      rightTrigger: 0,
      buttons: BUTTONS.A,
    },
  });
  let received = 0;
  consumeProtocolData(state, Buffer.concat(Array.from({ length: 500 }, () => packet)), {
    onPacket: () => {
      received += 1;
    },
  });

  assert.equal(received, 500);
  assert.equal(state.packetCount, 500);
  assert.equal(state.pending.length, 0);
});
