"use strict";

const PACKET_SIZE = 36;
const HEADER = Buffer.from("MGB1", "ascii");
const VERSION = 2;
const BUTTONS = Object.freeze({
  A: 1,
  B: 1 << 1,
  X: 1 << 2,
  Y: 1 << 3,
  LB: 1 << 4,
  RB: 1 << 5,
  BACK: 1 << 6,
  START: 1 << 7,
  GUIDE: 1 << 8,
  LS: 1 << 9,
  RS: 1 << 10,
  DPAD_UP: 1 << 11,
  DPAD_DOWN: 1 << 12,
  DPAD_LEFT: 1 << 13,
  DPAD_RIGHT: 1 << 14,
});

let crcTable;

function getCrcTable() {
  if (crcTable) {
    return crcTable;
  }
  crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) {
      c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    crcTable[n] = c >>> 0;
  }
  return crcTable;
}

function crc32(buffer, length = buffer.length) {
  const table = getCrcTable();
  let crc = 0xffffffff;
  for (let i = 0; i < length; i += 1) {
    crc = table[(crc ^ buffer[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function decodePacket(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length !== PACKET_SIZE) {
    throw new Error(`Invalid packet length: ${buffer?.length}`);
  }
  if (!buffer.subarray(0, 4).equals(HEADER)) {
    throw new Error("Invalid packet magic");
  }
  if (buffer[4] !== VERSION) {
    throw new Error(`Unsupported protocol version: ${buffer[4]}`);
  }
  const expectedCrc = buffer.readUInt32LE(32);
  const actualCrc = crc32(buffer, 32);
  if (actualCrc !== expectedCrc) {
    throw new Error("Packet checksum mismatch");
  }
  const flags = buffer[7];
  const battery = buffer[18];
  const touch1Present = (flags & (1 << 1)) !== 0;
  const touch2Present = (flags & (1 << 3)) !== 0;
  return {
    state: {
      leftX: buffer.readInt8(8),
      leftY: buffer.readInt8(9),
      rightX: buffer.readInt8(10),
      rightY: buffer.readInt8(11),
      leftTrigger: buffer.readUInt8(12),
      rightTrigger: buffer.readUInt8(13),
      buttons: buffer.readUInt32LE(14) & 0xffff,
      batteryPercent: battery === 255 ? -1 : battery,
      charging: (flags & (1 << 5)) !== 0,
      touch1Active: (flags & (1 << 2)) !== 0,
      touch1Id: touch1Present ? buffer[19] & 0x7f : -1,
      touch1X: buffer.readUInt16LE(20),
      touch1Y: buffer.readUInt16LE(22),
      touch2Active: (flags & (1 << 4)) !== 0,
      touch2Id: touch2Present ? buffer[24] & 0x7f : -1,
      touch2X: buffer.readUInt16LE(25),
      touch2Y: buffer.readUInt16LE(27),
      touchClick: (flags & (1 << 6)) !== 0,
    },
    profile: buffer[5],
    sequence: buffer[6],
    active: (flags & 1) !== 0,
  };
}

function encodePacket({ state, profile = 0, sequence = 0, active = true }) {
  const buffer = Buffer.alloc(PACKET_SIZE);
  HEADER.copy(buffer, 0);
  buffer[4] = VERSION;
  buffer[5] = profile;
  buffer[6] = sequence & 0xff;
  let flags = active ? 1 : 0;
  if ((state.touch1Id ?? -1) >= 0) {
    flags |= 1 << 1;
    if (state.touch1Active) flags |= 1 << 2;
  }
  if ((state.touch2Id ?? -1) >= 0) {
    flags |= 1 << 3;
    if (state.touch2Active) flags |= 1 << 4;
  }
  if (state.charging) flags |= 1 << 5;
  if (state.touchClick) flags |= 1 << 6;
  buffer[7] = flags;
  buffer.writeInt8(state.leftX, 8);
  buffer.writeInt8(state.leftY, 9);
  buffer.writeInt8(state.rightX, 10);
  buffer.writeInt8(state.rightY, 11);
  buffer.writeUInt8(state.leftTrigger, 12);
  buffer.writeUInt8(state.rightTrigger, 13);
  buffer.writeUInt32LE(state.buttons & 0xffff, 14);
  buffer[18] = (state.batteryPercent ?? -1) < 0 ? 255 : state.batteryPercent;
  buffer[19] = Math.max(0, state.touch1Id ?? 0);
  buffer.writeUInt16LE(state.touch1X ?? 0, 20);
  buffer.writeUInt16LE(state.touch1Y ?? 0, 22);
  buffer[24] = Math.max(0, state.touch2Id ?? 0);
  buffer.writeUInt16LE(state.touch2X ?? 0, 25);
  buffer.writeUInt16LE(state.touch2Y ?? 0, 27);
  buffer.writeUInt32LE(crc32(buffer, 32), 32);
  return buffer;
}

module.exports = {
  PACKET_SIZE,
  BUTTONS,
  decodePacket,
  encodePacket,
  crc32,
};
