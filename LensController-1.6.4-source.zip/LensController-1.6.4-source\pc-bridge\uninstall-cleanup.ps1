﻿param(
    [switch]$StopOnly
)

$ErrorActionPreference = "Continue"
$appRoot = $PSScriptRoot

$processes = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
foreach ($process in $processes) {
    $isLensNode =
        $process.Name -eq "node.exe" -and
        $process.ExecutablePath -eq (Join-Path $appRoot "runtime\node.exe")
    $isLensGui =
        $process.Name -eq "powershell.exe" -and
        $process.ProcessId -ne $PID -and
        $process.CommandLine -like "*$appRoot\LensControllerPC.ps1*"
    if ($isLensNode -or $isLensGui) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}
$bundledAdb = Join-Path $appRoot "adb\adb.exe"
if (Test-Path -LiteralPath $bundledAdb) {
    & $bundledAdb kill-server 2>$null | Out-Null
}
Start-Sleep -Milliseconds 300
foreach ($process in Get-CimInstance Win32_Process -ErrorAction SilentlyContinue) {
    $executablePath = [string]$process.ExecutablePath
    if ($process.Name -eq "adb.exe" -and
        $executablePath.StartsWith(
            $appRoot.TrimEnd('\') + '\',
            [StringComparison]::OrdinalIgnoreCase
        )) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}
Start-Sleep -Milliseconds 500

if ($StopOnly) {
    exit 0
}

$startupFolders = @(
    [Environment]::GetFolderPath("Startup"),
    [Environment]::GetFolderPath("CommonStartup")
)
foreach ($folder in $startupFolders) {
    if ($folder) {
        Remove-Item `
            -LiteralPath (Join-Path $folder "Lens controller PC.lnk") `
            -Force `
            -ErrorAction SilentlyContinue
    }
}

foreach ($ruleName in @(
    "Mangmi Bridge USB Discovery",
    "Mangmi Bridge USB Input",
    "Lens controller PC Service"
)) {
    try {
        Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue |
            Remove-NetFirewallRule -ErrorAction SilentlyContinue
    } catch {
        # The firewall rules may never have been created.
    }
}

$driverMarker = Join-Path $appRoot "driver-installed-by-lens.flag"
if (Test-Path -LiteralPath $driverMarker) {
    try {
        Start-Process `
            -FilePath "msiexec.exe" `
            -ArgumentList "/x {966606F3-2745-49E9-BF15-5C3EAA4E9077} /qn /norestart" `
            -Wait `
            -WindowStyle Hidden
    } catch {
        # Leave a shared driver alone if the MSI uninstaller cannot run.
    }
}

foreach ($name in @(
    "service.log",
    "service.previous.log",
    "service-launch.log",
    "service-launch-error.log",
    "service.pid",
    "controller-name.txt",
    "bluetooth-host.json",
    "driver-installed-by-lens.flag"
)) {
    Remove-Item -LiteralPath (Join-Path $appRoot $name) -Force -ErrorAction SilentlyContinue
}

$stateDirectory = Join-Path $env:LOCALAPPDATA "LensController"
if (Test-Path -LiteralPath $stateDirectory) {
    for ($attempt = 0; $attempt -lt 10; $attempt++) {
        Remove-Item -LiteralPath $stateDirectory -Recurse -Force -ErrorAction SilentlyContinue
        if (-not (Test-Path -LiteralPath $stateDirectory)) {
            break
        }
        Start-Sleep -Milliseconds 200
    }
}

exit 0
