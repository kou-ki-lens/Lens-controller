package com.mangmi.controllerbridge;

import android.app.AlertDialog;
import android.view.KeyEvent;
import android.view.View;

final class GamepadDialogNavigator {
    private GamepadDialogNavigator() {}

    static void attach(AlertDialog dialog, GamepadInputMapper inputMapper) {
        dialog.setOnKeyListener(
                (ignored, keyCode, event) -> {
                    if (!MainActivity.isGamepadSource(event.getSource(), event.getDevice())) {
                        return false;
                    }
                    if (event.getAction() != KeyEvent.ACTION_DOWN
                            || event.getRepeatCount() > 0) {
                        return true;
                    }
                    int action =
                            inputMapper.getKeyMapping().getOrDefault(
                                    keyCode, ButtonMapping.ACTION_NONE);
                    if (action == ButtonMapping.ACTION_A) {
                        View focused = dialog.getCurrentFocus();
                        View decor =
                                dialog.getWindow() == null
                                        ? null
                                        : dialog.getWindow().getDecorView();
                        if (focused == null || focused == decor) {
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
                        } else {
                            focused.performClick();
                        }
                        return true;
                    }
                    if (action == ButtonMapping.ACTION_B) {
                        dialog.cancel();
                        return true;
                    }
                    return false;
                });
    }
}
