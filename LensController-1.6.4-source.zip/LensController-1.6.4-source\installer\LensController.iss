#define AppName "Lens controller"
#define AppVersion "1.6.4"
#define AppPublisher "Lens controller"
#define AppExeName "start-pc.vbs"

[Setup]
AppId={{2EF8D7F1-FB74-4FB7-A4FD-6C705E74373A}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\Lens controller
DefaultGroupName=Lens controller
DisableDirPage=no
DisableProgramGroupPage=yes
AllowNoIcons=yes
OutputDir=..\dist
OutputBaseFilename=LensController-{#AppVersion}-Setup
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
SetupIconFile=..\pc-bridge\app.ico
WizardImageFile=..\branding\wizard-large.bmp
WizardSmallImageFile=..\branding\wizard-small.bmp
UninstallDisplayIcon={app}\app.ico
UninstallDisplayName={#AppName}
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "chinesesimplified"; MessagesFile: "compiler:Default.isl"

[LangOptions]
LanguageName=简体中文
LanguageID=$0804

[Messages]
SetupAppTitle=Lens controller 安装程序
SetupWindowTitle=Lens controller 安装程序 - %1
ButtonBack=< 上一步
ButtonNext=下一步 >
ButtonInstall=安装
ButtonOK=确定
ButtonCancel=取消
ButtonYes=是
ButtonNo=否
ButtonFinish=完成
ButtonBrowse=浏览...
WelcomeLabel1=欢迎使用 [name] 安装向导
WelcomeLabel2=安装程序将在电脑上安装 [name/ver]。%n%n建议继续前关闭正在运行的掌机桥接程序。
SelectDirLabel3=安装程序将把 [name] 安装到以下目录，你也可以选择其他目录。
SelectDirBrowseLabel=点击“下一步”继续；如需更改安装目录，请点击“浏览”。
SelectTasksLabel2=请选择安装 [name] 时需要的附加任务，然后点击“下一步”。
ReadyLabel1=安装程序已准备好将 [name] 安装到电脑。
ReadyLabel2a=点击“安装”继续；如需检查或更改设置，请点击“上一步”。
InstallingLabel=正在安装 [name]，请稍候。
FinishedHeadingLabel=完成 [name] 安装向导
FinishedLabelNoIcons=[name] 已安装完成。
FinishedLabel=[name] 已安装完成，可从开始菜单或桌面快捷方式启动。
ClickFinish=点击“完成”退出安装程序。
StatusCreateIcons=正在创建快捷方式...
ConfirmUninstall=确定要完全卸载 %1 及其全部组件吗？
UninstalledAll=%1 已从电脑中卸载。
StatusUninstalling=正在卸载 %1...

[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式"; GroupDescription: "快捷方式："; Flags: checkedonce
Name: "autostart"; Description: "登录 Windows 时自动启动服务"; GroupDescription: "启动选项："; Flags: unchecked

[Files]
Source: "..\LensController-PC\PC-Bridge\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "service.log,service.previous.log,service.pid,controller-name.txt,bluetooth-host.json,driver-installed-by-lens.flag"
Source: "..\pc-bridge\app.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\pc-bridge\app-white.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Lens controller"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\{#AppExeName}"""; WorkingDir: "{app}"; IconFilename: "{app}\app.ico"
Name: "{autodesktop}\Lens controller"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\{#AppExeName}"""; WorkingDir: "{app}"; IconFilename: "{app}\app-white.ico"; Tasks: desktopicon
Name: "{userstartup}\Lens controller PC"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\{#AppExeName}"" -Autostart"; WorkingDir: "{app}"; IconFilename: "{app}\app.ico"; Tasks: autostart

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\setup-runtime.ps1"""; StatusMsg: "正在安装和检查虚拟手柄驱动…"; Flags: runhidden waituntilterminated
Filename: "{sys}\wscript.exe"; Parameters: """{app}\{#AppExeName}"""; Description: "启动 Lens controller"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\uninstall-cleanup.ps1"""; RunOnceId: "StopLensServices"; Flags: runhidden waituntilterminated

[UninstallDelete]
Type: filesandordirs; Name: "{app}"
Type: filesandordirs; Name: "{localappdata}\LensController"

[Code]
var
  ViGEmWasInstalled: Boolean;

function InitializeSetup(): Boolean;
begin
  ViGEmWasInstalled :=
    RegValueExists(
      HKLM,
      'SYSTEM\CurrentControlSet\Services\ViGEmBus',
      'ImagePath'
    );
  Result := True;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if (CurStep = ssPostInstall) and (not ViGEmWasInstalled) then
    SaveStringToFile(
      ExpandConstant('{app}\driver-installed-by-lens.flag'),
      '1',
      False
    );
end;
