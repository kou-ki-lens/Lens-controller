"use strict";

const { parentPort, workerData } = require("node:worker_threads");
const koffi = require("koffi");
const { findAndroidDevices } = require("./bluetooth-discovery");

const AF_BTH = 32;
const SOCK_STREAM = 1;
const BTHPROTO_RFCOMM = 3;
const SERVICE_UUID = {
  Data1: 0x7c6a0001,
  Data2: 0x8f43,
  Data3: 0x4a3f,
  Data4: [0x9a, 0x72, 0x4c, 0x65, 0x6e, 0x73, 0x43, 0x31],
};
const FIONBIO = 0x8004667e;
const WSAEWOULDBLOCK = 10035;
const SOL_SOCKET = 0xffff;
const SO_ERROR = 0x1007;

const GUID = koffi.struct("LENS_GUID", {
  Data1: "uint32",
  Data2: "uint16",
  Data3: "uint16",
  Data4: koffi.array("uint8", 8),
});

const SOCKADDR_BTH = koffi.pack("LENS_SOCKADDR_BTH", {
  addressFamily: "uint16",
  btAddr: "uint64",
  serviceClassId: GUID,
  port: "uint32",
});

const TIMEVAL = koffi.struct("LENS_TIMEVAL", {
  tv_sec: "int32",
  tv_usec: "int32",
});

const FD_SET = koffi.struct("LENS_FD_SET", {
  fd_count: "uint32",
  fd_array: koffi.array("uint64", 64),
});

const ws2 = koffi.load("ws2_32.dll");
const WSAStartup = ws2.func("WSAStartup", "int", ["uint16", "void *"]);
const WSAGetLastError = ws2.func("WSAGetLastError", "int", []);
const socketFn = ws2.func("socket", "intptr_t", ["int", "int", "int"]);
const connectFn = ws2.func("connect", "int", ["intptr_t", "void *", "int"]);
const ioctlsocketFn = ws2.func("ioctlsocket", "int", ["intptr_t", "uint32", "void *"]);
const selectFn = ws2.func("select", "int", [
  "int",
  "void *",
  "void *",
  "void *",
  "void *",
]);
const getsockoptFn = ws2.func("getsockopt", "int", [
  "intptr_t",
  "int",
  "int",
  "void *",
  "void *",
]);
const recvFn = ws2.func("recv", "int", ["intptr_t", "void *", "int", "int"]);
const closesocketFn = ws2.func("closesocket", "int", ["intptr_t"]);

let activeSocket = -1;

function log(message) {
  parentPort.postMessage({ type: "log", message });
}

function sleep(milliseconds) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, milliseconds);
}

function setNonBlocking(socket, enabled) {
  const modePointer = koffi.alloc("uint32", 1);
  try {
    koffi.encode(modePointer, "uint32", enabled ? 1 : 0);
    if (ioctlsocketFn(socket, FIONBIO, modePointer) !== 0) {
      throw new Error(`设置 RFCOMM socket 模式失败，WSA 错误 ${WSAGetLastError()}`);
    }
  } finally {
    koffi.free(modePointer);
  }
}

function waitForConnect(socket, timeoutSeconds = 3.0) {
  const writeSet = koffi.alloc(FD_SET, 1);
  const exceptionSet = koffi.alloc(FD_SET, 1);
  const timeout = koffi.alloc(TIMEVAL, 1);
  const socketArray = new Array(64).fill(0n);
  socketArray[0] = BigInt(socket);
  try {
    koffi.encode(writeSet, FD_SET, { fd_count: 1, fd_array: socketArray });
    koffi.encode(exceptionSet, FD_SET, { fd_count: 1, fd_array: socketArray });
    const seconds = Math.floor(timeoutSeconds);
    koffi.encode(timeout, TIMEVAL, {
      tv_sec: seconds,
      tv_usec: Math.round((timeoutSeconds - seconds) * 1_000_000),
    });
    const ready = selectFn(0, null, writeSet, exceptionSet, timeout);
    if (ready === 0) {
      throw new Error("RFCOMM 连接超时，掌机端尚未开始监听");
    }
    if (ready < 0) {
      throw new Error(`RFCOMM select 失败，WSA 错误 ${WSAGetLastError()}`);
    }

    const errorPointer = koffi.alloc("int32", 1);
    const lengthPointer = koffi.alloc("uint32", 1);
    try {
      koffi.encode(errorPointer, "int32", 0);
      koffi.encode(lengthPointer, "uint32", 4);
      if (
        getsockoptFn(
          socket,
          SOL_SOCKET,
          SO_ERROR,
          errorPointer,
          lengthPointer,
        ) !== 0
      ) {
        throw new Error(`读取 RFCOMM 连接结果失败，WSA 错误 ${WSAGetLastError()}`);
      }
      const code = koffi.decode(errorPointer, "int32");
      if (code !== 0) {
        throw new Error(`RFCOMM 连接失败，WSA 错误 ${code}`);
      }
    } finally {
      koffi.free(lengthPointer);
      koffi.free(errorPointer);
    }
  } finally {
    koffi.free(timeout);
    koffi.free(exceptionSet);
    koffi.free(writeSet);
  }
}

function connect(address) {
  const bluetoothAddress = BigInt("0x" + address.replace(/:/g, ""));
  const socket = socketFn(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM);
  if (socket < 0) {
    throw new Error(`无法创建 RFCOMM socket，WSA 错误 ${WSAGetLastError()}`);
  }

  const addressPointer = koffi.alloc(SOCKADDR_BTH, 1);
  try {
    koffi.encode(addressPointer, SOCKADDR_BTH, {
      addressFamily: AF_BTH,
      btAddr: bluetoothAddress,
      serviceClassId: SERVICE_UUID,
      port: 0,
    });
    setNonBlocking(socket, true);
    const result = connectFn(
      socket,
      addressPointer,
      koffi.sizeof(SOCKADDR_BTH),
    );
    if (result !== 0) {
      const code = WSAGetLastError();
      if (code !== WSAEWOULDBLOCK) {
        closesocketFn(socket);
        throw new Error(`RFCOMM 连接失败，WSA 错误 ${code}`);
      }
      try {
        waitForConnect(socket);
      } catch (error) {
        closesocketFn(socket);
        throw error;
      }
    }
    setNonBlocking(socket, false);
  } finally {
    koffi.free(addressPointer);
  }
  return socket;
}

function main() {
  const startup = Buffer.alloc(512);
  if (WSAStartup(0x0202, startup) !== 0) {
    throw new Error("Winsock 初始化失败");
  }

  let address = workerData.address || "";
  const preferredAddress = address;
  let candidates = address ? [{ address, name: "已保存设备" }] : [];
  let candidateIndex = 0;
  let lastError = "";
  let lastCandidateSignature = "";
  let retriesSinceDiscovery = 0;
  let retryDelay = 800;
  let connectedOnce = false;
  while (true) {
    if (!address || retriesSinceDiscovery >= 6) {
      // Once an address is known, query remembered/connected devices only. A full
      // Bluetooth inquiry adds several seconds to every reconnect and is unnecessary.
      const discovered = findAndroidDevices({ includeUnknown: !address });
      retriesSinceDiscovery = 0;
      if (discovered.length > 0) {
        const bondedCandidates = discovered.filter(
          (device) => device.remembered || device.authenticated,
        );
        candidates =
          bondedCandidates.length > 0 ? bondedCandidates : discovered;
        candidates.sort((left, right) => {
          const score = (device) => {
            let value = 0;
            if (preferredAddress && device.address === preferredAddress) value += 100;
            if (device.connected) value += 20;
            if (device.remembered) value += 10;
            if (device.authenticated) value += 5;
            return value;
          };
          return score(right) - score(left);
        });
        candidateIndex = 0;
        const device = candidates[0];
        address = device.address;
        const candidateSignature = `${device.name || "Android 掌机"}|${address}`;
        if (candidateSignature !== lastCandidateSignature) {
          lastCandidateSignature = candidateSignature;
          log(`找到蓝牙候选设备：${device.name || "Android 掌机"} (${address})`);
        }
      } else if (!address) {
        const message = "未找到蓝牙掌机，请确认应用已点击开始桥接";
        if (message !== lastError) {
          log(message);
          lastError = message;
        }
        sleep(3500);
        continue;
      }
    }

    let socket = -1;
    try {
      socket = connect(address);
      activeSocket = socket;
      retryDelay = 800;
      connectedOnce = true;
      parentPort.postMessage({ type: "connected", address, socket });
      const buffer = Buffer.alloc(8192);
      while (true) {
        const received = recvFn(socket, buffer, buffer.length, 0);
        if (received <= 0) {
          break;
        }
        parentPort.postMessage({
          type: "data",
          data: Buffer.from(buffer.subarray(0, received)),
        });
      }
    } catch (error) {
      if (error.message !== lastError) {
        log(error.message);
        lastError = error.message;
      }
    } finally {
      activeSocket = -1;
      if (socket >= 0) {
        closesocketFn(socket);
      }
    }
    parentPort.postMessage({ type: "disconnected" });
    retriesSinceDiscovery++;
    if (candidates.length > 1) {
      candidateIndex = (candidateIndex + 1) % candidates.length;
      address = candidates[candidateIndex].address;
    }
    sleep(retryDelay);
    retryDelay = connectedOnce
      ? 800
      : Math.min(5_000, Math.max(900, retryDelay + 600));
    connectedOnce = false;
  }
}

main();
