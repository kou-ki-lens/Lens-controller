﻿param(
    [string]$Version = "1.6.4"
)

$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$publishRoot = Join-Path $root "publish"
$sourceOutput = Join-Path $publishRoot "LensController-$Version-source"
$releaseOutput = Join-Path $publishRoot "LensController-$Version-release"
$sourceZip = Join-Path $publishRoot "LensController-$Version-source.zip"
$releaseZip = Join-Path $publishRoot "LensController-$Version-release.zip"

foreach ($path in @($sourceOutput, $releaseOutput, $sourceZip, $releaseZip)) {
    $fullPath = [IO.Path]::GetFullPath($path)
    if (-not $fullPath.StartsWith([IO.Path]::GetFullPath($publishRoot), [StringComparison]::OrdinalIgnoreCase)) {
        throw "拒绝清理非发布目录：$fullPath"
    }
}

if (Test-Path -LiteralPath $publishRoot) {
    Remove-Item -LiteralPath $publishRoot -Recurse -Force
}
New-Item -ItemType Directory -Path $sourceOutput, $releaseOutput -Force | Out-Null

foreach ($name in @(
    ".gitignore",
    "README.md",
    "TEST-REPORT.md",
    "PC-使用说明.txt",
    "build.gradle",
    "settings.gradle",
    "gradle.properties",
    "gradlew",
    "gradlew.bat",
    "build-release.ps1",
    "build-all.ps1"
)) {
    Copy-Item -LiteralPath (Join-Path $root $name) -Destination $sourceOutput -Force
}

foreach ($folder in @("app", "gradle", "installer", "branding", "tools")) {
    Copy-Item `
        -LiteralPath (Join-Path $root $folder) `
        -Destination (Join-Path $sourceOutput $folder) `
        -Recurse `
        -Force
}
$copiedAppBuild = Join-Path $sourceOutput "app\build"
if (Test-Path -LiteralPath $copiedAppBuild) {
    Remove-Item -LiteralPath $copiedAppBuild -Recurse -Force
}

$pcSource = Join-Path $root "pc-bridge"
$pcOutput = Join-Path $sourceOutput "pc-bridge"
New-Item -ItemType Directory -Path $pcOutput -Force | Out-Null
Get-ChildItem -LiteralPath $pcSource -File |
    Where-Object {
        $_.Name -notin @(
            "bluetooth-host.json",
            "controller-name.txt",
            "driver-installed-by-lens.flag",
            "service.log",
            "service.previous.log",
            "service.pid"
        )
    } |
    Copy-Item -Destination $pcOutput -Force
foreach ($folder in @("adb", "driver", "native", "test", "tools")) {
    $sourceFolder = Join-Path $pcSource $folder
    if (Test-Path -LiteralPath $sourceFolder) {
        Copy-Item `
            -LiteralPath $sourceFolder `
            -Destination (Join-Path $pcOutput $folder) `
            -Recurse `
            -Force
    }
}

$apk = Join-Path $root "dist\LensController-$Version.apk"
$setup = Join-Path $root "dist\LensController-$Version-Setup.exe"
$checksums = Join-Path $root "dist\LensController-$Version-SHA256SUMS.txt"
$instructions = Join-Path $root "PC-使用说明.txt"
foreach ($required in @($apk, $setup, $checksums, $instructions)) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "发布文件不存在：$required"
    }
    Copy-Item -LiteralPath $required -Destination $releaseOutput -Force
}
Copy-Item -LiteralPath (Join-Path $root "README.md") -Destination $releaseOutput -Force
Copy-Item -LiteralPath (Join-Path $root "TEST-REPORT.md") -Destination $releaseOutput -Force

Compress-Archive -LiteralPath $sourceOutput -DestinationPath $sourceZip -CompressionLevel Optimal
Compress-Archive -LiteralPath $releaseOutput -DestinationPath $releaseZip -CompressionLevel Optimal

Write-Host "GitHub 源文件目录：$sourceOutput" -ForegroundColor Green
Write-Host "GitHub 程序目录：$releaseOutput" -ForegroundColor Green
