package com.mangmi.controllerbridge;

import android.content.Context;
import android.hardware.input.InputManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.InputDevice;

public final class HandheldVibrationController {
    private final Context context;
    private final InputManager inputManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile int pendingLeft;
    private volatile int pendingRight;
    private boolean updatePosted;
    private boolean enabled = true;
    private Vibrator activeVibrator;

    private final Runnable applyRumble =
            () -> {
                updatePosted = false;
                applyNow(pendingLeft, pendingRight);
            };

    public HandheldVibrationController(Context context) {
        this.context = context.getApplicationContext();
        inputManager = (InputManager) context.getSystemService(Context.INPUT_SERVICE);
    }

    public void setEnabled(boolean value) {
        enabled = value;
        if (!enabled) {
            handler.post(this::cancel);
        }
    }

    public void rumble(int leftMotor, int rightMotor) {
        pendingLeft = clamp(leftMotor);
        pendingRight = clamp(rightMotor);
        if (!enabled) {
            handler.post(this::cancel);
            return;
        }
        if (!updatePosted) {
            updatePosted = true;
            handler.postDelayed(applyRumble, 45L);
        }
    }

    public void stop() {
        handler.removeCallbacksAndMessages(null);
        updatePosted = false;
        cancel();
    }

    private void applyNow(int left, int right) {
        if (!enabled) {
            cancel();
            return;
        }
        int amplitude = Math.max(left, right);
        if (amplitude <= 0) {
            cancel();
            return;
        }
        Vibrator vibrator = findGamepadVibrator();
        boolean gamepadVibrator = vibrator != null;
        if (vibrator == null) {
            vibrator = defaultVibrator();
        }
        if (vibrator == null || !vibrator.hasVibrator()) {
            Log.w("LensController", "No handheld vibrator available");
            return;
        }
        activeVibrator = vibrator;
        int scaled = Math.max(1, Math.min(255, amplitude));
        Log.d(
                "LensController",
                "Rumble amplitude=" + scaled + " gamepad=" + gamepadVibrator);
        try {
            vibrator.vibrate(VibrationEffect.createOneShot(120L, scaled));
        } catch (SecurityException exception) {
            Log.w("LensController", "Rumble permission denied", exception);
        }
    }

    private Vibrator findGamepadVibrator() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || inputManager == null) {
            return null;
        }
        for (int id : inputManager.getInputDeviceIds()) {
            InputDevice device = inputManager.getInputDevice(id);
            if (device == null
                    || (device.getSources()
                                    & (InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK))
                            == 0) {
                continue;
            }
            Vibrator vibrator = device.getVibrator();
            if (vibrator != null && vibrator.hasVibrator()) {
                return vibrator;
            }
        }
        return null;
    }

    private Vibrator defaultVibrator() {
        Object service = context.getSystemService(Context.VIBRATOR_SERVICE);
        return service instanceof Vibrator ? (Vibrator) service : null;
    }

    private void cancel() {
        if (activeVibrator != null) {
            activeVibrator.cancel();
            activeVibrator = null;
        }
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }
}
