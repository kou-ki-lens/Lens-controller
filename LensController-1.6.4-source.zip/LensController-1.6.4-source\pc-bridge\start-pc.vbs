Option Explicit

Dim shell, fileSystem, root, scriptPath, command
Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")
root = fileSystem.GetParentFolderName(WScript.ScriptFullName)
scriptPath = fileSystem.BuildPath(root, "LensControllerPC.ps1")

command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & scriptPath & """"
If WScript.Arguments.Count > 0 Then
    command = command & " -Autostart"
End If

shell.CurrentDirectory = root
shell.Run command, 0, False
