﻿$ErrorActionPreference = "Stop"

$installer = Join-Path $PSScriptRoot "driver\ViGEmBus_1.22.0_x64_x86_arm64.exe"
if (-not (Test-Path -LiteralPath $installer)) {
    throw "未找到驱动安装包：$installer"
}

$principal = New-Object Security.Principal.WindowsPrincipal(
    [Security.Principal.WindowsIdentity]::GetCurrent()
)
$isAdmin = $principal.IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)
if (-not $isAdmin) {
    $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    $child = Start-Process -FilePath "powershell.exe" -ArgumentList $arguments -Verb RunAs -Wait -PassThru
    exit $child.ExitCode
}

$service = Get-Service -Name ViGEmBus -ErrorAction SilentlyContinue
if (-not $service) {
    Write-Host "正在安装 ViGEmBus 虚拟手柄驱动…"
    $process = Start-Process -FilePath $installer -ArgumentList "/quiet" -Wait -PassThru
    if ($process.ExitCode -ne 0) {
        throw "驱动安装程序返回错误码 $($process.ExitCode)"
    }
} else {
    Write-Host "ViGEmBus 驱动已安装。" -ForegroundColor Green
}

$service = Get-Service -Name ViGEmBus -ErrorAction SilentlyContinue
if (-not $service) {
    throw "驱动安装结束，但没有找到 ViGEmBus 服务。请重启电脑后重试。"
}

$firewallRules = @(
    @{
        DisplayName = "Mangmi Bridge USB Discovery"
        Protocol = "UDP"
        LocalPort = 47653
    },
    @{
        DisplayName = "Mangmi Bridge USB Input"
        Protocol = "TCP"
        LocalPort = 47654
    }
)

foreach ($rule in $firewallRules) {
    try {
        $existing = Get-NetFirewallRule -DisplayName $rule.DisplayName -ErrorAction SilentlyContinue
        if (-not $existing) {
            New-NetFirewallRule `
                -DisplayName $rule.DisplayName `
                -Direction Inbound `
                -Action Allow `
                -Protocol $rule.Protocol `
                -LocalPort $rule.LocalPort `
                -RemoteAddress LocalSubnet `
                -Profile Any | Out-Null
            Write-Host "已添加防火墙规则：$($rule.DisplayName)" -ForegroundColor Green
        }
    } catch {
        Write-Warning "防火墙规则未添加；ADB 隧道模式仍可使用。"
    }
}

$nodePath = Join-Path $PSScriptRoot "runtime\node.exe"
try {
    if (-not (Get-NetFirewallRule -DisplayName "Lens controller PC Service" -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule `
            -DisplayName "Lens controller PC Service" `
            -Direction Inbound `
            -Action Allow `
            -Program $nodePath `
            -Profile Any | Out-Null
    }
} catch {
    Write-Warning "未添加应用防火墙规则；固定端口规则仍可使用。"
}

$startScript = Join-Path $PSScriptRoot "start-pc.vbs"
$startupDirectory = [Environment]::GetFolderPath("Startup")
$shortcutPath = Join-Path $startupDirectory "Lens controller PC.lnk"
if (Test-Path -LiteralPath $startScript) {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
    $shortcut.Arguments = "`"$startScript`" -Autostart"
    $shortcut.WorkingDirectory = $PSScriptRoot
    $shortcut.WindowStyle = 7
    $shortcut.Description = "Lens controller 蓝牙/USB 虚拟手柄服务"
    $iconPath = Join-Path $PSScriptRoot "app.ico"
    if (Test-Path -LiteralPath $iconPath) {
        $shortcut.IconLocation = "$iconPath,0"
    }
    $shortcut.Save()
    Write-Host "已加入 Windows 登录启动项。" -ForegroundColor Green
}

Write-Host "PC 配套程序安装完成。" -ForegroundColor Green
