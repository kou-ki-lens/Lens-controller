﻿param(
    [string]$NodeExecutable = "",
    [string]$InnoCompiler = ""
)

$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$source = Join-Path $root "pc-bridge"
$stage = Join-Path $root "LensController-PC\PC-Bridge"
$expectedStage = [IO.Path]::GetFullPath((Join-Path $root "LensController-PC\PC-Bridge"))

if ([IO.Path]::GetFullPath($stage) -ne $expectedStage) {
    throw "拒绝清理非预期构建目录：$stage"
}
if (-not (Test-Path -LiteralPath (Join-Path $source "node_modules\koffi"))) {
    throw "缺少 PC 依赖，请先在 pc-bridge 目录运行 npm ci。"
}

if (-not $NodeExecutable) {
    $nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($null -eq $nodeCommand) {
        throw "未找到 node.exe；请安装 Node.js 或传入 -NodeExecutable。"
    }
    $NodeExecutable = $nodeCommand.Source
}
if (-not (Test-Path -LiteralPath $NodeExecutable)) {
    throw "Node 运行时不存在：$NodeExecutable"
}

$stageAdb = Join-Path $stage "adb\adb.exe"
if (Test-Path -LiteralPath $stageAdb) {
    & $stageAdb kill-server 2>$null | Out-Null
    Start-Sleep -Milliseconds 300
}

if (Test-Path -LiteralPath $stage) {
    Remove-Item -LiteralPath $stage -Recurse -Force
}
New-Item -ItemType Directory -Path $stage -Force | Out-Null

Get-ChildItem -LiteralPath $source -File |
    Where-Object {
        $_.Extension -in ".js", ".ps1", ".cmd", ".vbs", ".json", ".ico", ".png", ".txt"
    } |
    Copy-Item -Destination $stage -Force

foreach ($folder in @("adb", "driver", "native", "node_modules", "tools")) {
    $sourceFolder = Join-Path $source $folder
    if (Test-Path -LiteralPath $sourceFolder) {
        Copy-Item `
            -LiteralPath $sourceFolder `
            -Destination (Join-Path $stage $folder) `
            -Recurse `
            -Force
    }
}

$runtimeFolder = Join-Path $stage "runtime"
New-Item -ItemType Directory -Path $runtimeFolder -Force | Out-Null
Copy-Item -LiteralPath $NodeExecutable -Destination (Join-Path $runtimeFolder "node.exe") -Force

if (-not $InnoCompiler) {
    $candidates = @(
        (Join-Path $root ".inno-setup\ISCC.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"),
        (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe")
    )
    $InnoCompiler = $candidates |
        Where-Object { $_ -and (Test-Path -LiteralPath $_) } |
        Select-Object -First 1
}
if (-not $InnoCompiler -or -not (Test-Path -LiteralPath $InnoCompiler)) {
    throw "未找到 Inno Setup 6 编译器 ISCC.exe。"
}

& $InnoCompiler (Join-Path $root "installer\LensController.iss")
if ($LASTEXITCODE -ne 0) {
    throw "Windows 安装包编译失败。"
}

Write-Host "Windows 安装包已生成到 dist。" -ForegroundColor Green
